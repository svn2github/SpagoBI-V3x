package org.talend.designer.codegen.translators.file.output;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;
import java.util.List;

public class TFileOutputExcelBeginJava
{
  protected static String nl;
  public static synchronized TFileOutputExcelBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileOutputExcelBeginJava result = new TFileOutputExcelBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + NL + "\t\tint nb_line_";
  protected final String TEXT_3 = " = 0;" + NL + "\t\tjava.io.File file_";
  protected final String TEXT_4 = " = new java.io.File(";
  protected final String TEXT_5 = ");" + NL + "\t\t";
  protected final String TEXT_6 = NL + "//create directory only if not exists\t\t  " + NL + "          java.io.File parentFile_";
  protected final String TEXT_7 = " = file_";
  protected final String TEXT_8 = ".getParentFile();" + NL + "          if (parentFile_";
  protected final String TEXT_9 = " != null && !parentFile_";
  protected final String TEXT_10 = ".exists()) {" + NL + "             parentFile_";
  protected final String TEXT_11 = ".mkdirs();" + NL + "          }";
  protected final String TEXT_12 = "\t\t" + NL + "\t\t" + NL + "\t\tjxl.write.WritableWorkbook writeableWorkbook_";
  protected final String TEXT_13 = " = null;" + NL + "\t\tjxl.write.WritableSheet writableSheet_";
  protected final String TEXT_14 = " = null;" + NL + "\t\t" + NL + "\t\tjxl.WorkbookSettings workbookSettings_";
  protected final String TEXT_15 = " = new jxl.WorkbookSettings();" + NL + "        workbookSettings_";
  protected final String TEXT_16 = ".setEncoding(";
  protected final String TEXT_17 = ");" + NL + "        ";
  protected final String TEXT_18 = "  " + NL + "        if (file_";
  protected final String TEXT_19 = ".exists()) {" + NL + "        jxl.Workbook workbook_";
  protected final String TEXT_20 = " = jxl.Workbook.getWorkbook(file_";
  protected final String TEXT_21 = ");" + NL + "        writeableWorkbook_";
  protected final String TEXT_22 = " = new jxl.write.biff.WritableWorkbookImpl(" + NL + "                \tnew java.io.BufferedOutputStream(new java.io.FileOutputStream(file_";
  protected final String TEXT_23 = ", false)), " + NL + "                \tworkbook_";
  protected final String TEXT_24 = ", " + NL + "                \ttrue," + NL + "                    workbookSettings_";
  protected final String TEXT_25 = ");" + NL + "        }else{        " + NL + "\t\twriteableWorkbook_";
  protected final String TEXT_26 = " = new jxl.write.biff.WritableWorkbookImpl(" + NL + "            \t\tnew java.io.BufferedOutputStream(new java.io.FileOutputStream(";
  protected final String TEXT_27 = ")), " + NL + "            \t\ttrue, " + NL + "            \t\tworkbookSettings_";
  protected final String TEXT_28 = ");        " + NL + "        }     ";
  protected final String TEXT_29 = NL + "\t\twriteableWorkbook_";
  protected final String TEXT_30 = " = new jxl.write.biff.WritableWorkbookImpl(" + NL + "            \t\tnew java.io.BufferedOutputStream(new java.io.FileOutputStream(";
  protected final String TEXT_31 = ")), " + NL + "            \t\ttrue, " + NL + "            \t\tworkbookSettings_";
  protected final String TEXT_32 = ");";
  protected final String TEXT_33 = "       " + NL + "" + NL + "        writableSheet_";
  protected final String TEXT_34 = " = writeableWorkbook_";
  protected final String TEXT_35 = ".getSheet(";
  protected final String TEXT_36 = ");" + NL + "        if(writableSheet_";
  protected final String TEXT_37 = " == null){" + NL + "        \twritableSheet_";
  protected final String TEXT_38 = " = writeableWorkbook_";
  protected final String TEXT_39 = ".createSheet(";
  protected final String TEXT_40 = ", writeableWorkbook_";
  protected final String TEXT_41 = ".getNumberOfSheets());" + NL + "\t\t}" + NL + "\t\t";
  protected final String TEXT_42 = NL + "        else {" + NL + "" + NL + "            String[] sheetNames_";
  protected final String TEXT_43 = " = writeableWorkbook_";
  protected final String TEXT_44 = ".getSheetNames();" + NL + "            for (int i = 0; i < sheetNames_";
  protected final String TEXT_45 = ".length; i++) {" + NL + "                if (sheetNames_";
  protected final String TEXT_46 = "[i].equals(";
  protected final String TEXT_47 = ")) {" + NL + "                    writeableWorkbook_";
  protected final String TEXT_48 = ".removeSheet(i);" + NL + "                    break;" + NL + "                }" + NL + "            }" + NL + "" + NL + "\t\t\twritableSheet_";
  protected final String TEXT_49 = " = writeableWorkbook_";
  protected final String TEXT_50 = ".createSheet(";
  protected final String TEXT_51 = ", writeableWorkbook_";
  protected final String TEXT_52 = ".getNumberOfSheets());" + NL + "        }";
  protected final String TEXT_53 = NL + NL + "        int startRowNum_";
  protected final String TEXT_54 = " = writableSheet_";
  protected final String TEXT_55 = ".getRows();" + NL;
  protected final String TEXT_56 = NL + "    \tfinal jxl.write.WritableCellFormat cell_format_";
  protected final String TEXT_57 = "_";
  protected final String TEXT_58 = "=new jxl.write.WritableCellFormat(new jxl.write.DateFormat(";
  protected final String TEXT_59 = "));";
  protected final String TEXT_60 = NL + "\t\tif(true){" + NL + "\t\t\tthrow new RuntimeException(\"Date pattern must be set for column ";
  protected final String TEXT_61 = " in the schema of component ";
  protected final String TEXT_62 = "!\");" + NL + "\t\t}";
  protected final String TEXT_63 = "\t\t" + NL + NL;
  protected final String TEXT_64 = NL + "\t\tif (startRowNum_";
  protected final String TEXT_65 = "==0){";
  protected final String TEXT_66 = NL + "\t\t\t\twritableSheet_";
  protected final String TEXT_67 = ".addCell(new jxl.write.Label(";
  protected final String TEXT_68 = ", nb_line_";
  protected final String TEXT_69 = ", \"";
  protected final String TEXT_70 = "\"));\t\t";
  protected final String TEXT_71 = NL + "\t\t\t\tnb_line_";
  protected final String TEXT_72 = "++;" + NL + "\t\t}";
  protected final String TEXT_73 = NL + "\t\t";
  protected final String TEXT_74 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();

List<IMetadataTable> metadatas = node.getMetadataList();
if ((metadatas!=null)&&(metadatas.size()>0)) {
    IMetadataTable metadata = metadatas.get(0);
    if (metadata!=null) {
        String cid = node.getUniqueName();

        String filename = ElementParameterParser.getValue(node, "__FILENAME__");
        String sheetname = ElementParameterParser.getValue(node, "__SHEETNAME__");
        
        boolean isIncludeHeader = ElementParameterParser.getValue(node, "__INCLUDEHEADER__").equals("true");
        boolean isAppendFile = ElementParameterParser.getValue(node, "__APPEND_FILE__" ).equals("true");
        boolean isAppendSheet = ElementParameterParser.getValue(node, "__APPEND_SHEET__" ).equals("true");

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_4);
    stringBuffer.append(filename );
    stringBuffer.append(TEXT_5);
    if(ElementParameterParser.getValue(node,"__CREATE__").equals("true")){
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_10);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_11);
    }
    stringBuffer.append(TEXT_12);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_14);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_15);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_16);
    stringBuffer.append(ElementParameterParser.getValue(node,"__ENCODING__") );
    stringBuffer.append(TEXT_17);
    if(isAppendFile){
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_21);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_23);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_25);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_26);
    stringBuffer.append(filename);
    stringBuffer.append(TEXT_27);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_28);
    } else {
    stringBuffer.append(TEXT_29);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_30);
    stringBuffer.append(filename);
    stringBuffer.append(TEXT_31);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_32);
    }
    stringBuffer.append(TEXT_33);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_34);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_35);
    stringBuffer.append(sheetname );
    stringBuffer.append(TEXT_36);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_37);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_38);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_39);
    stringBuffer.append(sheetname );
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_41);
    if(isAppendFile && !isAppendSheet){
    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_43);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_45);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_46);
    stringBuffer.append(sheetname );
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_48);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_50);
    stringBuffer.append(sheetname );
    stringBuffer.append(TEXT_51);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_52);
    }
    stringBuffer.append(TEXT_53);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_54);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_55);
    
		List<IMetadataColumn> columns = metadata.getListColumns();
    	int sizeColumns = columns.size();
    	for (int i = 0; i < sizeColumns; i++) {
    		IMetadataColumn column = columns.get(i);
    		JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
    		if (javaType == JavaTypesManager.DATE){
    			String pattern = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
    			if(pattern != null && pattern.trim().length() != 0){
    stringBuffer.append(TEXT_56);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_57);
    stringBuffer.append( cid);
    stringBuffer.append(TEXT_58);
    stringBuffer.append(pattern );
    stringBuffer.append(TEXT_59);
    	    		}else{
    stringBuffer.append(TEXT_60);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_62);
    				}
			}
		
	    }

    stringBuffer.append(TEXT_63);
    if(isIncludeHeader){ 
    stringBuffer.append(TEXT_64);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_65);
    
    	for (int i = 0; i < sizeColumns; i++) {
    		IMetadataColumn column = columns.get(i);

    stringBuffer.append(TEXT_66);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_67);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_68);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_69);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_70);
     } 
    stringBuffer.append(TEXT_71);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_72);
     } 
    stringBuffer.append(TEXT_73);
    
    }
}

    stringBuffer.append(TEXT_74);
    return stringBuffer.toString();
  }
}
