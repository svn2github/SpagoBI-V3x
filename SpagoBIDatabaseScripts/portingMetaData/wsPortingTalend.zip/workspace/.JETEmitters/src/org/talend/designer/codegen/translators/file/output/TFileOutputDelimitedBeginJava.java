package org.talend.designer.codegen.translators.file.output;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;

public class TFileOutputDelimitedBeginJava
{
  protected static String nl;
  public static synchronized TFileOutputDelimitedBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileOutputDelimitedBeginJava result = new TFileOutputDelimitedBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "String fileName_";
  protected final String TEXT_3 = " = (new java.io.File(";
  protected final String TEXT_4 = ")).getAbsolutePath().replace(\"\\\\\",\"/\");" + NL + "String fullName_";
  protected final String TEXT_5 = " = null;" + NL + "String extension_";
  protected final String TEXT_6 = " = null;" + NL + "String directory_";
  protected final String TEXT_7 = " = null;" + NL + "if((fileName_";
  protected final String TEXT_8 = ".indexOf(\"/\") != -1)) {" + NL + "    if(fileName_";
  protected final String TEXT_9 = ".lastIndexOf(\".\") < fileName_";
  protected final String TEXT_10 = ".lastIndexOf(\"/\")) {" + NL + "        fullName_";
  protected final String TEXT_11 = " = fileName_";
  protected final String TEXT_12 = ";" + NL + "        extension_";
  protected final String TEXT_13 = " = \"\";" + NL + "    } else {" + NL + "        fullName_";
  protected final String TEXT_14 = " = fileName_";
  protected final String TEXT_15 = ".substring(0, fileName_";
  protected final String TEXT_16 = ".lastIndexOf(\".\"));" + NL + "        extension_";
  protected final String TEXT_17 = " = fileName_";
  protected final String TEXT_18 = ".substring(fileName_";
  protected final String TEXT_19 = ".lastIndexOf(\".\"));" + NL + "    }           " + NL + "    directory_";
  protected final String TEXT_20 = " = fileName_";
  protected final String TEXT_21 = ".substring(0, fileName_";
  protected final String TEXT_22 = ".lastIndexOf(\"/\"));            " + NL + "} else {" + NL + "    if(fileName_";
  protected final String TEXT_23 = ".lastIndexOf(\".\") != -1) {" + NL + "        fullName_";
  protected final String TEXT_24 = " = fileName_";
  protected final String TEXT_25 = ".substring(0, fileName_";
  protected final String TEXT_26 = ".lastIndexOf(\".\"));" + NL + "        extension_";
  protected final String TEXT_27 = " = fileName_";
  protected final String TEXT_28 = ".substring(fileName_";
  protected final String TEXT_29 = ".lastIndexOf(\".\"));" + NL + "    } else {" + NL + "        fullName_";
  protected final String TEXT_30 = " = fileName_";
  protected final String TEXT_31 = ";" + NL + "        extension_";
  protected final String TEXT_32 = " = \"\";" + NL + "    }" + NL + "    directory_";
  protected final String TEXT_33 = " = \"\";" + NL + "}";
  protected final String TEXT_34 = NL;
  protected final String TEXT_35 = NL + "    \t\tint nb_line_";
  protected final String TEXT_36 = " = 0;" + NL + "            int splitEvery_";
  protected final String TEXT_37 = " = ";
  protected final String TEXT_38 = ";" + NL + "            int splitedFileNo_";
  protected final String TEXT_39 = " = 0;" + NL + "            int currentRow_";
  protected final String TEXT_40 = " = 0;\t\t" + NL + "    \t\t" + NL + "    \t\tfinal String OUT_DELIM_";
  protected final String TEXT_41 = " = ";
  protected final String TEXT_42 = ";" + NL + "    \t\t" + NL + "    \t\tfinal String OUT_DELIM_ROWSEP_";
  protected final String TEXT_43 = " = ";
  protected final String TEXT_44 = ";" + NL + "    \t\t";
  protected final String TEXT_45 = "         " + NL + "                //create directory only if not exists" + NL + "                if(directory_";
  protected final String TEXT_46 = " != null && directory_";
  protected final String TEXT_47 = ".trim().length() != 0) {" + NL + "                    java.io.File dir_";
  protected final String TEXT_48 = " = new java.io.File(directory_";
  protected final String TEXT_49 = ");" + NL + "                    if(!dir_";
  protected final String TEXT_50 = ".exists()) {" + NL + "                        dir_";
  protected final String TEXT_51 = ".mkdirs();" + NL + "                    }" + NL + "                }";
  protected final String TEXT_52 = NL + "    " + NL + "    \t\t";
  protected final String TEXT_53 = "\t\t" + NL + "    \t\t    java.io.BufferedWriter out";
  protected final String TEXT_54 = " = new java.io.BufferedWriter(new java.io.OutputStreamWriter(" + NL + "            \t\tnew java.io.FileOutputStream(fileName_";
  protected final String TEXT_55 = ", ";
  protected final String TEXT_56 = "),";
  protected final String TEXT_57 = "));" + NL + "    \t\t    java.io.File file";
  protected final String TEXT_58 = " = new java.io.File(fileName_";
  protected final String TEXT_59 = ");" + NL + "    \t\t    ";
  protected final String TEXT_60 = NL + "                java.io.BufferedWriter out";
  protected final String TEXT_61 = " = new java.io.BufferedWriter(new java.io.OutputStreamWriter(" + NL + "                        new java.io.FileOutputStream(fullName_";
  protected final String TEXT_62 = " + splitedFileNo_";
  protected final String TEXT_63 = " + extension_";
  protected final String TEXT_64 = ", ";
  protected final String TEXT_65 = "),";
  protected final String TEXT_66 = "));" + NL + "                java.io.File file";
  protected final String TEXT_67 = " = new java.io.File(fullName_";
  protected final String TEXT_68 = " + splitedFileNo_";
  protected final String TEXT_69 = " + extension_";
  protected final String TEXT_70 = ");";
  protected final String TEXT_71 = NL + "            \t\t" + NL + "    \t\t";
  protected final String TEXT_72 = NL + "    \t\t    if(file";
  protected final String TEXT_73 = ".length()==0)  " + NL + "    \t\t    {" + NL + "    \t\t        ";
  protected final String TEXT_74 = NL + "    \t\t            out";
  protected final String TEXT_75 = ".write(\"";
  protected final String TEXT_76 = "\");" + NL + "    \t\t            ";
  protected final String TEXT_77 = NL + "    \t\t                out";
  protected final String TEXT_78 = ".write(OUT_DELIM_";
  protected final String TEXT_79 = ");" + NL + "    \t\t                ";
  protected final String TEXT_80 = NL + "    \t\t        out";
  protected final String TEXT_81 = ".write(OUT_DELIM_ROWSEP_";
  protected final String TEXT_82 = ");" + NL + "    \t\t    }\t" + NL + "    \t\t    ";
  protected final String TEXT_83 = NL;
  protected final String TEXT_84 = NL;
  protected final String TEXT_85 = "        " + NL + "            int nb_line_";
  protected final String TEXT_86 = " = 0;" + NL + "            int splitEvery_";
  protected final String TEXT_87 = " = ";
  protected final String TEXT_88 = ";" + NL + "            int splitedFileNo_";
  protected final String TEXT_89 = " =0;" + NL + "            int currentRow_";
  protected final String TEXT_90 = " = 0;";
  protected final String TEXT_91 = "         " + NL + "                //create directory only if not exists" + NL + "                if(directory_";
  protected final String TEXT_92 = " != null && directory_";
  protected final String TEXT_93 = ".trim().length() != 0) {" + NL + "                    java.io.File dir_";
  protected final String TEXT_94 = " = new java.io.File(directory_";
  protected final String TEXT_95 = ");" + NL + "                    if(!dir_";
  protected final String TEXT_96 = ".exists()) {" + NL + "                        dir_";
  protected final String TEXT_97 = ".mkdirs();" + NL + "                    }" + NL + "                }";
  protected final String TEXT_98 = NL + "                com.csvreader.CsvWriter CsvWriter";
  protected final String TEXT_99 = " = new com.csvreader.CsvWriter(new java.io.BufferedWriter(new java.io.OutputStreamWriter(" + NL + "                            new java.io.FileOutputStream(fileName_";
  protected final String TEXT_100 = ", ";
  protected final String TEXT_101 = "), ";
  protected final String TEXT_102 = ")), '";
  protected final String TEXT_103 = "');  " + NL + "                            java.io.File file_";
  protected final String TEXT_104 = "=new java.io.File(fileName_";
  protected final String TEXT_105 = ");   ";
  protected final String TEXT_106 = NL + "                com.csvreader.CsvWriter CsvWriter";
  protected final String TEXT_107 = " = new com.csvreader.CsvWriter(new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(fullName_";
  protected final String TEXT_108 = " + splitedFileNo_";
  protected final String TEXT_109 = " + extension_";
  protected final String TEXT_110 = ", ";
  protected final String TEXT_111 = "), ";
  protected final String TEXT_112 = ")), '";
  protected final String TEXT_113 = "');" + NL + "                java.io.File file_";
  protected final String TEXT_114 = " = new java.io.File(fullName_";
  protected final String TEXT_115 = " + splitedFileNo_";
  protected final String TEXT_116 = " + extension_";
  protected final String TEXT_117 = ");";
  protected final String TEXT_118 = NL + "    \t    String[] headColu";
  protected final String TEXT_119 = " = new String[";
  protected final String TEXT_120 = "];" + NL + "    \t    ";
  protected final String TEXT_121 = NL + "       \t\t\t\theadColu";
  protected final String TEXT_122 = "[";
  protected final String TEXT_123 = "]=\"";
  protected final String TEXT_124 = "\";" + NL + "       \t\t\t\t";
  protected final String TEXT_125 = NL + "        \t\tCsvWriter";
  protected final String TEXT_126 = ".writeRecord(headColu";
  protected final String TEXT_127 = ");\t" + NL + "        \t\t";
  protected final String TEXT_128 = "\t\t   " + NL + "    \t        if(file_";
  protected final String TEXT_129 = ".length()==0)  " + NL + "    \t        {" + NL + "    \t            ";
  protected final String TEXT_130 = "\t      \t" + NL + "        \t\t\t\theadColu";
  protected final String TEXT_131 = "[";
  protected final String TEXT_132 = "]=\"";
  protected final String TEXT_133 = "\";" + NL + "        \t\t\t\t";
  protected final String TEXT_134 = "\t " + NL + "    \t            CsvWriter";
  protected final String TEXT_135 = ".writeRecord(headColu";
  protected final String TEXT_136 = ");    \t" + NL + "    \t        }" + NL + "     " + NL + "    \t        ";
  protected final String TEXT_137 = NL + NL;
  protected final String TEXT_138 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
     
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();
String fileName = ElementParameterParser.getValue(node,"__FILENAME__");

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(fileName);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_21);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_23);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_25);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_26);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_28);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_29);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_30);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_31);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_32);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_33);
    
if(ElementParameterParser.getValue(node,"__CSV_OPTION__").equals("false")) {	
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    stringBuffer.append(TEXT_34);
    
    
    List<IMetadataTable> metadatas = node.getMetadataList();
    if ((metadatas!=null)&&(metadatas.size()>0)) {
        IMetadataTable metadata = metadatas.get(0);
        if (metadata!=null) {
            String fullName = null;
            String extensionName = null;
            String directoryName = null;    
            
            String fieldSeparator = ElementParameterParser.getValueWithUIFieldKey(
                node,
                "__FIELDSEPARATOR__",
                "FIELDSEPARATOR"
            );
            
            String rowSeparator = ElementParameterParser.getValueWithUIFieldKey(
                node,
                "__ROWSEPARATOR__",
                "ROWSEPARATOR"
            );
            
            String encoding = ElementParameterParser.getValue(
                node,
                "__ENCODING__"
            );
            
            boolean isAppend = ElementParameterParser.getValue(
                node,
                "__APPEND__"
            ).equals("true");
            
            boolean isIncludeHeader = ElementParameterParser.getValue(
                node,
                "__INCLUDEHEADER__"
            ).equals("true");
    		String fileNewname = ElementParameterParser.getValue(node,"__FILENAME__");
    		
    		boolean split = ElementParameterParser.getValue(node, "__SPLIT__").equals("true");
            String splitEvery = ElementParameterParser.getValue(node, "__SPLIT_EVERY__");
            
    stringBuffer.append(TEXT_35);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_36);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_37);
    stringBuffer.append(splitEvery );
    stringBuffer.append(TEXT_38);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_41);
    stringBuffer.append(fieldSeparator );
    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_43);
    stringBuffer.append(rowSeparator );
    stringBuffer.append(TEXT_44);
    
    		if(ElementParameterParser.getValue(node,"__CREATE__").equals("true")){
                
    stringBuffer.append(TEXT_45);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_46);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_48);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_50);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_51);
    
    		}
    		
    stringBuffer.append(TEXT_52);
     	
    		if(!split){
    		    
    stringBuffer.append(TEXT_53);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_54);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_55);
    stringBuffer.append(isAppend);
    stringBuffer.append(TEXT_56);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_57);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_58);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_59);
     
    		} else {
    		    
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_62);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_63);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_64);
    stringBuffer.append(isAppend);
    stringBuffer.append(TEXT_65);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_66);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_67);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_68);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_69);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    
    		}
    		
    stringBuffer.append(TEXT_71);
    
    		if(isIncludeHeader){
    		    
    stringBuffer.append(TEXT_72);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_73);
    		
    		        List<IMetadataColumn> columns = metadata.getListColumns();
    		        int sizeColumns = columns.size();
    		        for (int i = 0; i < sizeColumns; i++) {
    		            IMetadataColumn column = columns.get(i);
    		            
    stringBuffer.append(TEXT_74);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_75);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_76);
    
    		            if(i != sizeColumns - 1) {
    		                
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_78);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_79);
    
    		            }
    		        }
    		        
    stringBuffer.append(TEXT_80);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_81);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_82);
    
    		}
        }
    }
    
    stringBuffer.append(TEXT_83);
    
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}else{// the following is the tFileOutputCSV component
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    stringBuffer.append(TEXT_84);
    
    
    List<IMetadataTable> metadatas = node.getMetadataList();
    if ((metadatas!=null)&&(metadatas.size()>0)) {
        IMetadataTable metadata = metadatas.get(0);
        if (metadata!=null) {                        
            String encoding = ElementParameterParser.getValue(node,"__ENCODING__");
    		String delim1 = ElementParameterParser.getValue(node, "__FIELDSEPARATOR__");
        	String delim = delim1.substring(1,delim1.length()-1);
        	boolean isAppend = ElementParameterParser.getValue(node,"__APPEND__").equals("true");
        	boolean isIncludeHeader = ElementParameterParser.getValue(node,"__INCLUDEHEADER__").equals("true");
        	boolean split = ElementParameterParser.getValue(node, "__SPLIT__").equals("true");
            String splitEvery = ElementParameterParser.getValue(node, "__SPLIT_EVERY__");
            
    stringBuffer.append(TEXT_85);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_86);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_87);
    stringBuffer.append(splitEvery );
    stringBuffer.append(TEXT_88);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_89);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_90);
    
            if(ElementParameterParser.getValue(node,"__CREATE__").equals("true")){
                
    stringBuffer.append(TEXT_91);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_92);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_93);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_94);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_95);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_96);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_97);
    
            }
    	
            if(!split){
                
    stringBuffer.append(TEXT_98);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_99);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_100);
    stringBuffer.append(isAppend);
    stringBuffer.append(TEXT_101);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_102);
    stringBuffer.append(delim);
    stringBuffer.append(TEXT_103);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_104);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_105);
    
            }else{
                
    stringBuffer.append(TEXT_106);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_107);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_108);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_109);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_110);
    stringBuffer.append(isAppend);
    stringBuffer.append(TEXT_111);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_112);
    stringBuffer.append(delim);
    stringBuffer.append(TEXT_113);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_114);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_115);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_117);
    
            }
            List<IMetadataColumn> columns = metadata.getListColumns();
    	    int sizeColumns = columns.size();
    	    
    stringBuffer.append(TEXT_118);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_119);
    stringBuffer.append(sizeColumns);
    stringBuffer.append(TEXT_120);
     		
    	    if(isIncludeHeader && !isAppend)
    	    {
    	        for(int i = 0; i < sizeColumns; i++)
        		{
        			IMetadataColumn column = columns.get(i);
        			
    stringBuffer.append(TEXT_121);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_122);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_123);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_124);
    
        		}
    	        
    stringBuffer.append(TEXT_125);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_126);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_127);
    		
    	    }
    	    if(isIncludeHeader && isAppend)
    	    {
     		   
    	        
    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_129);
    			
         			for(int i = 0 ; i < sizeColumns ; i++)
        			{
        				IMetadataColumn column = columns.get(i);
        				
    stringBuffer.append(TEXT_130);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_131);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_132);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_133);
    
         			}
    	            
    stringBuffer.append(TEXT_134);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_135);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_136);
    		  
    	    } 
	    }
    }
    
    stringBuffer.append(TEXT_137);
    
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

    stringBuffer.append(TEXT_138);
    return stringBuffer.toString();
  }
}
