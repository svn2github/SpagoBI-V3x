package org.talend.designer.codegen.translators.common;

import org.talend.designer.codegen.config.NodesSubTree;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.process.INode;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.EConnectionType;
import org.talend.core.model.process.ElementParameterParser;
import java.util.List;
import java.util.Iterator;

public class Subprocess_footerJava
{
  protected static String nl;
  public static synchronized Subprocess_footerJava create(String lineSeparator)
  {
    nl = lineSeparator;
    Subprocess_footerJava result = new Subprocess_footerJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "\t\t";
  protected final String TEXT_3 = "Process();";
  protected final String TEXT_4 = NL + "\t";
  protected final String TEXT_5 = "Process();";
  protected final String TEXT_6 = NL + NL + "\t" + NL + "\t} catch(Exception e) {" + NL + "\t";
  protected final String TEXT_7 = NL + "\tthrow new TalendException(this, e, currentComponent);";
  protected final String TEXT_8 = "\t" + NL + "\t\tthrow new TalendException(this, e);";
  protected final String TEXT_9 = "\t\t" + NL + "\t}" + NL + "\t";
  protected final String TEXT_10 = NL + "\t\t\t\t";
  protected final String TEXT_11 = " finally{ ";
  protected final String TEXT_12 = NL + "\t\t\t\t//free memory for \"";
  protected final String TEXT_13 = "\"" + NL + "\t\t\t\tglobalMap.put(\"";
  protected final String TEXT_14 = "\", null);" + NL + "\t";
  protected final String TEXT_15 = NL + "     \t\t\t";
  protected final String TEXT_16 = " finally{ ";
  protected final String TEXT_17 = NL + "     \t\t\t//free memory for \"";
  protected final String TEXT_18 = "\"" + NL + "     \t\t\tglobalMap.put(\"tHash_Lookup_";
  protected final String TEXT_19 = "\", null); ";
  protected final String TEXT_20 = "      \t" + NL + "      \t\t\t";
  protected final String TEXT_21 = " finally{ ";
  protected final String TEXT_22 = NL + "      \t\t\t//free memory for \"";
  protected final String TEXT_23 = "\"" + NL + "\t\t\t\tglobalMap.put(\"tHash_";
  protected final String TEXT_24 = "\", null);";
  protected final String TEXT_25 = "\t\t" + NL + "\t\t\t\tSystem.gc();" + NL + "\t\t}\t\t" + NL + "\t";
  protected final String TEXT_26 = NL + "}";
  protected final String TEXT_27 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
	CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
	NodesSubTree subTree = (NodesSubTree) codeGenArgument.getArgument();
	boolean isRunInMultiThread = codeGenArgument.getIsRunInMultiThread();

    stringBuffer.append(TEXT_1);
    
	// Calls for RUN BEFORE links
	for (String before : subTree.getBeforeSubProcesses()) {

    stringBuffer.append(TEXT_2);
    stringBuffer.append(before );
    stringBuffer.append(TEXT_3);
    
	}
	
	if (subTree.getRootNode().getProcess().getNodesOfType("tFlowMeterCatcher").size() > 0 
		&& subTree.getRootNode().getProcess().getNodesOfType("tFlowMeter").size() >0 ) {
		List<INode> metterCatchers = (List<INode>)subTree.getRootNode().getProcess().getNodesOfType("tFlowMeterCatcher");
		List<INode> metters = (List<INode>)subTree.getRootNode().getProcess().getNodesOfType("tFlowMeter");
		List<INode> nodes = (List<INode>)subTree.getNodes();
		
		boolean hasMetterProcess = false;
		for(INode tmp : nodes)
		{
			for(INode metter : metters)
			{
				if(tmp.getUniqueName().equals(metter.getUniqueName()))
				{
					hasMetterProcess = true;
					break;
				}
			}
			if(hasMetterProcess)
			{
				break;
			}
		}
		if(hasMetterProcess)
		{
			for (INode metterCatcher : metterCatchers) {
				

    stringBuffer.append(TEXT_4);
    stringBuffer.append(metterCatcher.getUniqueName() );
    stringBuffer.append(TEXT_5);
          

			}
		}
	}

    stringBuffer.append(TEXT_6);
    
	if(isRunInMultiThread){

    stringBuffer.append(TEXT_7);
    
	}else{

    stringBuffer.append(TEXT_8);
    
	}

    stringBuffer.append(TEXT_9);
    
	//generate the code to free memory for lookup link and virtual component buffered datas 
	boolean firstIn = true;
	boolean needGc = false;
	List<INode> nodes = subTree.getNodes();
	for(INode node:nodes){
	
	boolean isVirtualGenerateNode = node.isVirtualGenerateNode();
	
	//check the virtual component generate node
	if(isVirtualGenerateNode){
		String origin  = ElementParameterParser.getValue(node, "__ORIGIN__");
		if(origin != null && !"".equals(origin)){
			if(!needGc) needGc = true;
	
    stringBuffer.append(TEXT_10);
    if(firstIn){
    stringBuffer.append(TEXT_11);
     firstIn = false;}
    stringBuffer.append(TEXT_12);
    stringBuffer.append(node.getUniqueName() );
    stringBuffer.append(TEXT_13);
    stringBuffer.append(origin );
    stringBuffer.append(TEXT_14);
    
		}
	}else{
	//check the Lookup link
		List<? extends IConnection> lookupInput = node.getIncomingConnections(EConnectionType.FLOW_REF);
		if(lookupInput!=null && lookupInput.size()>0){
			if(!needGc) needGc = true;
			//check the tMap like this, instanceof can't work			
			if(node.getClass().getName().equals("org.talend.designer.mapper.MapperComponent")){
				for(IConnection connection:lookupInput){						
     
    stringBuffer.append(TEXT_15);
    if(firstIn){
    stringBuffer.append(TEXT_16);
     firstIn = false;}
    stringBuffer.append(TEXT_17);
    stringBuffer.append(node.getUniqueName() );
    stringBuffer.append(TEXT_18);
    stringBuffer.append(connection.getName() );
    stringBuffer.append(TEXT_19);
    
            	}
            }else{
            	for(IConnection connection:lookupInput){
      
    stringBuffer.append(TEXT_20);
    if(firstIn){
    stringBuffer.append(TEXT_21);
     firstIn = false;}
    stringBuffer.append(TEXT_22);
    stringBuffer.append(node.getUniqueName() );
    stringBuffer.append(TEXT_23);
    stringBuffer.append(connection.getName() );
    stringBuffer.append(TEXT_24);
          		 
				} 
			} 
		}
	}
}

	if(needGc) {
	
    stringBuffer.append(TEXT_25);
    
		}
	
    stringBuffer.append(TEXT_26);
    stringBuffer.append(TEXT_27);
    return stringBuffer.toString();
  }
}
