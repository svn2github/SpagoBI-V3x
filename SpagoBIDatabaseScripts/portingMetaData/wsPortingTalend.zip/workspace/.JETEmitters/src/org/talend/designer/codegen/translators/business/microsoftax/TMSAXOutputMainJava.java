package org.talend.designer.codegen.translators.business.microsoftax;

import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;
import org.talend.core.model.process.IConnectionCategory;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedList;

public class TMSAXOutputMainJava
{
  protected static String nl;
  public static synchronized TMSAXOutputMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TMSAXOutputMainJava result = new TMSAXOutputMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "        ";
  protected final String TEXT_2 = " = null;            ";
  protected final String TEXT_3 = NL + "\trecord_";
  protected final String TEXT_4 = ".callMethod(\"ExecuteStmt\", new Object[] { ";
  protected final String TEXT_5 = "});";
  protected final String TEXT_6 = NL + "\trecord_";
  protected final String TEXT_7 = ".callMethod(\"InitValue\");";
  protected final String TEXT_8 = NL + "    whetherReject_";
  protected final String TEXT_9 = " = false;";
  protected final String TEXT_10 = NL + "\trecord_";
  protected final String TEXT_11 = ".put(\"field\",new Object[]{";
  protected final String TEXT_12 = ",";
  protected final String TEXT_13 = "});";
  protected final String TEXT_14 = NL + "    try{" + NL + "        record_";
  protected final String TEXT_15 = ".callMethod(\"Insert\");" + NL + "        insertedCount_";
  protected final String TEXT_16 = "++;" + NL + "        nb_line_";
  protected final String TEXT_17 = "++;" + NL + "    }catch(Exception e){" + NL + "        whetherReject_";
  protected final String TEXT_18 = " = true;";
  protected final String TEXT_19 = NL + "            throw(e);";
  protected final String TEXT_20 = NL + "            ";
  protected final String TEXT_21 = " = new ";
  protected final String TEXT_22 = "Struct();";
  protected final String TEXT_23 = NL + "            ";
  protected final String TEXT_24 = ".";
  protected final String TEXT_25 = " = ";
  protected final String TEXT_26 = ".";
  protected final String TEXT_27 = ";";
  protected final String TEXT_28 = NL + "            ";
  protected final String TEXT_29 = ".errorMessage = e.getMessage();";
  protected final String TEXT_30 = NL + "            System.err.print(e.getMessage());";
  protected final String TEXT_31 = NL + "    }";
  protected final String TEXT_32 = NL + "        try{" + NL + "            while(record_";
  protected final String TEXT_33 = ".get(\"Found\").getObjectAsBoolean()){";
  protected final String TEXT_34 = NL + "\t\t\t\trecord_";
  protected final String TEXT_35 = ".put(\"field\",new Object[]{";
  protected final String TEXT_36 = ",";
  protected final String TEXT_37 = "});";
  protected final String TEXT_38 = "\t" + NL + "\t\t\t\trecord_";
  protected final String TEXT_39 = ".callMethod(\"Update\");" + NL + "                record_";
  protected final String TEXT_40 = ".callMethod(\"Next\");" + NL + "                updatedCount_";
  protected final String TEXT_41 = "++;" + NL + "            }" + NL + "            nb_line_";
  protected final String TEXT_42 = "++;" + NL + "        }catch(Exception e){" + NL + "            whetherReject_";
  protected final String TEXT_43 = " = true;";
  protected final String TEXT_44 = NL + "                throw(e);";
  protected final String TEXT_45 = NL + "                    ";
  protected final String TEXT_46 = " = new ";
  protected final String TEXT_47 = "Struct();";
  protected final String TEXT_48 = NL + "                    ";
  protected final String TEXT_49 = ".";
  protected final String TEXT_50 = " = ";
  protected final String TEXT_51 = ".";
  protected final String TEXT_52 = ";";
  protected final String TEXT_53 = NL + "                    ";
  protected final String TEXT_54 = ".errorMessage = e.getMessage();";
  protected final String TEXT_55 = NL + "                    System.err.print(e.getMessage());";
  protected final String TEXT_56 = NL + "        }";
  protected final String TEXT_57 = NL + "\t\tif(record_";
  protected final String TEXT_58 = ".get(\"Found\").getObjectAsBoolean()){" + NL + "            try{" + NL + "\t\t\t\twhile(record_";
  protected final String TEXT_59 = ".get(\"Found\").getObjectAsBoolean()){";
  protected final String TEXT_60 = NL + "\t\t\t\t\trecord_";
  protected final String TEXT_61 = ".put(\"field\",new Object[]{";
  protected final String TEXT_62 = ",";
  protected final String TEXT_63 = "});";
  protected final String TEXT_64 = "\t" + NL + "\t\t\t\t\trecord_";
  protected final String TEXT_65 = ".callMethod(\"Update\");" + NL + "                \trecord_";
  protected final String TEXT_66 = ".callMethod(\"Next\");" + NL + "                \tupdatedCount_";
  protected final String TEXT_67 = "++;" + NL + "            \t}" + NL + "            }catch(Exception e){" + NL + "                whetherReject_";
  protected final String TEXT_68 = " = true;";
  protected final String TEXT_69 = NL + "                    throw(e);";
  protected final String TEXT_70 = NL + "                    ";
  protected final String TEXT_71 = " = new ";
  protected final String TEXT_72 = "Struct();";
  protected final String TEXT_73 = NL + "                            ";
  protected final String TEXT_74 = ".";
  protected final String TEXT_75 = " = ";
  protected final String TEXT_76 = ".";
  protected final String TEXT_77 = ";";
  protected final String TEXT_78 = NL + "                        ";
  protected final String TEXT_79 = ".errorMessage = e.getMessage();";
  protected final String TEXT_80 = NL + "                        System.err.print(e.getMessage());";
  protected final String TEXT_81 = NL + "            }" + NL + "\t\t}else{ //insert" + NL + "            try{";
  protected final String TEXT_82 = NL + "\t\t\t\trecord_";
  protected final String TEXT_83 = ".put(\"field\",new Object[]{";
  protected final String TEXT_84 = ",";
  protected final String TEXT_85 = "});";
  protected final String TEXT_86 = NL + "                record_";
  protected final String TEXT_87 = ".callMethod(\"Insert\");" + NL + "        \t\tinsertedCount_";
  protected final String TEXT_88 = "++;" + NL + "            }catch(Exception e)" + NL + "            {" + NL + "                whetherReject_";
  protected final String TEXT_89 = " = true;";
  protected final String TEXT_90 = NL + "                    throw(e);";
  protected final String TEXT_91 = NL + "                    ";
  protected final String TEXT_92 = " = new ";
  protected final String TEXT_93 = "Struct();";
  protected final String TEXT_94 = NL + "                    ";
  protected final String TEXT_95 = ".";
  protected final String TEXT_96 = " = ";
  protected final String TEXT_97 = ".";
  protected final String TEXT_98 = ";";
  protected final String TEXT_99 = NL + "                    ";
  protected final String TEXT_100 = ".errorMessage = e.getMessage();";
  protected final String TEXT_101 = NL + "                    System.err.print(e.getMessage());";
  protected final String TEXT_102 = NL + "            }" + NL + "\t\t}" + NL + "\t\tnb_line_";
  protected final String TEXT_103 = "++;";
  protected final String TEXT_104 = NL + "\t\tint updateFlag_";
  protected final String TEXT_105 = "=0;" + NL + "        try{" + NL + "       \t\twhile(record_";
  protected final String TEXT_106 = ".get(\"Found\").getObjectAsBoolean()){";
  protected final String TEXT_107 = NL + "\t\t\t\trecord_";
  protected final String TEXT_108 = ".put(\"field\",new Object[]{";
  protected final String TEXT_109 = ",";
  protected final String TEXT_110 = "});";
  protected final String TEXT_111 = "\t" + NL + "\t\t\t\trecord_";
  protected final String TEXT_112 = ".callMethod(\"Update\");" + NL + "                record_";
  protected final String TEXT_113 = ".callMethod(\"Next\");" + NL + "                updateFlag_";
  protected final String TEXT_114 = "++;" + NL + "                updatedCount_";
  protected final String TEXT_115 = "++;" + NL + "            }" + NL + "            nb_line_";
  protected final String TEXT_116 = "++;" + NL + "        }catch(Exception e)" + NL + "        {" + NL + "            whetherReject_";
  protected final String TEXT_117 = " = true;";
  protected final String TEXT_118 = NL + "                throw(e);";
  protected final String TEXT_119 = NL + "                ";
  protected final String TEXT_120 = " = new ";
  protected final String TEXT_121 = "Struct();";
  protected final String TEXT_122 = NL + "                ";
  protected final String TEXT_123 = ".";
  protected final String TEXT_124 = " = ";
  protected final String TEXT_125 = ".";
  protected final String TEXT_126 = ";";
  protected final String TEXT_127 = NL + "                ";
  protected final String TEXT_128 = ".errorMessage = e.getMessage();";
  protected final String TEXT_129 = NL + "                    System.err.print(e.getMessage());";
  protected final String TEXT_130 = NL + "        }" + NL + "        if(updateFlag_";
  protected final String TEXT_131 = " == 0) {" + NL + "            try{";
  protected final String TEXT_132 = NL + "\t\t\t\trecord_";
  protected final String TEXT_133 = ".put(\"field\",new Object[]{";
  protected final String TEXT_134 = ",";
  protected final String TEXT_135 = "});";
  protected final String TEXT_136 = NL + "                record_";
  protected final String TEXT_137 = ".callMethod(\"Insert\");" + NL + "        \t\tinsertedCount_";
  protected final String TEXT_138 = "++;" + NL + "            }catch(Exception e){" + NL + "                whetherReject_";
  protected final String TEXT_139 = " = true;";
  protected final String TEXT_140 = NL + "                    throw(e);";
  protected final String TEXT_141 = NL + "                    ";
  protected final String TEXT_142 = ".";
  protected final String TEXT_143 = " = ";
  protected final String TEXT_144 = ".";
  protected final String TEXT_145 = ";";
  protected final String TEXT_146 = NL + "                    ";
  protected final String TEXT_147 = ".errorMessage = e.getMessage();";
  protected final String TEXT_148 = NL + "                    System.err.print(e.getMessage());";
  protected final String TEXT_149 = NL + "            }" + NL + "        }" + NL + "        nb_line_";
  protected final String TEXT_150 = "++;";
  protected final String TEXT_151 = NL + "    try{" + NL + "\t    while(record_";
  protected final String TEXT_152 = ".get(\"Found\").getObjectAsBoolean()){" + NL + "\t\t\trecord_";
  protected final String TEXT_153 = ".callMethod(\"Delete\");" + NL + "            record_";
  protected final String TEXT_154 = ".callMethod(\"Next\");" + NL + "            updatedCount_";
  protected final String TEXT_155 = "++;" + NL + "        }" + NL + "    }catch(Exception e){" + NL + "        whetherReject_";
  protected final String TEXT_156 = " = true;";
  protected final String TEXT_157 = NL + "            throw(e);";
  protected final String TEXT_158 = NL + "            ";
  protected final String TEXT_159 = " = new ";
  protected final String TEXT_160 = "Struct();";
  protected final String TEXT_161 = NL + "            ";
  protected final String TEXT_162 = ".";
  protected final String TEXT_163 = " = ";
  protected final String TEXT_164 = ".";
  protected final String TEXT_165 = ";";
  protected final String TEXT_166 = NL + "            ";
  protected final String TEXT_167 = ".errorMessage = e.getMessage();";
  protected final String TEXT_168 = NL + "                System.err.print(e.getMessage());";
  protected final String TEXT_169 = NL + "    }" + NL + "    nb_line_";
  protected final String TEXT_170 = "++;";
  protected final String TEXT_171 = NL + "        if(!whetherReject_";
  protected final String TEXT_172 = ") {";
  protected final String TEXT_173 = NL + "        \t";
  protected final String TEXT_174 = " = new ";
  protected final String TEXT_175 = "Struct();";
  protected final String TEXT_176 = NL + "       \t\t";
  protected final String TEXT_177 = ".";
  protected final String TEXT_178 = " = ";
  protected final String TEXT_179 = ".";
  protected final String TEXT_180 = ";";
  protected final String TEXT_181 = NL + "        }";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
	CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
	INode node = (INode)codeGenArgument.getArgument();
	String cid = node.getUniqueName();
	
	String dataAction = ElementParameterParser.getValue(node,"__DATA_ACTION__");
    String dieOnError = ElementParameterParser.getValue(node, "__DIE_ON_ERROR__");
	String axTable = ElementParameterParser.getValue(node,"__DBTABLE__");
	
	List<Map<String, String>> addCols =
            (List<Map<String,String>>)ElementParameterParser.getObjectValue(node,"__ADD_COLS__");

	String incomingConnName = null;
	List<IMetadataColumn> columnList = null;
	
	List< ? extends IConnection> conns = node.getIncomingConnections();
	if(conns!=null && conns.size()>0){
		IConnection conn = conns.get(0);
		incomingConnName = conn.getName();
	}
	
	List<IMetadataTable> metadatas = node.getMetadataList();
	if(metadatas != null && metadatas.size()>0){
		IMetadataTable metadata = metadatas.get(0);
		if(metadata != null){
			columnList = metadata.getListColumns();
		}
	}
	
	String rejectConnName = null;
	List<? extends IConnection> rejectConns = node.getOutgoingConnections("REJECT");
	if(rejectConns != null && rejectConns.size() > 0) {
	    IConnection rejectConn = rejectConns.get(0);
	    rejectConnName = rejectConn.getName();
	}
	List<IMetadataColumn> rejectColumnList = null;
	IMetadataTable metadataTable = node.getMetadataFromConnector("REJECT");
	if(metadataTable != null) {
	    rejectColumnList = metadataTable.getListColumns();
	}
	
	List<? extends IConnection> outgoingConns = node.getOutgoingSortedConnections();
    for(IConnection conn : outgoingConns) {
        if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {

    stringBuffer.append(TEXT_1);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_2);
          }
    }

class Column{
	IMetadataColumn column;
	String name;
	String dataType;
	String operator;
	String DBname;
	String value;
	boolean addCol;
	List<Column> replacement = new ArrayList<Column>();
	
	public Column(String colName,String value,boolean addCol, String dataType){
		this.column = null;
		this.name=colName;
		this.DBname = colName;
		this.value = value;
		this.addCol =addCol;
		this.dataType = dataType;
	}
	
	public Column(IMetadataColumn column, String rowName){
		this.column = column;
		this.name = column.getLabel();
		this.value =rowName+"."+name;
		this.addCol =false;
		this.DBname=column.getOriginalDbColumnName();
		this.dataType=JavaTypesManager.getTypeToGenerate(column.getTalendType(), column.isNullable());
	}

	public boolean isReplaced(){
		return replacement.size()>0;
	}
	
	public void replace(Column column){
		this.replacement.add(column);
	}
	
	public List<Column> getReplacement(){
		return this.replacement;
	}
}

class VariantTool{
	public String vStr(String value){
		return "new org.jinterop.dcom.core.JIVariant(new org.jinterop.dcom.core.JIString("+value+"))";
	}

	public String vCulomnVale(Column column,String rowName){
		if(column.dataType.equals("String")){
			return vStr(column.value);
		}else if(column.dataType.equals("Int") || column.dataType.equals("Float") || column.dataType.equals("Double")
			|| column.dataType.equals("Short") || column.dataType.equals("Char") || column.dataType.equals("Object")
			|| column.dataType.equals("Date") || column.dataType.equals("Boolean")){
			return "new org.jinterop.dcom.core.JIVariant("+column.value+")";
		}
		return "new org.jinterop.dcom.core.JIVariant.EMPTY";
	}
}
VariantTool vTool = new VariantTool();

List<Column> stmtStructure =  new LinkedList<Column>();
for(IMetadataColumn column:columnList){
    Column myColumn = new Column(column,incomingConnName);
    myColumn.operator = "==";
	stmtStructure.add(myColumn);
}

for(IMetadataColumn column:columnList){
	if(addCols != null && addCols.size()>0){
		for(Map<String, String> addCol:addCols){
			if(addCol.get("REFCOL").equals(column.getLabel())){
				int stmtIndex = 0;
				for(Column stmtStr:stmtStructure){					
					if(stmtStr.name.equals(addCol.get("REFCOL"))){
						break;
					}
					stmtIndex++;
				}
				
				if(addCol.get("POS").equals("AFTER")){
					Column insertAfter = new Column(addCol.get("NAME").replaceAll("\"",""),addCol.get("SQL"),true,addCol.get("DATATYPE"));
					insertAfter.dataType = addCol.get("DATATYPE");
					insertAfter.operator = addCol.get("OPERATOR");
					stmtStructure.add(stmtIndex+1,insertAfter);
				}else if(addCol.get("POS").equals("BEFORE")){
					Column insertBefore = new Column(addCol.get("NAME").replaceAll("\"",""),addCol.get("SQL"),true,addCol.get("DATATYPE"));
					insertBefore.dataType = addCol.get("DATATYPE");
					insertBefore.operator = addCol.get("OPERATOR");
					stmtStructure.add(stmtIndex,insertBefore);
				}else if(addCol.get("POS").equals("REPLACE")){
					Column replacementCol = new Column(addCol.get("NAME").replaceAll("\"",""),addCol.get("SQL"),true,addCol.get("DATATYPE"));
					replacementCol.dataType = addCol.get("DATATYPE");
					replacementCol.operator = addCol.get("OPERATOR");
					Column replacedCol = (Column) stmtStructure.get(stmtIndex);
					replacedCol.replace(replacementCol);
				}
			}
		}
	}
}

List<Column> insertValueList = new LinkedList<Column>();
List<Column> updateValueList = new LinkedList<Column>();
StringBuilder whereStmt = new StringBuilder();
for(Column column : stmtStructure) {
    if(column.isReplaced()) {
        List<Column> replacedColumns = column.getReplacement();          
        for(Column replacedColumn : replacedColumns) {
			insertValueList.add(replacedColumn);
            if(column.column.isKey()) {
            	if(whereStmt.length()>0){
            		whereStmt.append(" && ");
            		whereStmt.append("%1." + replacedColumn.name + " " + replacedColumn.operator + " \\\"\"+" + replacedColumn.value + "+\"\\\"" );
            	}else{
            		whereStmt.append(" %1." + replacedColumn.name + " " + replacedColumn.operator + " \\\"\"+" + replacedColumn.value+ "+\"\\\"");
            	}
            } else {
                updateValueList.add(replacedColumn);
            }
        }
    } else {
        if(column.addCol) {
            insertValueList.add(column);
			updateValueList.add(column);
        } else {
            insertValueList.add(column);
            if(column.column.isKey()) {
            	if(whereStmt.length()>0){
            		whereStmt.append(" && ");
            		whereStmt.append("%1." + column.name + " " + column.operator + " \\\"\"+" + column.value+"+\"\\\"");
            	}else{
            		whereStmt.append(" %1." + column.name + " " + column.operator + " \\\"\"+" + column.value+"+\"\\\"");
            	}
            } else {
                updateValueList.add(column);
            }
        }
    }
}

//select recode
if(!dataAction.equals("INSERT")){
	String executeStmt = "\"select forupdate %1 where"+whereStmt.toString()+"\"";

    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(vTool.vStr(executeStmt));
    stringBuffer.append(TEXT_5);
    
}else{

    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_7);
    
}



if(incomingConnName != null && columnList != null){

    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_9);
    
    if(dataAction.equals("INSERT")){
		for(Column column : insertValueList){

    stringBuffer.append(TEXT_10);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(vTool.vStr("\""+column.name+"\""));
    stringBuffer.append(TEXT_12);
    stringBuffer.append(vTool.vCulomnVale(column,incomingConnName));
    stringBuffer.append(TEXT_13);
    
		}

    stringBuffer.append(TEXT_14);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_18);
    
        if (dieOnError.equals("true")) {

    stringBuffer.append(TEXT_19);
    
        } else {
            if(rejectConnName != null && rejectColumnList != null && rejectColumnList.size() > 0) {

    stringBuffer.append(TEXT_20);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_21);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_22);
    
                for(IMetadataColumn column : columnList) {

    stringBuffer.append(TEXT_23);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_25);
    stringBuffer.append(incomingConnName);
    stringBuffer.append(TEXT_26);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_27);
    
                }

    stringBuffer.append(TEXT_28);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_29);
    
            } else {

    stringBuffer.append(TEXT_30);
    
            }
        } 

    stringBuffer.append(TEXT_31);
    
	}else if(dataAction.equals("UPDATE")){

    stringBuffer.append(TEXT_32);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_33);
    
		for(Column column : updateValueList){

    stringBuffer.append(TEXT_34);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_35);
    stringBuffer.append(vTool.vStr("\""+column.name+"\""));
    stringBuffer.append(TEXT_36);
    stringBuffer.append(vTool.vCulomnVale(column,incomingConnName));
    stringBuffer.append(TEXT_37);
    
		}

    stringBuffer.append(TEXT_38);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_43);
    
            if (dieOnError.equals("true")) {

    stringBuffer.append(TEXT_44);
    
            } else {
                if(rejectConnName != null && rejectColumnList != null && rejectColumnList.size() > 0) {

    stringBuffer.append(TEXT_45);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_46);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_47);
    
                    for(IMetadataColumn column : columnList) {

    stringBuffer.append(TEXT_48);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_50);
    stringBuffer.append(incomingConnName);
    stringBuffer.append(TEXT_51);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_52);
    
                    }

    stringBuffer.append(TEXT_53);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_54);
    
                } else {

    stringBuffer.append(TEXT_55);
    
                }
            } 

    stringBuffer.append(TEXT_56);
    
	}else if (dataAction.equals("INSERT_OR_UPDATE")){

    stringBuffer.append(TEXT_57);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_58);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_59);
    
		for(Column column : updateValueList){

    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_61);
    stringBuffer.append(vTool.vStr("\""+column.name+"\""));
    stringBuffer.append(TEXT_62);
    stringBuffer.append(vTool.vCulomnVale(column,incomingConnName));
    stringBuffer.append(TEXT_63);
    
		}

    stringBuffer.append(TEXT_64);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_65);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_66);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_67);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_68);
    
                if (dieOnError.equals("true")) {

    stringBuffer.append(TEXT_69);
    
                } else {
                    if(rejectConnName != null && rejectColumnList != null && rejectColumnList.size() > 0) {

    stringBuffer.append(TEXT_70);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_71);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_72);
    
                        for(IMetadataColumn column : columnList) {

    stringBuffer.append(TEXT_73);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_74);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_75);
    stringBuffer.append(incomingConnName);
    stringBuffer.append(TEXT_76);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_77);
    
                        }

    stringBuffer.append(TEXT_78);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_79);
    
                    } else {

    stringBuffer.append(TEXT_80);
    
                    }
                }

    stringBuffer.append(TEXT_81);
    
			for(Column column : insertValueList){

    stringBuffer.append(TEXT_82);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_83);
    stringBuffer.append(vTool.vStr("\""+column.name+"\""));
    stringBuffer.append(TEXT_84);
    stringBuffer.append(vTool.vCulomnVale(column,incomingConnName));
    stringBuffer.append(TEXT_85);
    
			}

    stringBuffer.append(TEXT_86);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_87);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_88);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_89);
    
                if (dieOnError.equals("true")) {

    stringBuffer.append(TEXT_90);
    
                } else {
                    if(rejectConnName != null && rejectColumnList != null && rejectColumnList.size() > 0) {

    stringBuffer.append(TEXT_91);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_92);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_93);
    
                        for(IMetadataColumn column : columnList) {

    stringBuffer.append(TEXT_94);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_95);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_96);
    stringBuffer.append(incomingConnName);
    stringBuffer.append(TEXT_97);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_98);
    
                        }

    stringBuffer.append(TEXT_99);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_100);
    
                    } else {

    stringBuffer.append(TEXT_101);
    
                    }
                }

    stringBuffer.append(TEXT_102);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_103);
    
	}else if (dataAction.equals("UPDATE_OR_INSERT")){

    stringBuffer.append(TEXT_104);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_105);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_106);
    
		for(Column column : updateValueList){

    stringBuffer.append(TEXT_107);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_108);
    stringBuffer.append(vTool.vStr("\""+column.name+"\""));
    stringBuffer.append(TEXT_109);
    stringBuffer.append(vTool.vCulomnVale(column,incomingConnName));
    stringBuffer.append(TEXT_110);
    
		}

    stringBuffer.append(TEXT_111);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_112);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_113);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_114);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_115);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_117);
    
            if (dieOnError.equals("true")) {

    stringBuffer.append(TEXT_118);
    
            } else {
                if(rejectConnName != null && rejectColumnList != null && rejectColumnList.size() > 0) {

    stringBuffer.append(TEXT_119);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_120);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_121);
    
                    for(IMetadataColumn column : columnList) {

    stringBuffer.append(TEXT_122);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_123);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_124);
    stringBuffer.append(incomingConnName);
    stringBuffer.append(TEXT_125);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_126);
    
                    }

    stringBuffer.append(TEXT_127);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_128);
    
                } else {

    stringBuffer.append(TEXT_129);
    
                }
            }

    stringBuffer.append(TEXT_130);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_131);
    
			for(Column column : insertValueList){

    stringBuffer.append(TEXT_132);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_133);
    stringBuffer.append(vTool.vStr("\""+column.name+"\""));
    stringBuffer.append(TEXT_134);
    stringBuffer.append(vTool.vCulomnVale(column,incomingConnName));
    stringBuffer.append(TEXT_135);
    
			}

    stringBuffer.append(TEXT_136);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_137);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_138);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_139);
    
                if (dieOnError.equals("true")) {

    stringBuffer.append(TEXT_140);
    
                } else {
                    if(rejectConnName != null && rejectColumnList != null && rejectColumnList.size() > 0) {
                        for(IMetadataColumn column : columnList) {

    stringBuffer.append(TEXT_141);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_142);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_143);
    stringBuffer.append(incomingConnName);
    stringBuffer.append(TEXT_144);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_145);
    
                        }

    stringBuffer.append(TEXT_146);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_147);
    
                    } else {

    stringBuffer.append(TEXT_148);
    
                    }
                }

    stringBuffer.append(TEXT_149);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_150);
    
	}else if (dataAction.equals("DELETE")){

    stringBuffer.append(TEXT_151);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_152);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_153);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_154);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_155);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_156);
    
        if (dieOnError.equals("true")) {

    stringBuffer.append(TEXT_157);
    
        } else {
            if(rejectConnName != null && rejectColumnList != null && rejectColumnList.size() > 0) {

    stringBuffer.append(TEXT_158);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_159);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_160);
    
                for(IMetadataColumn column : columnList) {

    stringBuffer.append(TEXT_161);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_162);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_163);
    stringBuffer.append(incomingConnName);
    stringBuffer.append(TEXT_164);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_165);
    
            	}

    stringBuffer.append(TEXT_166);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_167);
    
            } else {

    stringBuffer.append(TEXT_168);
    
            }
        }

    stringBuffer.append(TEXT_169);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_170);
    
	}
	
    if(outgoingConns != null && outgoingConns.size() > 0) {
        
    stringBuffer.append(TEXT_171);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_172);
    
            for(IConnection outgoingConn : outgoingConns) {
                if(rejectConnName == null || (rejectConnName != null && !outgoingConn.getName().equals(rejectConnName))) {
                    if(outgoingConn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {

    stringBuffer.append(TEXT_173);
    stringBuffer.append(outgoingConn.getName());
    stringBuffer.append(TEXT_174);
    stringBuffer.append(outgoingConn.getName());
    stringBuffer.append(TEXT_175);
    
                        for(IMetadataColumn column : columnList) {

    stringBuffer.append(TEXT_176);
    stringBuffer.append(outgoingConn.getName());
    stringBuffer.append(TEXT_177);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_178);
    stringBuffer.append(incomingConnName);
    stringBuffer.append(TEXT_179);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_180);
    
                        }
                    }
                }
            }

    stringBuffer.append(TEXT_181);
    
    }
}

    return stringBuffer.toString();
  }
}
