package org.talend.designer.codegen.translators.file.management;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;

public class TFileListBeginJava
{
  protected static String nl;
  public static synchronized TFileListBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileListBeginJava result = new TFileListBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "//tFileList_Begin";
  protected final String TEXT_2 = NL + NL + "    String directory_";
  protected final String TEXT_3 = " = ";
  protected final String TEXT_4 = ";" + NL + "    String filemask_";
  protected final String TEXT_5 = " = ";
  protected final String TEXT_6 = " + \"$\";" + NL + "    if(filemask_";
  protected final String TEXT_7 = ".indexOf(\"^\") == -1) " + NL + "    {" + NL + "        filemask_";
  protected final String TEXT_8 = " = \"^\" + filemask_";
  protected final String TEXT_9 = ";" + NL + "    }" + NL + "    filemask_";
  protected final String TEXT_10 = " = java.util.regex.Pattern.compile(\"[*]\").matcher(filemask_";
  protected final String TEXT_11 = ").replaceAll(\".*\");" + NL + "   " + NL + "    boolean case_sensitive_";
  protected final String TEXT_12 = " = ";
  protected final String TEXT_13 = ";" + NL + "\tjava.util.regex.Pattern fileNamePattern_";
  protected final String TEXT_14 = " = java.util.regex.Pattern.compile(filemask_";
  protected final String TEXT_15 = ");" + NL + "\tif(!case_sensitive_";
  protected final String TEXT_16 = "){" + NL + "    \tfileNamePattern_";
  protected final String TEXT_17 = " = java.util.regex.Pattern.compile(filemask_";
  protected final String TEXT_18 = ", java.util.regex.Pattern.CASE_INSENSITIVE);" + NL + "\t}       " + NL + "\tjava.io.File file_";
  protected final String TEXT_19 = " = new java.io.File(directory_";
  protected final String TEXT_20 = ");" + NL + "    final java.util.List<java.io.File> list_";
  protected final String TEXT_21 = " = new java.util.ArrayList<java.io.File>(); ";
  protected final String TEXT_22 = NL + "        file_";
  protected final String TEXT_23 = ".listFiles(new java.io.FilenameFilter() {" + NL + "            public boolean accept(java.io.File dir, String name) {" + NL + "                java.io.File file = new java.io.File(dir, name);";
  protected final String TEXT_24 = NL + "                    if(!file.isDirectory()) {" + NL + "                        list_";
  protected final String TEXT_25 = ".add(file);" + NL + "                        return true;" + NL + "                    } else {" + NL + "                        file.listFiles(this);" + NL + "                    }";
  protected final String TEXT_26 = NL + "                    if(!file.isDirectory()) {" + NL + "                        return true;" + NL + "                    } else {" + NL + "                        list_";
  protected final String TEXT_27 = ".add(file);" + NL + "                        file.listFiles(this);" + NL + "                    }";
  protected final String TEXT_28 = NL + "                    if(!file.isDirectory()) {" + NL + "                        list_";
  protected final String TEXT_29 = ".add(file);" + NL + "                    } else {" + NL + "                        list_";
  protected final String TEXT_30 = ".add(file);" + NL + "                        file.listFiles(this);" + NL + "                    }";
  protected final String TEXT_31 = NL + "                return false;" + NL + "            }" + NL + "        });";
  protected final String TEXT_32 = " " + NL + "         file_";
  protected final String TEXT_33 = ".listFiles(new java.io.FilenameFilter() {" + NL + "             public boolean accept(java.io.File dir, String name) {" + NL + "                 java.io.File file = new java.io.File(dir, name);";
  protected final String TEXT_34 = NL + "                     if(!file.isDirectory()) {" + NL + "                         list_";
  protected final String TEXT_35 = ".add(file);" + NL + "                     }";
  protected final String TEXT_36 = NL + "                     if(file.isDirectory()) {" + NL + "                         list_";
  protected final String TEXT_37 = ".add(file);" + NL + "                     }";
  protected final String TEXT_38 = NL + "                     list_";
  protected final String TEXT_39 = ".add(file);";
  protected final String TEXT_40 = NL + "                 return true;" + NL + "             }" + NL + "         });";
  protected final String TEXT_41 = " " + NL + "    int NB_FILE";
  protected final String TEXT_42 = " = 0;" + NL + "    for (int i_";
  protected final String TEXT_43 = " = 0; i_";
  protected final String TEXT_44 = " < list_";
  protected final String TEXT_45 = ".size() ; i_";
  protected final String TEXT_46 = "++){" + NL + "        " + NL + "        java.io.File files_";
  protected final String TEXT_47 = " =list_";
  protected final String TEXT_48 = ".get(i_";
  protected final String TEXT_49 = ");" + NL + "        String fileName_";
  protected final String TEXT_50 = " = files_";
  protected final String TEXT_51 = ".getName();" + NL + "" + NL + "        if(!fileNamePattern_";
  protected final String TEXT_52 = ".matcher(fileName_";
  protected final String TEXT_53 = ").find()){" + NL + "            continue;" + NL + "        }" + NL + "       " + NL + "        String currentFileName_";
  protected final String TEXT_54 = " = files_";
  protected final String TEXT_55 = ".getName(); " + NL + "        String currentFilePath_";
  protected final String TEXT_56 = " = files_";
  protected final String TEXT_57 = ".getAbsolutePath();" + NL + "        NB_FILE";
  protected final String TEXT_58 = "++;" + NL + "        " + NL + "        globalMap.put(\"";
  protected final String TEXT_59 = "_CURRENT_FILE\", currentFileName_";
  protected final String TEXT_60 = ");" + NL + "        globalMap.put(\"";
  protected final String TEXT_61 = "_CURRENT_FILEPATH\", currentFilePath_";
  protected final String TEXT_62 = ");";
  protected final String TEXT_63 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
	CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
	INode node = (INode)codeGenArgument.getArgument();
	String cid = node.getUniqueName();
    boolean incldSubdir = ElementParameterParser.getValue(node, "__INCLUDSUBDIR__").equals("true");
    String filelistType = ElementParameterParser.getValue(node, "__LIST_MODE__");

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(ElementParameterParser.getValue(node, "__DIRECTORY__") );
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(ElementParameterParser.getValue(node, "__FILEMASK__"));
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(ElementParameterParser.getValue(node, "__CASE_SENSITIVE__").equals("YES") );
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_21);
    
    if(incldSubdir) {
    
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_23);
    
                if(filelistType.equals("FILES")) {
                    
    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_25);
    
                } else if(filelistType.equals("DIRECTORIES")) {
                    
    stringBuffer.append(TEXT_26);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_27);
    
                } else if(filelistType.equals("BOTH")) {
                    
    stringBuffer.append(TEXT_28);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_29);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_30);
    
                }
                
    stringBuffer.append(TEXT_31);
    } 
    else 
    {
    stringBuffer.append(TEXT_32);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_33);
    
                 if(filelistType.equals("FILES")) {
                     
    stringBuffer.append(TEXT_34);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_35);
    
                 } else if(filelistType.equals("DIRECTORIES")) {
                     
    stringBuffer.append(TEXT_36);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_37);
    
                 } else if(filelistType.equals("BOTH")) {
                     
    stringBuffer.append(TEXT_38);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    
                 }
                 
    stringBuffer.append(TEXT_40);
    
    }
    
    stringBuffer.append(TEXT_41);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_43);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_45);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_46);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_48);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_50);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_51);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_52);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_53);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_54);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_55);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_56);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_57);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_58);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_59);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_62);
    stringBuffer.append(TEXT_63);
    return stringBuffer.toString();
  }
}
