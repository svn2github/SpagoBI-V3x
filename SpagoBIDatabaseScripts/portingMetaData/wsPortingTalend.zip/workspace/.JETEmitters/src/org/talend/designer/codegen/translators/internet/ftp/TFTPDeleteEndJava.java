package org.talend.designer.codegen.translators.internet.ftp;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;

public class TFTPDeleteEndJava
{
  protected static String nl;
  public static synchronized TFTPDeleteEndJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFTPDeleteEndJava result = new TFTPDeleteEndJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "    session";
  protected final String TEXT_2 = ".disconnect(); " + NL + "    ";
  protected final String TEXT_3 = NL + NL + "\tftp";
  protected final String TEXT_4 = ".quit();" + NL + "\t";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
	CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
	INode node = (INode)codeGenArgument.getArgument();
	String cid = node.getUniqueName();
	boolean sftp = ElementParameterParser.getValue(node, "__SFTP__").equals("true");
	
	if(sftp){

    stringBuffer.append(TEXT_1);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_2);
    }else{
    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_4);
    }
    return stringBuffer.toString();
  }
}
