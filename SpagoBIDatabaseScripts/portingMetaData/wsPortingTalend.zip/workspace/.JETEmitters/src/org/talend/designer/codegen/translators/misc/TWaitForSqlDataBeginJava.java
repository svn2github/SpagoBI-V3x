package org.talend.designer.codegen.translators.misc;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.designer.codegen.config.CodeGeneratorArgument;

public class TWaitForSqlDataBeginJava
{
  protected static String nl;
  public static synchronized TWaitForSqlDataBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TWaitForSqlDataBeginJava result = new TWaitForSqlDataBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "String sqlStr_";
  protected final String TEXT_3 = " = \"";
  protected final String TEXT_4 = "\"+";
  protected final String TEXT_5 = ";" + NL + "java.sql.Connection connection_";
  protected final String TEXT_6 = " = (java.sql.Connection)globalMap.get(\"";
  protected final String TEXT_7 = "\");" + NL + "java.sql.Statement statement_";
  protected final String TEXT_8 = " = connection_";
  protected final String TEXT_9 = ".createStatement();" + NL + "int count_";
  protected final String TEXT_10 = " = 0;" + NL + "int rowCount_";
  protected final String TEXT_11 = "=0;" + NL + "while (true) {";
  protected final String TEXT_12 = NL + "    if(";
  protected final String TEXT_13 = " == count_";
  protected final String TEXT_14 = ")" + NL + "    {" + NL + "    \tbreak;" + NL + "    }";
  protected final String TEXT_15 = NL + "    statement_";
  protected final String TEXT_16 = ".execute(sqlStr_";
  protected final String TEXT_17 = ");" + NL + "    java.sql.ResultSet set_";
  protected final String TEXT_18 = " = statement_";
  protected final String TEXT_19 = ".getResultSet();" + NL + "    set_";
  protected final String TEXT_20 = ".next();" + NL + "    rowCount_";
  protected final String TEXT_21 = " = set_";
  protected final String TEXT_22 = ".getInt(1);" + NL + "    connection_";
  protected final String TEXT_23 = ".commit();" + NL + "    globalMap.put(\"";
  protected final String TEXT_24 = "_ROW_COUNT\", rowCount_";
  protected final String TEXT_25 = ");" + NL + "    " + NL + "    count_";
  protected final String TEXT_26 = "++;" + NL + "\tglobalMap.put(\"";
  protected final String TEXT_27 = "_CURRENT_ITERATION\", count_";
  protected final String TEXT_28 = ");" + NL + "                " + NL + "    if (!(rowCount_";
  protected final String TEXT_29 = ")) {" + NL + "    \tThread.currentThread().sleep(";
  protected final String TEXT_30 = "*1000);" + NL + "        continue;" + NL + "    }";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();

String table = ElementParameterParser.getValue(node,"__TABLE__");
String connection = ElementParameterParser.getValue(node,"__CONNECTION__");
String max = ElementParameterParser.getValue(node,"__MAX_ITERATIONS__");
String operator = ElementParameterParser.getValue(node,"__OPERATOR__");
String value = ElementParameterParser.getValue(node,"__VALUE__");

String conn = "conn_" + connection ;
String query = "select count(*) from ";

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(query);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(table);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(conn);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_11);
    
if(!max.equals("")){

    stringBuffer.append(TEXT_12);
    stringBuffer.append(max);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_14);
    
}

    stringBuffer.append(TEXT_15);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_21);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_23);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_25);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_26);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_28);
    stringBuffer.append(cid);
    stringBuffer.append(operator);
    stringBuffer.append(value);
    stringBuffer.append(TEXT_29);
    stringBuffer.append(ElementParameterParser.getValue(node, "__WAIT__"));
    stringBuffer.append(TEXT_30);
    return stringBuffer.toString();
  }
}
