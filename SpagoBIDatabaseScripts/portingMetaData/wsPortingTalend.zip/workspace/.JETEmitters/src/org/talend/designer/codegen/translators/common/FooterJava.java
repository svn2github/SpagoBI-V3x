package org.talend.designer.codegen.translators.common;

import org.talend.core.model.process.INode;

import org.talend.core.model.process.IProcess;
import org.talend.core.model.process.INode;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.CorePlugin;
import org.talend.core.model.process.EConnectionType;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import java.util.Vector;
import java.util.List;
import java.util.ArrayList;
import org.talend.core.model.process.IContextParameter;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;

public class FooterJava
{
  protected static String nl;
  public static synchronized FooterJava create(String lineSeparator)
  {
    nl = lineSeparator;
    FooterJava result = new FooterJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "    public static boolean watch = false;" + NL + "    public static int portStats = 3334;" + NL + "    public static int portTraces = 4334;" + NL + "    public static String clientHost;" + NL + "    public static String defaultClientHost = \"localhost\";" + NL + "    public static String contextStr = \"";
  protected final String TEXT_2 = "\";" + NL + "    public static String pid = \"0\";" + NL + "    public static String rootPid = null;" + NL + "    public static String fatherPid = null;";
  protected final String TEXT_3 = NL + "    private static ThreadLocal threadLocal = new ThreadLocal();" + NL + "\tprivate static SyncInt runningThreadCount =new SyncInt();" + NL + "\t" + NL + "\tprivate static class SyncInt" + NL + "\t{" + NL + "\t\tprivate int count = 0;" + NL + "\t    public synchronized void add(int i)" + NL + "\t    {" + NL + "\t        count +=i;" + NL + "\t    }" + NL + "\t    " + NL + "\t    public synchronized int getCount()" + NL + "\t    {" + NL + "\t        return count;" + NL + "\t    }" + NL + "\t}";
  protected final String TEXT_4 = NL + "  " + NL + "    private static java.util.Properties context_param = new java.util.Properties();" + NL + "    " + NL + "    public static String status= \"\";" + NL + "    " + NL + "    public static void main(String[] args){" + NL + "    " + NL + "        int exitCode = runJobInTOS(args);" + NL + "        " + NL + "        globalBuffer.clear();" + NL + "        " + NL + "        System.exit(exitCode);" + NL + "    }    " + NL + "   " + NL + " " + NL + "    public static String[][] runJob(String[] args) {" + NL + "    " + NL + "\t\tint exitCode = runJobInTOS(args);";
  protected final String TEXT_5 = "  \t\t\t\t" + NL + "\t\tString[][] bufferValue = (String[][])globalBuffer.toArray(new String[globalBuffer.size()][]);\t\t" + NL + "\t";
  protected final String TEXT_6 = NL + "\t\tString[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };" + NL + "\t";
  protected final String TEXT_7 = "\t" + NL + "\t\tglobalBuffer.clear();" + NL + "\t\t" + NL + "\t\treturn bufferValue;" + NL + "    }" + NL + "    " + NL + "    public static synchronized int runJobInTOS(String[] args) {" + NL + "    " + NL + "\t\tinit();" + NL + "    " + NL + "        String lastStr = \"\";" + NL + "        for (String arg : args) {" + NL + "            if (arg.equalsIgnoreCase(\"--context_param\")) {" + NL + "                lastStr = arg;" + NL + "            } else if (lastStr.equals(\"\")) {" + NL + "                evalParam(arg);" + NL + "            } else {" + NL + "                evalParam(lastStr + \" \" + arg);" + NL + "                lastStr = \"\";" + NL + "            }" + NL + "        }" + NL + "    \t" + NL + "    \tif(clientHost == null) {" + NL + "    \t\tclientHost = defaultClientHost;" + NL + "    \t}" + NL + "    \t" + NL + "    \t" + NL + "    \tpid = TalendString.getAsciiRandomString(6);" + NL + "    \tif (rootPid==null) {" + NL + "    \t\trootPid = pid;" + NL + "    \t}" + NL + "    \tif (fatherPid==null) {" + NL + "    \t\tfatherPid = pid;" + NL + "    \t}" + NL + "    \t" + NL + "    \ttry {" + NL + "    \t\tjava.io.InputStream inContext = ";
  protected final String TEXT_8 = ".class.getClassLoader().getResourceAsStream(\"";
  protected final String TEXT_9 = "/";
  protected final String TEXT_10 = "/contexts/Default.properties\");    \t\t" + NL + "    \t\tif (inContext!=null) {" + NL + "\t    \t\tdefaultProps.load(inContext);" + NL + "    \t\t\tinContext.close();" + NL + "\t    \t\tcontext = new ContextProperties(defaultProps);" + NL + "\t    \t}" + NL + "    \t\t" + NL + "    \t\tif (contextStr.compareTo(\"Default\")!=0) {" + NL + "    \t\t\tinContext = ";
  protected final String TEXT_11 = ".class.getClassLoader().getResourceAsStream(\"";
  protected final String TEXT_12 = "/";
  protected final String TEXT_13 = "/contexts/\"+contextStr+\".properties\");" + NL + "    \t\t\tif (inContext!=null) {" + NL + "\t\t\t\t\tcontext.load(inContext);" + NL + "\t\t\t\t\tinContext.close();" + NL + "\t\t\t\t}" + NL + "\t\t\t}" + NL + "\t\t\t" + NL + "\t\t\tif(!context_param.isEmpty()) {\t\t\t\t\t\t" + NL + "\t\t\t    context.putAll(context_param);\t\t" + NL + "\t\t\t}" + NL + "\t\t\t";
  protected final String TEXT_14 = NL + "\t\t\ttry{" + NL + "\t\t\t    context.";
  protected final String TEXT_15 = "=(java.util.Date)(new java.text.SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").parse(context.getProperty(\"";
  protected final String TEXT_16 = "\")));" + NL + "\t\t\t}catch(ParseException e)" + NL + "\t\t\t{" + NL + "\t\t\t    context.";
  protected final String TEXT_17 = "=null;" + NL + "\t\t\t}" + NL + "\t\t\t";
  protected final String TEXT_18 = " " + NL + "\t\t\t  try{" + NL + "\t\t\t      context.";
  protected final String TEXT_19 = "=Integer.parseInt(context.getProperty(\"";
  protected final String TEXT_20 = "\"));" + NL + "\t\t\t  }catch(NumberFormatException e){" + NL + "\t\t\t      context.";
  protected final String TEXT_21 = "=null;" + NL + "\t\t\t  }" + NL + "\t\t\t  ";
  protected final String TEXT_22 = NL + "\t\t\t    context.";
  protected final String TEXT_23 = "=(";
  protected final String TEXT_24 = ") context.getProperty(\"";
  protected final String TEXT_25 = "\");" + NL + "\t\t\t    ";
  protected final String TEXT_26 = NL + "\t\t\t context.";
  protected final String TEXT_27 = "= context.getProperty(\"";
  protected final String TEXT_28 = "\");" + NL + "\t\t\t ";
  protected final String TEXT_29 = NL + "\t\t\t         context.";
  protected final String TEXT_30 = "= new ";
  protected final String TEXT_31 = "(context.getProperty(\"";
  protected final String TEXT_32 = "\"));" + NL + "\t\t\t         ";
  protected final String TEXT_33 = " " + NL + "\t\t\t try{" + NL + "\t\t\t     context.";
  protected final String TEXT_34 = "=";
  protected final String TEXT_35 = ".parse";
  protected final String TEXT_36 = " (context.getProperty(\"";
  protected final String TEXT_37 = "\"));" + NL + "\t\t\t }catch(NumberFormatException e){" + NL + "\t\t\t     context.";
  protected final String TEXT_38 = "=null;" + NL + "\t\t\t  }" + NL + "\t\t\t ";
  protected final String TEXT_39 = NL + "    \t} catch (java.io.IOException ie) {" + NL + "    \t\tSystem.err.println(\"Could not load context \"+contextStr);" + NL + "    \t\tie.printStackTrace();" + NL + "    \t}" + NL;
  protected final String TEXT_40 = NL + "\ttry {" + NL + "\t\trunStat.startThreadStat(clientHost, portStats);" + NL + "\t} catch (java.io.IOException ioException) {" + NL + "\t\tioException.printStackTrace();" + NL + "\t}";
  protected final String TEXT_41 = NL;
  protected final String TEXT_42 = NL + "\t\ttry {" + NL + "\t\trunTrace.startThreadTrace(clientHost, portTraces);" + NL + "\t} catch (java.io.IOException ioException) {" + NL + "\t\tioException.printStackTrace();" + NL + "\t}";
  protected final String TEXT_43 = NL + NL + NL + "\tlong startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();" + NL + "\tlong endUsedMemory = 0;" + NL + "\tlong end = 0;" + NL + "\tlong start = System.currentTimeMillis();" + NL + "\tfinal ";
  protected final String TEXT_44 = " ";
  protected final String TEXT_45 = "Class = new ";
  protected final String TEXT_46 = "(); ";
  protected final String TEXT_47 = NL + "\t\t";
  protected final String TEXT_48 = "Class.";
  protected final String TEXT_49 = ".addMessage(\"begin\");\t\t\t";
  protected final String TEXT_50 = NL + "\t\trunningThreadCount.add(1);" + NL + "   \t\tnew Thread(){" + NL + "\t    \tpublic void run()" + NL + "\t   \t\t{" + NL + "                java.util.Map threadRunResultMap = new java.util.HashMap();" + NL + "                threadRunResultMap.put(errorCode, null);" + NL + "                threadRunResultMap.put(status, \"\");" + NL + "                threadLocal.set(threadRunResultMap);" + NL + "\t    \t    " + NL + "\t\t\t\t";
  protected final String TEXT_51 = NL + "\t        \t" + NL + "                Integer localErrorCode = (Integer)(((java.util.Map)threadLocal.get()).get(errorCode));" + NL + "                String localStatus = (String)(((java.util.Map)threadLocal.get()).get(status));" + NL + "                if (localErrorCode != null) {" + NL + "                    if (errorCode == null || localErrorCode.compareTo(errorCode) > 0) {" + NL + "                       errorCode = localErrorCode;" + NL + "                    }" + NL + "                }else if(!status.equals(\"failure\")){" + NL + "                        status = localStatus;" + NL + "                }\t" + NL + "         \t    " + NL + "                runningThreadCount.add(-1);\t        \t" + NL + "\t    \t}" + NL + "\t\t}.start();" + NL + "\t\t";
  protected final String TEXT_52 = NL + "\twhile(";
  protected final String TEXT_53 = "Class.runningThreadCount.getCount()>0)" + NL + "    {" + NL + "        try {" + NL + "            Thread.sleep(10);" + NL + "        } catch (Exception e) {" + NL + "            e.printStackTrace();" + NL + "        }            " + NL + "    }";
  protected final String TEXT_54 = NL;
  protected final String TEXT_55 = "\t" + NL + "\t\tend = System.currentTimeMillis();" + NL + "\t\tif (watch) {" + NL + "    \t\tSystem.out.println((end-start)+\" milliseconds\");" + NL + "\t    }" + NL + "\t" + NL + "\t\tendUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();" + NL + "\t\tif (false) {" + NL + "    \t\tSystem.out.println((endUsedMemory - startUsedMemory) + \" bytes memory increase when running : ";
  protected final String TEXT_56 = "\");" + NL + "\t    }\t\t  ";
  protected final String TEXT_57 = NL + "\trunStat.stopThreadStat();";
  protected final String TEXT_58 = NL + "\t\trunTrace.stopThreadTrace();";
  protected final String TEXT_59 = NL + "\t\t";
  protected final String TEXT_60 = "Class.";
  protected final String TEXT_61 = ".addMessage(status==\"\"?\"end\":status, (end-start));" + NL + "\t\ttry {" + NL + "\t\t\t";
  protected final String TEXT_62 = "Class.";
  protected final String TEXT_63 = "Process();" + NL + "\t\t} catch (Exception e) {" + NL + "\t\t\te.printStackTrace();" + NL + "\t\t}";
  protected final String TEXT_64 = NL + "\t" + NL + "\treset();" + NL + "\t" + NL + "    if(errorCode == null) {" + NL + "         return status != null && status.equals(\"failure\") ? 1 : 0;\t" + NL + "    } else {   " + NL + "         return errorCode.intValue();" + NL + "    }" + NL + "  }" + NL + "\t" + NL + "\tpublic static void evalParam(String arg) {\t   " + NL + "\t\tif (arg.startsWith(\"--watch\")) {" + NL + "    \t\twatch = true;" + NL + "    \t} else if (arg.startsWith(\"--stat_port=\")) {" + NL + "    \t\tportStats = Integer.parseInt(arg.substring(12));" + NL + "    \t} else if (arg.startsWith(\"--trace_port=\")) {" + NL + "    \t\tportTraces = Integer.parseInt(arg.substring(13));" + NL + "    \t} else if (arg.startsWith(\"--client_host=\")) {" + NL + "    \t\tclientHost = arg.substring(14);" + NL + "    \t} else if (arg.startsWith(\"--context=\")) {" + NL + "    \t\tcontextStr = arg.substring(10);" + NL + "    \t} else if (arg.startsWith(\"--father_pid=\")) {" + NL + "    \t\tfatherPid = arg.substring(13);" + NL + "    \t} else if (arg.startsWith(\"--root_pid=\")) {" + NL + "    \t\trootPid = arg.substring(11);" + NL + "    \t} else if (arg.startsWith(\"--context_param\")) {   \t\t " + NL + "            String keyValue = arg.substring(16);           " + NL + "            int index = -1;" + NL + "            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {" + NL + "                context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));" + NL + "            }" + NL + "    \t}" + NL + "    \t" + NL + "\t}" + NL + "" + NL + "\tprivate static void init() {" + NL + "\t\terrorCode = null;" + NL + "\t\tstatus = \"\";" + NL + "\t}" + NL + "\t" + NL + "\tprivate static void reset() {" + NL + "" + NL + "\t\tdefaultProps.clear();" + NL + "\t\tcontext.clear();\t";
  protected final String TEXT_65 = NL + "\tcurrentComponent = \"\";";
  protected final String TEXT_66 = "\t" + NL + "\tthreadLocal = new ThreadLocal();" + NL + "\trunningThreadCount = new SyncInt();";
  protected final String TEXT_67 = NL + "\t\tstart_Hash.clear();" + NL + "\t\tend_Hash.clear();" + NL + "\t\tok_Hash.clear();" + NL + "\t\tglobalMap.clear();\t\t" + NL + "\t\twatch = false;" + NL + "\t\tportStats = 3334;" + NL + "\t\tportTraces = 4334;" + NL + "\t\tclientHost = null;" + NL + "\t\tdefaultClientHost = \"localhost\";" + NL + "\t\tcontextStr = \"";
  protected final String TEXT_68 = "\";" + NL + "\t\tpid = \"0\";" + NL + "\t\trootPid = null;" + NL + "\t\tfatherPid = null;" + NL + "\t\tcontext_param.clear();" + NL + "\t\tSystem.gc();\t\t" + NL + "\t}\t" + NL + "}";

    private static String end_multiThread = "((java.util.Map) threadLocal.get()).put(status, \"end\");";
    private static String end_singleThread = "status = \"end\";";
    private static String failure_multiThread = "((java.util.Map) threadLocal.get()).put(status, \"failure\");";
    private static String failure_singleThread = "status = \"failure\";";
    private static String errorCode_multiThread = "((java.util.Map) threadLocal.get()).put(errorCode, null);";
    private static String errorCode_singleThread = "errorCode = null;";
    
    // add the list of the connection names to avoid to declare two times the same name.
    public String createCallProcess(INode rootNode, String className, boolean isMultiThread) {
        String toReturn = "";
        toReturn =  "try {\n";
        if(isMultiThread) {
            toReturn +=  errorCode_multiThread;
        }else{
            toReturn +=  errorCode_singleThread;
        }        
        
        toReturn += className + "Class."+ rootNode.getUniqueName() + "Process();\n";
        
        if(isMultiThread) {
            toReturn +=  end_multiThread;
        }else{
            toReturn +=  end_singleThread;
        }
        
        toReturn += "\n}catch (TalendException e_" + rootNode.getUniqueName() + ") {\n";
        
        if(isMultiThread) {
            toReturn +=  failure_multiThread;
        }else{
            toReturn +=  failure_singleThread;
        }
        
        toReturn += "\ne_" + rootNode.getUniqueName() + ".printStackTrace();\n";
      
       //List< ? extends IConnection> onSubJobErrorConns = rootNode.getOutgoingConnections(EConnectionType.ON_SUBJOB_ERROR);
       //if(onSubJobErrorConns!=null){
       //    for(IConnection conn : onSubJobErrorConns) {               
       //        toReturn += createCallProcess(conn.getTarget(),  className, isMultiThread);
       //    }
       //}            
       toReturn += "\n}finally {\n}"; 
       return toReturn;
    }
		 
    public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
	CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
    Vector v = (Vector) codeGenArgument.getArgument();
    IProcess process = (IProcess)v.get(0);
    List<INode> rootNodes = (List<INode>)v.get(1);

	boolean stats = codeGenArgument.isStatistics();
	boolean trace = codeGenArgument.isTrace();
	boolean isRunInMultiThread = codeGenArgument.getIsRunInMultiThread();
	List<IContextParameter> params = new ArrayList<IContextParameter>();
    params=process.getContextManager().getDefaultContext().getContextParameterList();

    stringBuffer.append(TEXT_1);
    stringBuffer.append(codeGenArgument.getContextName() );
    stringBuffer.append(TEXT_2);
    
	if(isRunInMultiThread){

    stringBuffer.append(TEXT_3);
    
	}

    stringBuffer.append(TEXT_4);
    	
        List<INode> tBufferNodes = (List<INode>)process.getNodesOfType("tBufferOutput");
        if(tBufferNodes != null && tBufferNodes.size() > 0) {
    
    stringBuffer.append(TEXT_5);
    
		} else {
	
    stringBuffer.append(TEXT_6);
    
		}
	
    stringBuffer.append(TEXT_7);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_8);
    stringBuffer.append(codeGenArgument.getCurrentProjectName().toLowerCase() );
    stringBuffer.append(TEXT_9);
    stringBuffer.append(codeGenArgument.getJobName().toLowerCase() );
    stringBuffer.append(TEXT_10);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_11);
    stringBuffer.append(codeGenArgument.getCurrentProjectName().toLowerCase() );
    stringBuffer.append(TEXT_12);
    stringBuffer.append(codeGenArgument.getJobName().toLowerCase() );
    stringBuffer.append(TEXT_13);
     for (IContextParameter ctxParam :params)
			{
			    String typeToGenerate ="String";
			    if( !(ctxParam.getType().equals("id_File") || ctxParam.getType().equals("id_Directory") ||ctxParam.getType().equals("id_List Of Value")))
			    {
			       typeToGenerate=JavaTypesManager.getTypeToGenerate(ctxParam.getType(),true);
			    }
			    if(typeToGenerate.equals("java.util.Date"))
			    {
			        
			
    stringBuffer.append(TEXT_14);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_15);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_16);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_17);
    
			      
			    }else if(typeToGenerate.equals("Integer"))
			    {
			  
    stringBuffer.append(TEXT_18);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_19);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_20);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_21);
    
			    }else if(typeToGenerate.equals("Object")||typeToGenerate.equals("String") )
			    {
			    
    stringBuffer.append(TEXT_22);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_23);
    stringBuffer.append(typeToGenerate);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_25);
    
			    }else if(typeToGenerate.equals("Character"))
			    {
			 
    stringBuffer.append(TEXT_26);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_27);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_28);
    
			    }else if(typeToGenerate.equals("BigDecimal"))
	            {
			         
    stringBuffer.append(TEXT_29);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_30);
    stringBuffer.append(typeToGenerate);
    stringBuffer.append(TEXT_31);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_32);
    
			          }
			     else
			    {
			 
    stringBuffer.append(TEXT_33);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_34);
    stringBuffer.append(typeToGenerate);
    stringBuffer.append(TEXT_35);
    stringBuffer.append(typeToGenerate);
    stringBuffer.append(TEXT_36);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_37);
    stringBuffer.append(ctxParam.getName());
    stringBuffer.append(TEXT_38);
    
			    }
			}
			
    stringBuffer.append(TEXT_39);
    
		if (stats) {

    stringBuffer.append(TEXT_40);
    
		}

    stringBuffer.append(TEXT_41);
    
		if (trace) {

    stringBuffer.append(TEXT_42);
    
		}

    stringBuffer.append(TEXT_43);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_44);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_45);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_46);
    
		for (INode statCatcherNode : process.getNodesOfType("tStatCatcher")) {

    stringBuffer.append(TEXT_47);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_48);
    stringBuffer.append(statCatcherNode.getUniqueName() );
    stringBuffer.append(TEXT_49);
    
    	}

	if(isRunInMultiThread){
		for (INode rootNode : rootNodes) {
			String componentName = (String) rootNode.getComponent().getName();
            if (!componentName.equals("tLogCatcher") && !componentName.equals("tFlowMeterCatcher") && !componentName.equals("tAssertCatcher") && !componentName.equals("tStatCatcher")) {

    stringBuffer.append(TEXT_50);
    stringBuffer.append(createCallProcess(rootNode, process.getName(), true) );
    stringBuffer.append(TEXT_51);
    
			}
		}

    stringBuffer.append(TEXT_52);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_53);
    
	}else{ // isRunInMultiThread
		for (INode rootNode : rootNodes) {
			String componentName = (String) rootNode.getComponent().getName();
            if (!componentName.equals("tLogCatcher") && !componentName.equals("tFlowMeterCatcher") && !componentName.equals("tAssertCatcher") && !componentName.equals("tStatCatcher")) {

    stringBuffer.append(TEXT_54);
    stringBuffer.append(createCallProcess(rootNode, process.getName(), false) );
    	  }
	}
}// end if(isRunInMultiThread)

    stringBuffer.append(TEXT_55);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_56);
    
	if (stats) {

    stringBuffer.append(TEXT_57);
    	
	}

	if (trace) {

    stringBuffer.append(TEXT_58);
    
	}	
	
	for (INode statCatcherNode : process.getNodesOfType("tStatCatcher")) {

    stringBuffer.append(TEXT_59);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_60);
    stringBuffer.append(statCatcherNode.getUniqueName() );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(process.getName() );
    stringBuffer.append(TEXT_62);
    stringBuffer.append(statCatcherNode.getUniqueName() );
    stringBuffer.append(TEXT_63);
    
    }	

    stringBuffer.append(TEXT_64);
    
	if(!isRunInMultiThread ){

    stringBuffer.append(TEXT_65);
    
	}else{

    stringBuffer.append(TEXT_66);
    
	}

    stringBuffer.append(TEXT_67);
    stringBuffer.append(codeGenArgument.getContextName() );
    stringBuffer.append(TEXT_68);
    return stringBuffer.toString();
  }
}