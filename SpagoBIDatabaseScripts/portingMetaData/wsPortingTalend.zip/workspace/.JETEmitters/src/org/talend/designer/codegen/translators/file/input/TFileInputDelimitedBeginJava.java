package org.talend.designer.codegen.translators.file.input;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.IConnectionCategory;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;
import java.util.List;
import java.util.Map;

public class TFileInputDelimitedBeginJava
{
  protected static String nl;
  public static synchronized TFileInputDelimitedBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileInputDelimitedBeginJava result = new TFileInputDelimitedBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "org.talend.fileprocess.FileInputDelimited fid_";
  protected final String TEXT_3 = " = new org.talend.fileprocess.FileInputDelimited(";
  protected final String TEXT_4 = ",";
  protected final String TEXT_5 = ",";
  protected final String TEXT_6 = ",";
  protected final String TEXT_7 = ",";
  protected final String TEXT_8 = ",";
  protected final String TEXT_9 = ",";
  protected final String TEXT_10 = ",";
  protected final String TEXT_11 = ",";
  protected final String TEXT_12 = ");" + NL + "while (fid_";
  protected final String TEXT_13 = ".nextRecord()) {";
  protected final String TEXT_14 = NL + "    \t\t";
  protected final String TEXT_15 = " = null;\t\t\t";
  protected final String TEXT_16 = "\t\t\t" + NL + "\t\t\tboolean whetherReject_";
  protected final String TEXT_17 = " = false;" + NL + "\t\t\t";
  protected final String TEXT_18 = " = new ";
  protected final String TEXT_19 = "Struct();" + NL + "\t\t\ttry {" + NL + "\t\t\t";
  protected final String TEXT_20 = "String temp_";
  protected final String TEXT_21 = " = \"\";" + NL + "\t\t\t\t";
  protected final String TEXT_22 = NL;
  protected final String TEXT_23 = ".";
  protected final String TEXT_24 = " = fid_";
  protected final String TEXT_25 = ".get(";
  protected final String TEXT_26 = ")";
  protected final String TEXT_27 = ";";
  protected final String TEXT_28 = "temp_";
  protected final String TEXT_29 = " = fid_";
  protected final String TEXT_30 = ".get(";
  protected final String TEXT_31 = ")";
  protected final String TEXT_32 = ";" + NL + "if(temp_";
  protected final String TEXT_33 = ".length() > 0) {";
  protected final String TEXT_34 = ".";
  protected final String TEXT_35 = " = temp_";
  protected final String TEXT_36 = ".getBytes(";
  protected final String TEXT_37 = ");";
  protected final String TEXT_38 = ".";
  protected final String TEXT_39 = " = ParserUtils.parseTo_Date(temp_";
  protected final String TEXT_40 = ", ";
  protected final String TEXT_41 = ");";
  protected final String TEXT_42 = ".";
  protected final String TEXT_43 = " = ParserUtils.parseTo_";
  protected final String TEXT_44 = "(ParserUtils.parseTo_Number(temp_";
  protected final String TEXT_45 = ", ";
  protected final String TEXT_46 = ", ";
  protected final String TEXT_47 = "));";
  protected final String TEXT_48 = ".";
  protected final String TEXT_49 = " = ParserUtils.parseTo_";
  protected final String TEXT_50 = "(temp_";
  protected final String TEXT_51 = ");";
  protected final String TEXT_52 = "} else {\t\t\t\t\t\t";
  protected final String TEXT_53 = "throw new RuntimeException(\"Value is empty for column : '";
  protected final String TEXT_54 = "', value is invalid or this column should be nullable or have a default value.\");";
  protected final String TEXT_55 = ".";
  protected final String TEXT_56 = " = ";
  protected final String TEXT_57 = ";";
  protected final String TEXT_58 = "}";
  protected final String TEXT_59 = NL + "\t\t\t\t";
  protected final String TEXT_60 = NL + "\t int filedsum_";
  protected final String TEXT_61 = " = fid_";
  protected final String TEXT_62 = ".getColumnsCountOfCurrentRow();" + NL + "\t if(filedsum_";
  protected final String TEXT_63 = " < ";
  protected final String TEXT_64 = "){" + NL + "\t \tthrow new RuntimeException(\"Column(s) missing\");" + NL + "\t } else if(filedsum_";
  protected final String TEXT_65 = " > ";
  protected final String TEXT_66 = ") {" + NL + "\t \tthrow new RuntimeException(\"Too many columns\");" + NL + "\t }     ";
  protected final String TEXT_67 = "\t\t\t\t" + NL;
  protected final String TEXT_68 = " ";
  protected final String TEXT_69 = " = null; ";
  protected final String TEXT_70 = NL + "\t\t\t\t" + NL + "    } catch (Exception e) {" + NL + "        whetherReject_";
  protected final String TEXT_71 = " = true;";
  protected final String TEXT_72 = NL + "            throw(e);";
  protected final String TEXT_73 = "                    ";
  protected final String TEXT_74 = NL + "                    ";
  protected final String TEXT_75 = " = new ";
  protected final String TEXT_76 = "Struct();";
  protected final String TEXT_77 = NL + "                    ";
  protected final String TEXT_78 = ".";
  protected final String TEXT_79 = " = ";
  protected final String TEXT_80 = ".";
  protected final String TEXT_81 = ";";
  protected final String TEXT_82 = NL + "                ";
  protected final String TEXT_83 = ".errorMessage = e.getMessage();";
  protected final String TEXT_84 = NL + "                ";
  protected final String TEXT_85 = " = null;";
  protected final String TEXT_86 = NL + "                System.err.println(e.getMessage());";
  protected final String TEXT_87 = NL + "                ";
  protected final String TEXT_88 = " = null;";
  protected final String TEXT_89 = NL + "            \t";
  protected final String TEXT_90 = ".errorMessage = e.getMessage();";
  protected final String TEXT_91 = NL + "    }" + NL + "" + NL + "\t\t\t\t";
  protected final String TEXT_92 = NL + "\t\t";
  protected final String TEXT_93 = "if(!whetherReject_";
  protected final String TEXT_94 = ") { ";
  protected final String TEXT_95 = "      " + NL + "             if(";
  protected final String TEXT_96 = " == null){ " + NL + "            \t ";
  protected final String TEXT_97 = " = new ";
  protected final String TEXT_98 = "Struct();" + NL + "             }\t\t\t\t";
  protected final String TEXT_99 = NL + "\t    \t ";
  protected final String TEXT_100 = ".";
  protected final String TEXT_101 = " = ";
  protected final String TEXT_102 = ".";
  protected final String TEXT_103 = ";    \t\t\t\t";
  protected final String TEXT_104 = NL + "\t\t";
  protected final String TEXT_105 = " } ";
  protected final String TEXT_106 = "\t";
  protected final String TEXT_107 = NL;
  protected final String TEXT_108 = NL;
  protected final String TEXT_109 = "\t\t" + NL + "\t\tint nb_line_";
  protected final String TEXT_110 = " = 0;" + NL + "\t\tint footer_";
  protected final String TEXT_111 = " = ";
  protected final String TEXT_112 = ";" + NL + "\t\tint totalLine";
  protected final String TEXT_113 = " = 0;" + NL + "\t\tint limit";
  protected final String TEXT_114 = " = ";
  protected final String TEXT_115 = ";" + NL + "\t\tint lastLine";
  protected final String TEXT_116 = " = -1;\t" + NL + "\t\t" + NL + "\t\tcom.csvreader.CsvReader csvReader";
  protected final String TEXT_117 = "=new com.csvreader.CsvReader(new java.io.BufferedReader(new java.io.InputStreamReader(" + NL + "                new java.io.FileInputStream(";
  protected final String TEXT_118 = "),";
  protected final String TEXT_119 = ")), '";
  protected final String TEXT_120 = "');" + NL + "                ";
  protected final String TEXT_121 = NL + "          \tcsvReader";
  protected final String TEXT_122 = ".setRecordDelimiter('";
  protected final String TEXT_123 = "');";
  protected final String TEXT_124 = NL + "        csvReader";
  protected final String TEXT_125 = ".setSkipEmptyRecords(";
  protected final String TEXT_126 = ");" + NL + "        csvReader";
  protected final String TEXT_127 = ".setTextQualifier('";
  protected final String TEXT_128 = "');                " + NL;
  protected final String TEXT_129 = NL + "            csvReader";
  protected final String TEXT_130 = ".setEscapeMode(com.csvreader.CsvReader.ESCAPE_MODE_BACKSLASH);";
  protected final String TEXT_131 = NL + "            csvReader";
  protected final String TEXT_132 = ".setEscapeMode(com.csvreader.CsvReader.ESCAPE_MODE_DOUBLED);";
  protected final String TEXT_133 = NL + "            //?????doesn't work for other escapeChar";
  protected final String TEXT_134 = "       " + NL + "" + NL + "\t\tString[] row";
  protected final String TEXT_135 = "=null;" + NL + "\t\t" + NL + "\t\tif(footer_";
  protected final String TEXT_136 = " > 0){" + NL + "\t\t" + NL + "            while (csvReader";
  protected final String TEXT_137 = ".readRecord()) {";
  protected final String TEXT_138 = NL + "\t\t\t\trow";
  protected final String TEXT_139 = "=csvReader";
  protected final String TEXT_140 = ".getValues();" + NL + "\t\t\t\tif(!(row";
  protected final String TEXT_141 = ".length == 1 && row";
  protected final String TEXT_142 = "[0].equals(\"\\015\"))){//empty line when row separator is '\\n'";
  protected final String TEXT_143 = NL + "                " + NL + "                \ttotalLine";
  protected final String TEXT_144 = "++;" + NL + "                ";
  protected final String TEXT_145 = NL + "\t\t\t\t}";
  protected final String TEXT_146 = NL + "                " + NL + "            }" + NL + "            int lastLineTemp";
  protected final String TEXT_147 = " = totalLine";
  protected final String TEXT_148 = " - footer_";
  protected final String TEXT_149 = "   < 0? 0 : totalLine";
  protected final String TEXT_150 = " - footer_";
  protected final String TEXT_151 = " ;" + NL + "            if(lastLine";
  protected final String TEXT_152 = " > 0){" + NL + "                lastLine";
  protected final String TEXT_153 = " = lastLine";
  protected final String TEXT_154 = " < lastLineTemp";
  protected final String TEXT_155 = " ? lastLine";
  protected final String TEXT_156 = " : lastLineTemp";
  protected final String TEXT_157 = "; " + NL + "            }else {" + NL + "                lastLine";
  protected final String TEXT_158 = " = lastLineTemp";
  protected final String TEXT_159 = ";" + NL + "            }" + NL + "         " + NL + "          \tcsvReader";
  protected final String TEXT_160 = ".close();" + NL + "          " + NL + "         \tcsvReader";
  protected final String TEXT_161 = "=new com.csvreader.CsvReader(new java.io.BufferedReader(new java.io.InputStreamReader(" + NL + "                  new java.io.FileInputStream(";
  protected final String TEXT_162 = "),";
  protected final String TEXT_163 = ")), '";
  protected final String TEXT_164 = "');";
  protected final String TEXT_165 = NL + "          \tcsvReader";
  protected final String TEXT_166 = ".setRecordDelimiter('";
  protected final String TEXT_167 = "');";
  protected final String TEXT_168 = NL + "        csvReader";
  protected final String TEXT_169 = ".setSkipEmptyRecords(";
  protected final String TEXT_170 = ");" + NL + "        csvReader";
  protected final String TEXT_171 = ".setTextQualifier('";
  protected final String TEXT_172 = "');                " + NL;
  protected final String TEXT_173 = NL + "            csvReader";
  protected final String TEXT_174 = ".setEscapeMode(com.csvreader.CsvReader.ESCAPE_MODE_BACKSLASH);";
  protected final String TEXT_175 = NL + "            csvReader";
  protected final String TEXT_176 = ".setEscapeMode(com.csvreader.CsvReader.ESCAPE_MODE_DOUBLED);";
  protected final String TEXT_177 = NL + "            //?????doesn't work for other escapeChar";
  protected final String TEXT_178 = "  " + NL + "          " + NL + "        }" + NL + "        " + NL + "        " + NL + "        " + NL + "        int currentLine";
  protected final String TEXT_179 = " = 0;" + NL + "        int outputLine";
  protected final String TEXT_180 = " = 0;" + NL + "            " + NL + "        while (csvReader";
  protected final String TEXT_181 = ".readRecord()) { " + NL + "        " + NL + "        \trow";
  protected final String TEXT_182 = "=csvReader";
  protected final String TEXT_183 = ".getValues();" + NL + "        \t";
  protected final String TEXT_184 = NL + "        \tif(row";
  protected final String TEXT_185 = ".length == 1 && row";
  protected final String TEXT_186 = "[0].equals(\"\\015\")){//empty line when row separator is '\\n'" + NL + "        \t\tcontinue;" + NL + "        \t}";
  protected final String TEXT_187 = NL + "        \t" + NL + "        \t" + NL + "        \tcurrentLine";
  protected final String TEXT_188 = "++;" + NL + "        \tif(currentLine";
  protected final String TEXT_189 = " < ";
  protected final String TEXT_190 = "+1) {" + NL + "                continue;" + NL + "            }" + NL + "            " + NL + "            if(lastLine";
  protected final String TEXT_191 = " > -1 && currentLine";
  protected final String TEXT_192 = " > lastLine";
  protected final String TEXT_193 = ") {" + NL + "                break;" + NL + "            }" + NL + "            outputLine";
  protected final String TEXT_194 = "++;" + NL + "            if(limit";
  protected final String TEXT_195 = "!=-1&& outputLine";
  protected final String TEXT_196 = " > limit";
  protected final String TEXT_197 = "){" + NL + "                break;" + NL + "            }  " + NL + "                                                                      ";
  protected final String TEXT_198 = NL + "    \t\t";
  protected final String TEXT_199 = " = null;\t\t\t";
  protected final String TEXT_200 = NL + "\t\t\tboolean whetherReject_";
  protected final String TEXT_201 = " = false;" + NL + "\t\t\t";
  protected final String TEXT_202 = " = new ";
  protected final String TEXT_203 = "Struct();" + NL + "\t\t\ttry {\t\t\t" + NL + "\t\t\t";
  protected final String TEXT_204 = "\t\t\t\t" + NL + "\t\t\t\t" + NL + "\t\t\tif(row";
  protected final String TEXT_205 = ".length == 1 && row";
  protected final String TEXT_206 = "[0].equals(\"\\015\")){//empty line when row separator is '\\n'" + NL + "\t\t\t\t";
  protected final String TEXT_207 = NL + NL + "\t\t\t\t";
  protected final String TEXT_208 = ".";
  protected final String TEXT_209 = " = ";
  protected final String TEXT_210 = ";" + NL + "\t\t\t\t";
  protected final String TEXT_211 = NL + "\t\t\t\t" + NL + "\t\t\t}else{" + NL + "\t\t\t";
  protected final String TEXT_212 = NL + "\t\t\t\t\t\t" + NL + "\t\t\t" + NL + "\t\t\t\tif(";
  protected final String TEXT_213 = " < row";
  protected final String TEXT_214 = ".length){\t\t\t\t";
  protected final String TEXT_215 = NL + "\t\t\t\t\t";
  protected final String TEXT_216 = ".";
  protected final String TEXT_217 = " = row";
  protected final String TEXT_218 = "[";
  protected final String TEXT_219 = "]";
  protected final String TEXT_220 = ";";
  protected final String TEXT_221 = NL + "\t\t\t\t\t\tif(row";
  protected final String TEXT_222 = "[";
  protected final String TEXT_223 = "].length() > 0) {" + NL + "\t";
  protected final String TEXT_224 = NL + "\t\t\t\t\t\t\t\t";
  protected final String TEXT_225 = ".";
  protected final String TEXT_226 = " = ParserUtils.parseTo_Date(row";
  protected final String TEXT_227 = "[";
  protected final String TEXT_228 = "]";
  protected final String TEXT_229 = ", ";
  protected final String TEXT_230 = ");" + NL + "\t";
  protected final String TEXT_231 = NL + "\t\t\t\t\t\t\t\t";
  protected final String TEXT_232 = ".";
  protected final String TEXT_233 = " = ParserUtils.parseTo_";
  protected final String TEXT_234 = "(ParserUtils.parseTo_Number(row";
  protected final String TEXT_235 = "[";
  protected final String TEXT_236 = "]";
  protected final String TEXT_237 = ", ";
  protected final String TEXT_238 = ", ";
  protected final String TEXT_239 = "));" + NL + "\t";
  protected final String TEXT_240 = "\t\t\t\t\t\t\t" + NL + "\t\t\t\t\t\t\t    ";
  protected final String TEXT_241 = ".";
  protected final String TEXT_242 = " = row";
  protected final String TEXT_243 = "[";
  protected final String TEXT_244 = "]";
  protected final String TEXT_245 = ".getBytes(";
  protected final String TEXT_246 = ");" + NL + "\t";
  protected final String TEXT_247 = NL + "\t\t\t\t\t\t\t\t";
  protected final String TEXT_248 = ".";
  protected final String TEXT_249 = " = ParserUtils.parseTo_";
  protected final String TEXT_250 = "(row";
  protected final String TEXT_251 = "[";
  protected final String TEXT_252 = "]";
  protected final String TEXT_253 = ");" + NL + "\t";
  protected final String TEXT_254 = "\t\t\t\t\t" + NL + "\t\t\t\t\t\t}else{" + NL + "\t\t\t\t\t\t\t";
  protected final String TEXT_255 = ".";
  protected final String TEXT_256 = " = ";
  protected final String TEXT_257 = ";" + NL + "\t\t\t\t\t\t}" + NL + "\t";
  protected final String TEXT_258 = "\t" + NL + "\t\t\t\t\t\t\t\t" + NL + "\t\t\t\t}else{\t\t\t\t\t\t\t\t\t\t" + NL + "" + NL + "\t\t\t\t";
  protected final String TEXT_259 = ".";
  protected final String TEXT_260 = " = ";
  protected final String TEXT_261 = ";" + NL + "" + NL + "\t\t\t\t}" + NL;
  protected final String TEXT_262 = NL + NL + "\t\t\t}" + NL + "\t\t\t";
  protected final String TEXT_263 = NL + "\t int filedsum_";
  protected final String TEXT_264 = " = row";
  protected final String TEXT_265 = ".length;" + NL + "\t if(filedsum_";
  protected final String TEXT_266 = " < ";
  protected final String TEXT_267 = "){" + NL + "\t \tthrow new Exception(\"Column(s) missing\");" + NL + "\t } else if(filedsum_";
  protected final String TEXT_268 = " > ";
  protected final String TEXT_269 = ") {" + NL + "\t \tthrow new RuntimeException(\"Too many columns\");" + NL + "\t }     ";
  protected final String TEXT_270 = "\t" + NL;
  protected final String TEXT_271 = " ";
  protected final String TEXT_272 = " = null; ";
  protected final String TEXT_273 = NL + "\t\t\t" + NL + "    } catch (Exception e) {" + NL + "        whetherReject_";
  protected final String TEXT_274 = " = true;";
  protected final String TEXT_275 = NL + "            throw(e);";
  protected final String TEXT_276 = NL + "                    ";
  protected final String TEXT_277 = " = new ";
  protected final String TEXT_278 = "Struct();";
  protected final String TEXT_279 = NL + "                    ";
  protected final String TEXT_280 = ".";
  protected final String TEXT_281 = " = ";
  protected final String TEXT_282 = ".";
  protected final String TEXT_283 = ";";
  protected final String TEXT_284 = NL + "                ";
  protected final String TEXT_285 = ".errorMessage = e.getMessage();";
  protected final String TEXT_286 = NL + "                ";
  protected final String TEXT_287 = " = null;";
  protected final String TEXT_288 = NL + "                System.err.println(e.getMessage());";
  protected final String TEXT_289 = NL + "                ";
  protected final String TEXT_290 = " = null;";
  protected final String TEXT_291 = NL + "            \t";
  protected final String TEXT_292 = ".errorMessage = e.getMessage();";
  protected final String TEXT_293 = NL + "    }" + NL;
  protected final String TEXT_294 = NL + "\t\t";
  protected final String TEXT_295 = "if(!whetherReject_";
  protected final String TEXT_296 = ") { ";
  protected final String TEXT_297 = "      " + NL + "             if(";
  protected final String TEXT_298 = " == null){ " + NL + "            \t ";
  protected final String TEXT_299 = " = new ";
  protected final String TEXT_300 = "Struct();" + NL + "             }\t\t\t\t";
  protected final String TEXT_301 = NL + "\t    \t ";
  protected final String TEXT_302 = ".";
  protected final String TEXT_303 = " = ";
  protected final String TEXT_304 = ".";
  protected final String TEXT_305 = ";    \t\t\t\t";
  protected final String TEXT_306 = NL + "\t\t";
  protected final String TEXT_307 = " } ";
  protected final String TEXT_308 = "\t";
  protected final String TEXT_309 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     
    CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
    INode node = (INode)codeGenArgument.getArgument();
    String cid = node.getUniqueName();	
	if(ElementParameterParser.getValue(node,"__CSV_OPTION__").equals("false")) {	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    stringBuffer.append(TEXT_1);
    
List<IMetadataTable> metadatas = node.getMetadataList();
if ((metadatas!=null)&&(metadatas.size()>0)) {
	IMetadataTable metadata = metadatas.get(0);
	if (metadata!=null) {
		String filename = ElementParameterParser.getValue(node,"__FILENAME__");
    	String encoding = ElementParameterParser.getValue(node,"__ENCODING__");
    	String header = ElementParameterParser.getValue(node, "__HEADER__");
    	if(header.equals("")){
    		header="0";
    	}
    	String limit = ElementParameterParser.getValue(node, "__LIMIT__");
		if(limit.equals("")){
			limit = "-1";
		}
    	String footer = ElementParameterParser.getValue(node, "__FOOTER__");
    	if(footer.equals("")){
    		footer="0";
    	}
    	String random = "-1";
    	String ran = ElementParameterParser.getValue(node, "__RANDOM__");
    	if(ran.equals("true")){
    		random = ElementParameterParser.getValue(node, "__NB_RANDOM__");
    		if(random.equals("")){
    			random="0";
    		}
    	}
    	
		List<Map<String, String>> trimSelects = (List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__TRIMSELECT__");
		String isTrimAllStr = ElementParameterParser.getValue(node,"__TRIMALL__");
		boolean isTrimAll = (isTrimAllStr!=null&&!isTrimAllStr.equals(""))?isTrimAllStr.equals("true"):true;
		
    	String fieldSeparator = ElementParameterParser.getValue(node, "__FIELDSEPARATOR__");
    	String rowSeparator = ElementParameterParser.getValue(node, "__ROWSEPARATOR__");
    	String removeEmptyRowFlag =  ElementParameterParser.getValue(node, "__REMOVE_EMPTY_ROW__");
    	String dieOnErrorStr = ElementParameterParser.getValue(node, "__DIE_ON_ERROR__");
		boolean dieOnError = (dieOnErrorStr!=null&&!dieOnErrorStr.equals(""))?dieOnErrorStr.equals("true"):false; 
		
		String checkNumStr = ElementParameterParser.getValue(node, "__CHECK_FIELDS_NUM__");
		boolean checkNum = (checkNumStr!=null&&!checkNumStr.equals(""))?checkNumStr.equals("true"):false; 
		
		String advancedSeparatorStr = ElementParameterParser.getValue(node, "__ADVANCED_SEPARATOR__");
		boolean advancedSeparator = (advancedSeparatorStr!=null&&!advancedSeparatorStr.equals(""))?advancedSeparatorStr.equals("true"):false;
		String thousandsSeparator = ElementParameterParser.getValue(node, "__THOUSANDS_SEPARATOR__");
		String decimalSeparator = ElementParameterParser.getValue(node, "__DECIMAL_SEPARATOR__");

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_3);
    stringBuffer.append(filename );
    stringBuffer.append(TEXT_4);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_5);
    stringBuffer.append(fieldSeparator );
    stringBuffer.append(TEXT_6);
    stringBuffer.append(rowSeparator );
    stringBuffer.append(TEXT_7);
    stringBuffer.append(removeEmptyRowFlag );
    stringBuffer.append(TEXT_8);
    stringBuffer.append(header );
    stringBuffer.append(TEXT_9);
    stringBuffer.append(footer );
    stringBuffer.append(TEXT_10);
    stringBuffer.append(limit );
    stringBuffer.append(TEXT_11);
    stringBuffer.append(random );
    stringBuffer.append(TEXT_12);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_13);
    
	List< ? extends IConnection> conns = node.getOutgoingSortedConnections();

    String rejectConnName = "";
    List<? extends IConnection> rejectConns = node.getOutgoingConnections("REJECT");
    if(rejectConns != null && rejectConns.size() > 0) {
        IConnection rejectConn = rejectConns.get(0);
        rejectConnName = rejectConn.getName();
    }
    List<IMetadataColumn> rejectColumnList = null;
    IMetadataTable metadataTable = node.getMetadataFromConnector("REJECT");
    if(metadataTable != null) {
        rejectColumnList = metadataTable.getListColumns();      
    }

    	if (conns!=null) {
    		if (conns.size()>0) {
    			for (int i=0;i<conns.size();i++) {
    				IConnection connTemp = conns.get(i);
    				if (connTemp.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {

    stringBuffer.append(TEXT_14);
    stringBuffer.append(connTemp.getName() );
    stringBuffer.append(TEXT_15);
    
    				}
    			}
    		}
    	}
    	
	String firstConnName = "";
	if (conns!=null) {
		if (conns.size()>0) {
			IConnection conn = conns.get(0);
			firstConnName = conn.getName();			
			if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
    stringBuffer.append(TEXT_16);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_17);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_18);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_19);
    	
				List<IMetadataColumn> listColumns = metadata.getListColumns();
				int sizeListColumns = listColumns.size();
				boolean noStringTypeExist = false;
				for (int valueN=0; valueN<sizeListColumns; valueN++) {
					IMetadataColumn column = listColumns.get(valueN);
					JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
					if(javaType == JavaTypesManager.STRING || javaType == JavaTypesManager.OBJECT){
					}else{
						noStringTypeExist = true;
						break;
					}
				}
				if(noStringTypeExist){
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_21);
    
				}
				for (int valueN=0; valueN<sizeListColumns; valueN++) {
					IMetadataColumn column = listColumns.get(valueN);
					String typeToGenerate = JavaTypesManager.getTypeToGenerate(column.getTalendType(), column.isNullable());
					JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
					String patternValue = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
    
if(javaType == JavaTypesManager.STRING || javaType == JavaTypesManager.OBJECT){
    stringBuffer.append(TEXT_22);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_23);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_25);
    stringBuffer.append(valueN);
    stringBuffer.append(TEXT_26);
    stringBuffer.append((isTrimAll || (!trimSelects.isEmpty() && trimSelects.get(valueN).get("TRIM").equals("true")))?".trim()":"" );
    stringBuffer.append(TEXT_27);
    
}else{ 

    stringBuffer.append(TEXT_28);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_29);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_30);
    stringBuffer.append(valueN);
    stringBuffer.append(TEXT_31);
    stringBuffer.append((isTrimAll || (!trimSelects.isEmpty() && trimSelects.get(valueN).get("TRIM").equals("true")))?".trim()":"" );
    stringBuffer.append(TEXT_32);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_33);
    
					if(javaType == JavaTypesManager.STRING || javaType == JavaTypesManager.OBJECT) {
					} else if(javaType == JavaTypesManager.BYTE_ARRAY){ 

    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_34);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_35);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_36);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_37);
    
					}else if(javaType == JavaTypesManager.DATE) { 

    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_38);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_39);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_40);
    stringBuffer.append( patternValue );
    stringBuffer.append(TEXT_41);
    
					}else if(advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable())) { 

    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_42);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_43);
    stringBuffer.append( typeToGenerate );
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_45);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_46);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_47);
    
					} else { 

    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_48);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_49);
    stringBuffer.append( typeToGenerate );
    stringBuffer.append(TEXT_50);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_51);
    
					}

    stringBuffer.append(TEXT_52);
    
					String defaultValue = JavaTypesManager.getDefaultValueFromJavaType(typeToGenerate, column.getDefault());
					if(defaultValue == null) {

    stringBuffer.append(TEXT_53);
    stringBuffer.append( column.getLabel() );
    stringBuffer.append(TEXT_54);
    
					} else {

    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_55);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_56);
    stringBuffer.append(defaultValue );
    stringBuffer.append(TEXT_57);
    
					}

    stringBuffer.append(TEXT_58);
    
}

    
				}
    stringBuffer.append(TEXT_59);
    if(checkNum) {
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_62);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_63);
    stringBuffer.append(metadata.getListColumns().size() );
    stringBuffer.append(TEXT_64);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_65);
    stringBuffer.append(metadata.getListColumns().size() );
    stringBuffer.append(TEXT_66);
    }
    stringBuffer.append(TEXT_67);
    if(rejectConnName.equals(firstConnName)) {
    stringBuffer.append(TEXT_68);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_69);
    }
    stringBuffer.append(TEXT_70);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_71);
    
        if (dieOnError) {
            
    stringBuffer.append(TEXT_72);
    
        } else {
            if(!rejectConnName.equals("")&&!rejectConnName.equals(firstConnName)&&rejectColumnList != null && rejectColumnList.size() > 0) {

                
    stringBuffer.append(TEXT_73);
    stringBuffer.append(TEXT_74);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_75);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_76);
    
                for(IMetadataColumn column : metadata.getListColumns()) {
                    
    stringBuffer.append(TEXT_77);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_78);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_79);
    stringBuffer.append(firstConnName);
    stringBuffer.append(TEXT_80);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_81);
    
                }
                
    stringBuffer.append(TEXT_82);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_83);
    stringBuffer.append(TEXT_84);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_85);
    
            } else if(rejectConnName.equals("")){
                
    stringBuffer.append(TEXT_86);
    stringBuffer.append(TEXT_87);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_88);
    
            } else if(rejectConnName.equals(firstConnName)){
    stringBuffer.append(TEXT_89);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_90);
    }
        } 
        
    stringBuffer.append(TEXT_91);
    
			}
		}
		if (conns.size()>0) {	
			boolean isFirstEnter = true;
			for (int i=0;i<conns.size();i++) {
				IConnection conn = conns.get(i);
				if ((conn.getName().compareTo(firstConnName)!=0)&&(conn.getName().compareTo(rejectConnName)!=0)&&(conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA))) {

    stringBuffer.append(TEXT_92);
     if(isFirstEnter) {
    stringBuffer.append(TEXT_93);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_94);
     isFirstEnter = false; } 
    stringBuffer.append(TEXT_95);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_96);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_97);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_98);
    
			    	 for (IMetadataColumn column: metadata.getListColumns()) {

    stringBuffer.append(TEXT_99);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_100);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_101);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_102);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_103);
    
				 	}
				}
			}

    stringBuffer.append(TEXT_104);
     if(!isFirstEnter) {
    stringBuffer.append(TEXT_105);
     } 
    stringBuffer.append(TEXT_106);
    
		}
	  }
	}
}

    stringBuffer.append(TEXT_107);
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}else{//the following is the tFileInputCSV component
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    stringBuffer.append(TEXT_108);
    
List<IMetadataTable> metadatas = node.getMetadataList();
if ((metadatas!=null)&&(metadatas.size()>0)) {
    IMetadataTable metadata = metadatas.get(0);
    if (metadata!=null) {
        
        String filename = ElementParameterParser.getValueWithUIFieldKey(node,"__FILENAME__", "FILENAME");
    	String encoding = ElementParameterParser.getValue(node,"__ENCODING__");
    	String header = ElementParameterParser.getValue(node, "__HEADER__");
    	String footer = ElementParameterParser.getValue(node, "__FOOTER__");
    	String limit = ElementParameterParser.getValue(node, "__LIMIT__");
    	if(limit.equals("")){
    		limit="-1";
    	}
    	String delim1 = ElementParameterParser.getValue(node, "__FIELDSEPARATOR__");
    	String delim = delim1.substring(1,delim1.length()-1);
    	if(delim.equals("'")){
    		delim = "\\'";
    	}
    	String rowSeparator1 = ElementParameterParser.getValue(node, "__ROWSEPARATOR__");
    	String rowSeparator = rowSeparator1.substring(1,rowSeparator1.length()-1);
    	if(rowSeparator.equals("'")){
    		rowSeparator = "\\'";
    	}
    	String escapeChar1 = ElementParameterParser.getValue(node, "__ESCAPE_CHAR__");
    	String escapeChar = escapeChar1.substring(1,escapeChar1.length()-1);
    	if(escapeChar.equals("'")){
    		escapeChar = "\\'";
    	}
    	String textEnclosure1 = ElementParameterParser.getValue(node, "__TEXT_ENCLOSURE__");
    	String textEnclosure = textEnclosure1.substring(1,textEnclosure1.length()-1);
    	if ("".equals(textEnclosure)) textEnclosure = "\0";
    	if(textEnclosure.equals("'")){
    		textEnclosure = "\\'";
    	}
    	String removeEmptyRow = ElementParameterParser.getValue(node, "__REMOVE_EMPTY_ROW__");
    	
    	List<Map<String, String>> trimSelects = (List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__TRIMSELECT__");
		String isTrimAllStr = ElementParameterParser.getValue(node,"__TRIMALL__");
		boolean isTrimAll = (isTrimAllStr!=null&&!isTrimAllStr.equals(""))?isTrimAllStr.equals("true"):true;
		
    	String dieOnErrorStr = ElementParameterParser.getValue(node, "__DIE_ON_ERROR__");
		boolean dieOnError = (dieOnErrorStr!=null&&!dieOnErrorStr.equals(""))?dieOnErrorStr.equals("true"):false;
		
		String checkNumStr = ElementParameterParser.getValue(node, "__CHECK_FIELDS_NUM__");
		boolean checkNum = (checkNumStr!=null&&!checkNumStr.equals(""))?checkNumStr.equals("true"):false; 
		
		String advancedSeparatorStr = ElementParameterParser.getValue(node, "__ADVANCED_SEPARATOR__");
		boolean advancedSeparator = (advancedSeparatorStr!=null&&!advancedSeparatorStr.equals(""))?advancedSeparatorStr.equals("true"):false;
		String thousandsSeparator = ElementParameterParser.getValue(node, "__THOUSANDS_SEPARATOR__");
		String decimalSeparator = ElementParameterParser.getValue(node, "__DECIMAL_SEPARATOR__");
		

    stringBuffer.append(TEXT_109);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_110);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_111);
    stringBuffer.append( footer);
    stringBuffer.append(TEXT_112);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_113);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_114);
    stringBuffer.append( limit );
    stringBuffer.append(TEXT_115);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_117);
    stringBuffer.append(filename );
    stringBuffer.append(TEXT_118);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_119);
    stringBuffer.append(delim );
    stringBuffer.append(TEXT_120);
              	if(!rowSeparator.equals("\\n") && !rowSeparator.equals("\\r")){
    stringBuffer.append(TEXT_121);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_122);
    stringBuffer.append(rowSeparator  );
    stringBuffer.append(TEXT_123);
    				}

    stringBuffer.append(TEXT_124);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_125);
    stringBuffer.append(removeEmptyRow );
    stringBuffer.append(TEXT_126);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_127);
    stringBuffer.append(textEnclosure );
    stringBuffer.append(TEXT_128);
    
        if(escapeChar.equals("\\\\")){
        
    stringBuffer.append(TEXT_129);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_130);
    
        }else if(escapeChar.equals(textEnclosure)){
        
    stringBuffer.append(TEXT_131);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_132);
    
        }else{
        
    stringBuffer.append(TEXT_133);
    
        }
        
    stringBuffer.append(TEXT_134);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_135);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_136);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_137);
                	if(removeEmptyRow.equals("true")){
    stringBuffer.append(TEXT_138);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_139);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_140);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_141);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_142);
    				}
    stringBuffer.append(TEXT_143);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_144);
                	if(removeEmptyRow.equals("true")){
    stringBuffer.append(TEXT_145);
    				}
    stringBuffer.append(TEXT_146);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_147);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_148);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_149);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_150);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_151);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_152);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_153);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_154);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_155);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_156);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_157);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_158);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_159);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_160);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_161);
    stringBuffer.append(filename );
    stringBuffer.append(TEXT_162);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_163);
    stringBuffer.append(delim );
    stringBuffer.append(TEXT_164);
              	if(!rowSeparator.equals("\\n") && !rowSeparator.equals("\\r")){
    stringBuffer.append(TEXT_165);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_166);
    stringBuffer.append(rowSeparator  );
    stringBuffer.append(TEXT_167);
    				}

    stringBuffer.append(TEXT_168);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_169);
    stringBuffer.append(removeEmptyRow );
    stringBuffer.append(TEXT_170);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_171);
    stringBuffer.append(textEnclosure );
    stringBuffer.append(TEXT_172);
    
        if(escapeChar.equals("\\\\")){
        
    stringBuffer.append(TEXT_173);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_174);
    
        }else if(escapeChar.equals(textEnclosure)){
        
    stringBuffer.append(TEXT_175);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_176);
    
        }else{
        
    stringBuffer.append(TEXT_177);
    
        }
        
    stringBuffer.append(TEXT_178);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_179);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_180);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_181);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_182);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_183);
    
   		if(removeEmptyRow.equals("true")){
    stringBuffer.append(TEXT_184);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_185);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_186);
    		}
    stringBuffer.append(TEXT_187);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_188);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_189);
    stringBuffer.append( header );
    stringBuffer.append(TEXT_190);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_191);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_192);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_193);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_194);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_195);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_196);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_197);
    
	List< ? extends IConnection> conns = node.getOutgoingSortedConnections();

    String rejectConnName = "";
    List<? extends IConnection> rejectConns = node.getOutgoingConnections("REJECT");
    if(rejectConns != null && rejectConns.size() > 0) {
        IConnection rejectConn = rejectConns.get(0);
        rejectConnName = rejectConn.getName();
    }
    List<IMetadataColumn> rejectColumnList = null;
    IMetadataTable metadataTable = node.getMetadataFromConnector("REJECT");
    if(metadataTable != null) {
        rejectColumnList = metadataTable.getListColumns();      
    }

    	if (conns!=null) {
    		if (conns.size()>0) {
    			for (int i=0;i<conns.size();i++) {
    				IConnection connTemp = conns.get(i);
    				if (connTemp.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {

    stringBuffer.append(TEXT_198);
    stringBuffer.append(connTemp.getName() );
    stringBuffer.append(TEXT_199);
    
    				}
    			}
    		}
    	}
    	
	String firstConnName = "";
	if (conns!=null) {
		if (conns.size()>0) {
			IConnection conn = conns.get(0);
			firstConnName = conn.getName();
			
			if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
			
    stringBuffer.append(TEXT_200);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_201);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_202);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_203);
    
				List<IMetadataColumn> columns=metadata.getListColumns();
				int columnSize = columns.size();
				
    stringBuffer.append(TEXT_204);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_205);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_206);
    
		for (IMetadataColumn column1: metadata.getListColumns()) {
    stringBuffer.append(TEXT_207);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_208);
    stringBuffer.append(column1.getLabel() );
    stringBuffer.append(TEXT_209);
    stringBuffer.append(JavaTypesManager.getDefaultValueFromJavaIdType(column1.getTalendType(), column1.isNullable()));
    stringBuffer.append(TEXT_210);
    		}
    stringBuffer.append(TEXT_211);
    
			for (int i=0;i<columnSize;i++) {
					IMetadataColumn column=columns.get(i);
					String typeToGenerate = JavaTypesManager.getTypeToGenerate(column.getTalendType(), column.isNullable());
					JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
					String patternValue = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
			
    stringBuffer.append(TEXT_212);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_213);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_214);
    
					if(javaType == JavaTypesManager.STRING || javaType == JavaTypesManager.OBJECT) {

    stringBuffer.append(TEXT_215);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_216);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_217);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_218);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_219);
    stringBuffer.append((isTrimAll || (!trimSelects.isEmpty() && trimSelects.get(i).get("TRIM").equals("true")))?".trim()":"" );
    stringBuffer.append(TEXT_220);
    
					} else {

    stringBuffer.append(TEXT_221);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_222);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_223);
    
							if(javaType == JavaTypesManager.DATE) {
	
    stringBuffer.append(TEXT_224);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_225);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_226);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_227);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_228);
    stringBuffer.append((isTrimAll || (!trimSelects.isEmpty() && trimSelects.get(i).get("TRIM").equals("true")))?".trim()":"" );
    stringBuffer.append(TEXT_229);
    stringBuffer.append( patternValue );
    stringBuffer.append(TEXT_230);
    
							} else if(advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable())) { 
	
    stringBuffer.append(TEXT_231);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_232);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_233);
    stringBuffer.append( typeToGenerate );
    stringBuffer.append(TEXT_234);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_235);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_236);
    stringBuffer.append((isTrimAll || (!trimSelects.isEmpty() && trimSelects.get(i).get("TRIM").equals("true")))?".trim()":"" );
    stringBuffer.append(TEXT_237);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_238);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_239);
    
							}else if(javaType == JavaTypesManager.BYTE_ARRAY){ 
	
    stringBuffer.append(TEXT_240);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_241);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_242);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_243);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_244);
    stringBuffer.append((isTrimAll || (!trimSelects.isEmpty() && trimSelects.get(i).get("TRIM").equals("true")))?".trim()":"" );
    stringBuffer.append(TEXT_245);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_246);
    
							} else {
	
    stringBuffer.append(TEXT_247);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_249);
    stringBuffer.append( typeToGenerate );
    stringBuffer.append(TEXT_250);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_251);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_252);
    stringBuffer.append((isTrimAll || (!trimSelects.isEmpty() && trimSelects.get(i).get("TRIM").equals("true")))?".trim()":"" );
    stringBuffer.append(TEXT_253);
    
							}
	
    stringBuffer.append(TEXT_254);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_255);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_256);
    stringBuffer.append(JavaTypesManager.getDefaultValueFromJavaType(typeToGenerate));
    stringBuffer.append(TEXT_257);
    					
					}
    stringBuffer.append(TEXT_258);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_259);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_260);
    stringBuffer.append(JavaTypesManager.getDefaultValueFromJavaType(typeToGenerate));
    stringBuffer.append(TEXT_261);
    			}
    stringBuffer.append(TEXT_262);
    if(checkNum) {
    stringBuffer.append(TEXT_263);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_264);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_265);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_266);
    stringBuffer.append(metadata.getListColumns().size() );
    stringBuffer.append(TEXT_267);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_268);
    stringBuffer.append(metadata.getListColumns().size() );
    stringBuffer.append(TEXT_269);
    }
    stringBuffer.append(TEXT_270);
    if(rejectConnName.equals(firstConnName)) {
    stringBuffer.append(TEXT_271);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_272);
    }
    stringBuffer.append(TEXT_273);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_274);
    
        if (dieOnError) {
            
    stringBuffer.append(TEXT_275);
    
        } else {
            if(!rejectConnName.equals("")&&!rejectConnName.equals(firstConnName)&&rejectColumnList != null && rejectColumnList.size() > 0) {

                
    stringBuffer.append(TEXT_276);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_277);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_278);
    
                for(IMetadataColumn column : metadata.getListColumns()) {
                    
    stringBuffer.append(TEXT_279);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_280);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_281);
    stringBuffer.append(firstConnName);
    stringBuffer.append(TEXT_282);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_283);
    
                }
                
    stringBuffer.append(TEXT_284);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_285);
    stringBuffer.append(TEXT_286);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_287);
    
            } else if(rejectConnName.equals("")){
                
    stringBuffer.append(TEXT_288);
    stringBuffer.append(TEXT_289);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_290);
    
            } else if(rejectConnName.equals(firstConnName)){
    stringBuffer.append(TEXT_291);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_292);
    }
        } 
        
    stringBuffer.append(TEXT_293);
    			
			}
		}
		if (conns.size()>0) {	
			boolean isFirstEnter = true;
			for (int i=0;i<conns.size();i++) {
				IConnection conn = conns.get(i);
				if ((conn.getName().compareTo(firstConnName)!=0)&&(conn.getName().compareTo(rejectConnName)!=0)&&(conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA))) {

    stringBuffer.append(TEXT_294);
     if(isFirstEnter) {
    stringBuffer.append(TEXT_295);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_296);
     isFirstEnter = false; } 
    stringBuffer.append(TEXT_297);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_298);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_299);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_300);
    
			    	 for (IMetadataColumn column: metadata.getListColumns()) {

    stringBuffer.append(TEXT_301);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_302);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_303);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_304);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_305);
    
				 	}
				}
			}

    stringBuffer.append(TEXT_306);
     if(!isFirstEnter) {
    stringBuffer.append(TEXT_307);
     } 
    stringBuffer.append(TEXT_308);
    
		}
	}
		}
	}

    stringBuffer.append(TEXT_309);
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  }

    return stringBuffer.toString();
  }
}
