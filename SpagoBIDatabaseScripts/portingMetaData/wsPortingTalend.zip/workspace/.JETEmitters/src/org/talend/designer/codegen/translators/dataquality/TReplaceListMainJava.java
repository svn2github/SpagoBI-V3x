package org.talend.designer.codegen.translators.dataquality;

import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.EConnectionType;
import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import org.talend.commons.utils.StringUtils;

public class TReplaceListMainJava
{
  protected static String nl;
  public static synchronized TReplaceListMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TReplaceListMainJava result = new TReplaceListMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "String inputFlow";
  protected final String TEXT_3 = " = ";
  protected final String TEXT_4 = ".";
  protected final String TEXT_5 = ";" + NL + "for(Object o:replace_";
  protected final String TEXT_6 = ".keySet()){" + NL + "    String search";
  protected final String TEXT_7 = " = (String)o;" + NL + "    String replace";
  protected final String TEXT_8 = " = replace_";
  protected final String TEXT_9 = ".get(o);" + NL + "    inputFlow";
  protected final String TEXT_10 = " = inputFlow";
  protected final String TEXT_11 = ".replaceAll(search";
  protected final String TEXT_12 = ",replace";
  protected final String TEXT_13 = ");" + NL + "}";
  protected final String TEXT_14 = NL + "        ";
  protected final String TEXT_15 = ".";
  protected final String TEXT_16 = " = inputFlow";
  protected final String TEXT_17 = ";" + NL;
  protected final String TEXT_18 = NL;
  protected final String TEXT_19 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;

INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();

List<Map<String, String>> columnOptions =
    (List<Map<String,String>>)ElementParameterParser.getObjectValue(
        node,
        "__COLUMN_OPTIONS__"
    );


List<IMetadataTable> metadatas = node.getMetadataList();
if (metadatas != null && metadatas.size() > 0) {
    List<IConnection> inputConnections;
    List<IConnection> outputConnections;
    String main = null;
    inputConnections = (List<IConnection>) node.getIncomingConnections();
    outputConnections = (List<IConnection>) node.getOutgoingConnections();
    for (IConnection connection : inputConnections) {
        if (connection == null) {
            continue;
        }

        if (connection.getLineStyle() == EConnectionType.FLOW_MAIN) {
            main = connection.getName();
            continue;
        }
    }

    IMetadataTable metadata = metadatas.get(0);

    int column_num = 0;
    for (Map<String, String> columnOption: columnOptions) {
        if (columnOption.get("REPLACE").equals("true")) {
            String columnName = metadata.getListColumns().get(column_num).getLabel();

    stringBuffer.append(TEXT_2);
    stringBuffer.append(columnName);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(main);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(columnName);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(columnName);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(columnName);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_13);
    
        }
        column_num++;
    }
    
    //output
    int outColumn_num=0;
    for (IConnection connection : outputConnections){
        String outConName = connection.getName();
        for(Map<String,String> columnOption: columnOptions){
          if (columnOption.get("REPLACE").equals("true")){
              String columnname = connection.getTarget().getMetadataList().get(0).getListColumns().get(outColumn_num).getLabel();

    stringBuffer.append(TEXT_14);
    stringBuffer.append(main);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(columnname);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(columnname);
    stringBuffer.append(TEXT_17);
    
          }
          outColumn_num ++;
       }
       
    }
    
    

    stringBuffer.append(TEXT_18);
    
}

    stringBuffer.append(TEXT_19);
    return stringBuffer.toString();
  }
}
