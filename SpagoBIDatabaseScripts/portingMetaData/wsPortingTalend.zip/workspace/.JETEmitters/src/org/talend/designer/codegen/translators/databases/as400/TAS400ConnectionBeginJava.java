package org.talend.designer.codegen.translators.databases.as400;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.designer.codegen.config.CodeGeneratorArgument;

public class TAS400ConnectionBeginJava
{
  protected static String nl;
  public static synchronized TAS400ConnectionBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TAS400ConnectionBeginJava result = new TAS400ConnectionBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "int nb_line_";
  protected final String TEXT_3 = " = 0;" + NL + "" + NL + "java.lang.Class.forName(\"com.ibm.as400.access.AS400JDBCDriver\");";
  protected final String TEXT_4 = NL + "    String url_";
  protected final String TEXT_5 = " = \"jdbc:as400://\" + ";
  protected final String TEXT_6 = " + \"/\" + ";
  protected final String TEXT_7 = ";";
  protected final String TEXT_8 = NL + "\tString url_";
  protected final String TEXT_9 = " = \"jdbc:as400://\" + ";
  protected final String TEXT_10 = " + \"/\" + ";
  protected final String TEXT_11 = " + \";\" + ";
  protected final String TEXT_12 = ";";
  protected final String TEXT_13 = NL + NL + "String dbUser_";
  protected final String TEXT_14 = " = ";
  protected final String TEXT_15 = ";" + NL + "" + NL + "String dbPwd_";
  protected final String TEXT_16 = " = ";
  protected final String TEXT_17 = ";" + NL + "" + NL + "java.sql.Connection conn_";
  protected final String TEXT_18 = " = java.sql.DriverManager.getConnection(url_";
  protected final String TEXT_19 = ",dbUser_";
  protected final String TEXT_20 = ",dbPwd_";
  protected final String TEXT_21 = ");" + NL + "" + NL + "conn_";
  protected final String TEXT_22 = ".setAutoCommit(false);" + NL + "" + NL + "globalMap.put(\"conn_\" + \"";
  protected final String TEXT_23 = "\",conn_";
  protected final String TEXT_24 = ");";
  protected final String TEXT_25 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
    CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
    INode node = (INode)codeGenArgument.getArgument();
	
    String cid = node.getUniqueName();
    String dbhost = ElementParameterParser.getValue(node, "__HOST__");
    String dbname= ElementParameterParser.getValue(node, "__DBNAME__");
    String dbuser= ElementParameterParser.getValue(node, "__USER__");
    String dbpwd= ElementParameterParser.getValue(node, "__PASS__");
    String dbproperties = ElementParameterParser.getValue(node, "__PROPERTIES__");

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_3);
    
if(dbproperties == null || dbproperties.equals("\"\"") || dbproperties.equals("")) {
    
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_5);
    stringBuffer.append(dbhost);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(dbname);
    stringBuffer.append(TEXT_7);
    }else
{
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_9);
    stringBuffer.append(dbhost);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(dbname);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(dbproperties);
    stringBuffer.append(TEXT_12);
    }
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_14);
    stringBuffer.append(dbuser);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_16);
    stringBuffer.append(dbpwd);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_21);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_23);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(TEXT_25);
    return stringBuffer.toString();
  }
}
