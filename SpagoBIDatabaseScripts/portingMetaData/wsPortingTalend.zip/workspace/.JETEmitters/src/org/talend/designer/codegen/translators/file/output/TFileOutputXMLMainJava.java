package org.talend.designer.codegen.translators.file.output;

import org.talend.core.model.process.INode;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.process.ElementParameterParser;
import java.util.List;
import java.util.Map;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;
import org.talend.core.model.process.IConnection;

public class TFileOutputXMLMainJava
{
  protected static String nl;
  public static synchronized TFileOutputXMLMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileOutputXMLMainJava result = new TFileOutputXMLMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "String tempSt_";
  protected final String TEXT_3 = " = null;" + NL + "" + NL + "boolean flag_";
  protected final String TEXT_4 = " = true;" + NL + " " + NL + "groupby_new_";
  protected final String TEXT_5 = " = 0;" + NL;
  protected final String TEXT_6 = "tempSt_";
  protected final String TEXT_7 = " = \"<";
  protected final String TEXT_8 = " ";
  protected final String TEXT_9 = "=\\\"\"+";
  protected final String TEXT_10 = "FormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_11 = ".";
  protected final String TEXT_12 = ".doubleValue()), ";
  protected final String TEXT_13 = ", ";
  protected final String TEXT_14 = ")";
  protected final String TEXT_15 = "FormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_16 = ".";
  protected final String TEXT_17 = "), ";
  protected final String TEXT_18 = ", ";
  protected final String TEXT_19 = ")";
  protected final String TEXT_20 = ".";
  protected final String TEXT_21 = "((";
  protected final String TEXT_22 = ".";
  protected final String TEXT_23 = " == null)?\"\":(";
  protected final String TEXT_24 = "TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_25 = "FormatterUtils.format_Date(";
  protected final String TEXT_26 = ".";
  protected final String TEXT_27 = ", ";
  protected final String TEXT_28 = ")";
  protected final String TEXT_29 = ")";
  protected final String TEXT_30 = "TalendString.replaceSpecialCharForXML(java.nio.charset.Charset.defaultCharset().decode(java.nio.ByteBuffer.wrap(";
  protected final String TEXT_31 = ".";
  protected final String TEXT_32 = ")).toString())";
  protected final String TEXT_33 = "TalendString.replaceSpecialCharForXML(String.valueof(";
  protected final String TEXT_34 = ".";
  protected final String TEXT_35 = ".doublevalue()))";
  protected final String TEXT_36 = "TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_37 = ".";
  protected final String TEXT_38 = ")";
  protected final String TEXT_39 = "))";
  protected final String TEXT_40 = "+\"\\\">\";" + NL + "" + NL + "if(!groupby_";
  protected final String TEXT_41 = "[";
  protected final String TEXT_42 = "][0].equals(tempSt_";
  protected final String TEXT_43 = ")){" + NL + "\t" + NL + "\tif(flag_";
  protected final String TEXT_44 = "){" + NL + "\t" + NL + "\t\tgroupby_new_";
  protected final String TEXT_45 = " = ";
  protected final String TEXT_46 = ";" + NL + "" + NL + "\t\tflag_";
  protected final String TEXT_47 = " = false;" + NL + "\t\t" + NL + "\t\tfor(int i_";
  protected final String TEXT_48 = " = ";
  protected final String TEXT_49 = "; i_";
  protected final String TEXT_50 = " >= groupby_new_";
  protected final String TEXT_51 = " && start_";
  protected final String TEXT_52 = "; i_";
  protected final String TEXT_53 = "--){" + NL + "" + NL + "\t\t\tout_";
  protected final String TEXT_54 = ".write(groupby_";
  protected final String TEXT_55 = "[i_";
  protected final String TEXT_56 = "][1]);" + NL + "\t" + NL + "\t\t\tout_";
  protected final String TEXT_57 = ".newLine();" + NL + "\t" + NL + "\t\t}\t" + NL + "\t}" + NL + "" + NL + "\tgroupby_";
  protected final String TEXT_58 = "[";
  protected final String TEXT_59 = "][0] = tempSt_";
  protected final String TEXT_60 = ";" + NL + "\t" + NL + "\tout_";
  protected final String TEXT_61 = ".write(tempSt_";
  protected final String TEXT_62 = ");" + NL + "" + NL + "\tout_";
  protected final String TEXT_63 = ".newLine();" + NL + "\t" + NL + "\tif(!start_";
  protected final String TEXT_64 = "){" + NL + "\t\t\t" + NL + "\t\tstart_";
  protected final String TEXT_65 = " = true;" + NL + "\t\t\t" + NL + "\t}" + NL + "\t\t" + NL + "}else if(!flag_";
  protected final String TEXT_66 = "){" + NL + "\t" + NL + "\tout_";
  protected final String TEXT_67 = ".write(tempSt_";
  protected final String TEXT_68 = ");" + NL + "\t" + NL + "\tout_";
  protected final String TEXT_69 = ".newLine();" + NL + "\t" + NL + "\tif(!start_";
  protected final String TEXT_70 = "){" + NL + "\t\t\t" + NL + "\t\tstart_";
  protected final String TEXT_71 = " = true;" + NL + "\t\t\t" + NL + "\t}" + NL + "\t" + NL + "}" + NL;
  protected final String TEXT_72 = "StringBuilder tempRes_";
  protected final String TEXT_73 = " = new StringBuilder(\"<\"+";
  protected final String TEXT_74 = ");" + NL;
  protected final String TEXT_75 = "tempRes_";
  protected final String TEXT_76 = ".append(\" ";
  protected final String TEXT_77 = "=\\\"\"+";
  protected final String TEXT_78 = "FormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_79 = ".";
  protected final String TEXT_80 = ".doubleValue()), ";
  protected final String TEXT_81 = ", ";
  protected final String TEXT_82 = ")";
  protected final String TEXT_83 = "FormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_84 = ".";
  protected final String TEXT_85 = "), ";
  protected final String TEXT_86 = ", ";
  protected final String TEXT_87 = ")";
  protected final String TEXT_88 = ".";
  protected final String TEXT_89 = "((";
  protected final String TEXT_90 = ".";
  protected final String TEXT_91 = " == null)?\"\":(";
  protected final String TEXT_92 = "TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_93 = "FormatterUtils.format_Date(";
  protected final String TEXT_94 = ".";
  protected final String TEXT_95 = ", ";
  protected final String TEXT_96 = ")";
  protected final String TEXT_97 = ")";
  protected final String TEXT_98 = "TalendString.replaceSpecialCharForXML(java.nio.charset.Charset.defaultCharset().decode(java.nio.ByteBuffer.wrap(";
  protected final String TEXT_99 = ".";
  protected final String TEXT_100 = ")).toString())";
  protected final String TEXT_101 = "TalendString.replaceSpecialCharForXML(String.valueof(";
  protected final String TEXT_102 = ".";
  protected final String TEXT_103 = ".doublevalue()))";
  protected final String TEXT_104 = "TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_105 = ".";
  protected final String TEXT_106 = ")";
  protected final String TEXT_107 = "))";
  protected final String TEXT_108 = "+\"\\\"\");" + NL;
  protected final String TEXT_109 = "tempRes_";
  protected final String TEXT_110 = ".append(\">\");" + NL;
  protected final String TEXT_111 = "tempRes_";
  protected final String TEXT_112 = ".append(\"/>\");" + NL;
  protected final String TEXT_113 = "out_";
  protected final String TEXT_114 = ".write(tempRes_";
  protected final String TEXT_115 = ".toString());" + NL + "" + NL + "out_";
  protected final String TEXT_116 = ".newLine();" + NL;
  protected final String TEXT_117 = "out_";
  protected final String TEXT_118 = ".write(\"<";
  protected final String TEXT_119 = ">\"+";
  protected final String TEXT_120 = "FormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_121 = ".";
  protected final String TEXT_122 = ".doubleValue()), ";
  protected final String TEXT_123 = ", ";
  protected final String TEXT_124 = ")";
  protected final String TEXT_125 = "FormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_126 = ".";
  protected final String TEXT_127 = "), ";
  protected final String TEXT_128 = ", ";
  protected final String TEXT_129 = ")";
  protected final String TEXT_130 = ".";
  protected final String TEXT_131 = "((";
  protected final String TEXT_132 = ".";
  protected final String TEXT_133 = " == null)?\"\":(";
  protected final String TEXT_134 = "TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_135 = "FormatterUtils.format_Date(";
  protected final String TEXT_136 = ".";
  protected final String TEXT_137 = ", ";
  protected final String TEXT_138 = ")";
  protected final String TEXT_139 = ")";
  protected final String TEXT_140 = "TalendString.replaceSpecialCharForXML(java.nio.charset.Charset.defaultCharset().decode(java.nio.ByteBuffer.wrap(";
  protected final String TEXT_141 = ".";
  protected final String TEXT_142 = ")).toString())";
  protected final String TEXT_143 = "TalendString.replaceSpecialCharForXML(String.valueof(";
  protected final String TEXT_144 = ".";
  protected final String TEXT_145 = ".doublevalue()))";
  protected final String TEXT_146 = "TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_147 = ".";
  protected final String TEXT_148 = ")";
  protected final String TEXT_149 = "))";
  protected final String TEXT_150 = "+\"</";
  protected final String TEXT_151 = ">\");" + NL + "" + NL + "out_";
  protected final String TEXT_152 = ".newLine();" + NL;
  protected final String TEXT_153 = "out_";
  protected final String TEXT_154 = ".write(\"</\"+";
  protected final String TEXT_155 = "+\">\");" + NL + "" + NL + "out_";
  protected final String TEXT_156 = ".newLine();" + NL;
  protected final String TEXT_157 = NL;
  protected final String TEXT_158 = NL + "    if(nb_line_";
  protected final String TEXT_159 = "%";
  protected final String TEXT_160 = " == 0) {" + NL + "    out_";
  protected final String TEXT_161 = ".flush();" + NL + "    }";
  protected final String TEXT_162 = NL + "nb_line_";
  protected final String TEXT_163 = "++;" + NL;
  protected final String TEXT_164 = NL + "currentRowCount_";
  protected final String TEXT_165 = "++;" + NL + "if(currentRowCount_";
  protected final String TEXT_166 = " == ";
  protected final String TEXT_167 = "){";
  protected final String TEXT_168 = NL + "out_";
  protected final String TEXT_169 = ".write(groupby_";
  protected final String TEXT_170 = "[";
  protected final String TEXT_171 = "][1]);" + NL + "out_";
  protected final String TEXT_172 = ".newLine();\t\t";
  protected final String TEXT_173 = NL + "out_";
  protected final String TEXT_174 = ".write(footers_";
  protected final String TEXT_175 = "[";
  protected final String TEXT_176 = "]);" + NL + "out_";
  protected final String TEXT_177 = ".newLine();";
  protected final String TEXT_178 = "\t" + NL + "\tout_";
  protected final String TEXT_179 = ".close();" + NL + "\tcurrentFileCount_";
  protected final String TEXT_180 = "++;";
  protected final String TEXT_181 = NL + "\tout_";
  protected final String TEXT_182 = " = new java.io.BufferedWriter(new java.io.OutputStreamWriter(" + NL + "\tnew java.io.FileOutputStream(";
  protected final String TEXT_183 = "\"+currentFileCount_";
  protected final String TEXT_184 = "+\".xml\"), ";
  protected final String TEXT_185 = "));";
  protected final String TEXT_186 = NL + "\tout_";
  protected final String TEXT_187 = " = new java.io.BufferedWriter(new java.io.OutputStreamWriter(" + NL + "\tnew java.io.FileOutputStream(prefix_fn_";
  protected final String TEXT_188 = "+currentFileCount_";
  protected final String TEXT_189 = "+\".xml\"), ";
  protected final String TEXT_190 = "));";
  protected final String TEXT_191 = NL + "\tstart_";
  protected final String TEXT_192 = " = false;  ";
  protected final String TEXT_193 = "\t" + NL + "\tout_";
  protected final String TEXT_194 = ".write(headers_";
  protected final String TEXT_195 = "[";
  protected final String TEXT_196 = "]);" + NL + "\tout_";
  protected final String TEXT_197 = ".newLine();";
  protected final String TEXT_198 = "\t" + NL + "\tgroupby_";
  protected final String TEXT_199 = "[";
  protected final String TEXT_200 = "][0] = \"\";";
  protected final String TEXT_201 = "\t" + NL + "    currentRowCount_";
  protected final String TEXT_202 = " = 0;" + NL + "}";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();
List<IMetadataTable> metadatas = node.getMetadataList();
if ((metadatas!=null)&&(metadatas.size()>0)) {
    IMetadataTable metadata = metadatas.get(0);
    if (metadata!=null) {
    boolean flushOnRow = ElementParameterParser.getValue(node, "__FLUSHONROW__").equals("true"); 
    String flushMod = ElementParameterParser.getValue(node, "__FLUSHONROW_NUM__");       
    String split = ElementParameterParser.getValue(node, "__SPLIT__");
	String encoding = ElementParameterParser.getValue(node, "__ENCODING__");
	String fileName = ElementParameterParser.getValue(node, "__FILENAME__");
	List rootTags = (List)ElementParameterParser.getObjectValue(node, "__ROOT_TAGS__");
    int footers = rootTags.size();
    List<Map<String, String>> columnMapping = 
    		(List<Map<String,String>>)ElementParameterParser.getObjectValue(
                node,
                "__MAPPING__"
            );
    String useDynamicGrouping = ElementParameterParser.getValue(
            node,
            "__USE_DYNAMIC_GROUPING__"
        );
    List<Map<String, String>> groupBys =
            (List<Map<String,String>>)ElementParameterParser.getObjectValue(
                node,
                "__GROUP_BY__"
            );
            
    String advancedSeparatorStr = ElementParameterParser.getValue(node, "__ADVANCED_SEPARATOR__");
	boolean advancedSeparator = (advancedSeparatorStr!=null&&!advancedSeparatorStr.equals(""))?advancedSeparatorStr.equals("true"):false;
	String thousandsSeparator = ElementParameterParser.getValue(node, "__THOUSANDS_SEPARATOR__");
	String decimalSeparator = ElementParameterParser.getValue(node, "__DECIMAL_SEPARATOR__");
	
    if (useDynamicGrouping.equals("false")) {
        groupBys.clear();
    }
    if (encoding!=null) {
        if (encoding.equals("")) {
                encoding = "ISO-8859-15";
        }
    }
    String groupby[][] = new String[groupBys.size()][3];
    for(int i = 0; i < groupBys.size(); i++){
    	groupby[i][0] = groupBys.get(i).get("COLUMN");
    	groupby[i][1] = groupBys.get(i).get("LABEL");
    }
    int atts = 0;
    int tags = 0;
    outter1:
    for(int i = 0; i < columnMapping.size(); i++){
    	Map<String, String> map = columnMapping.get(i);
    	String col = metadata.getListColumns().get(i).getLabel();
    	for(int j = 0; j < groupby.length; j++){
    		if(groupby[j][0].equals(col)){
    			if(map.get("SCHEMA_COLUMN_NAME").equals("true")){
    				groupby[j][2] = col;
    			}else{
    				groupby[j][2] = map.get("LABEL");
    			}
    			continue outter1;
    		}
    	}
    	if(map.get("AS_ATTRIBUTE").equals("true")){
    		atts ++;
    	}else{
    		tags ++;
    	}
    }
    String[][] attribute = new String[atts][2];
    String[][] tag = new String[tags][2];
    int ia=0;
    int it=0;
    outter2:
    for(int i = 0; i < columnMapping.size(); i++){
    	Map<String, String> map = columnMapping.get(i);
    	String col = metadata.getListColumns().get(i).getLabel();
    	for(int j = 0; j < groupby.length; j++){
    		if(groupby[j][0].equals(col)){
    			continue outter2;
    		}
    	}
    	if(map.get("AS_ATTRIBUTE").equals("true")){
    		if(map.get("SCHEMA_COLUMN_NAME").equals("true")){
    			attribute[ia][1] = col;
    		}else{
    			attribute[ia][1] = map.get("LABEL");
    		}
    		attribute[ia++][0] = col;
    	}else{
    		if(map.get("SCHEMA_COLUMN_NAME").equals("true")){
    			tag[it][1] = col;
    		}else{
    			tag[it][1] = map.get("LABEL");
    		}
    	    tag[it++][0] = col;
    	}
    }
	if(groupby.length>0){

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_5);
    
	}

    
	List< ? extends IConnection> conns = node.getIncomingConnections();
	if(conns!=null && conns.size()>0){
		IConnection conn = conns.get(0);
		for(int i = 0; i < groupby.length; i++){
			boolean needReplace = false;
			boolean isDate = false;
			boolean isByteArray = false;
			String pattern = null;
			boolean isPrimitive = false;
			boolean isBigDecimal = false;
			boolean isAdvancedSeparator = false;
			for(IMetadataColumn column:metadata.getListColumns()) {
				if(column.getLabel().equals(groupby[i][0])){
					JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
					if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.STRING){
						needReplace = true;
					}
					if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.DATE){
						pattern = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
						if(pattern != null && (pattern.contains("&") || pattern.contains("<") || pattern.contains(">") || pattern.contains("'") || pattern.contains("\""))){
							needReplace = true;
						}
						isDate = true;
					}
					if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.BYTE_ARRAY){
						isByteArray = true;
					}else if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.BIGDECIMAL){
						isBigDecimal = true;
					}
					isPrimitive = JavaTypesManager.isJavaPrimitiveType( column.getTalendType(), column.isNullable());
					
					isAdvancedSeparator = advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable());
					break;
				}
			}

    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_7);
    stringBuffer.append(groupby[i][2] );
    stringBuffer.append(TEXT_8);
    stringBuffer.append(groupby[i][1] );
    stringBuffer.append(TEXT_9);
    
							if(isAdvancedSeparator){
								if(isBigDecimal){
								
    stringBuffer.append(TEXT_10);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_11);
    stringBuffer.append(groupby[i][0] );
    stringBuffer.append(TEXT_12);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_13);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_14);
    
								}else {
								
    stringBuffer.append(TEXT_15);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_16);
    stringBuffer.append(groupby[i][0] );
    stringBuffer.append(TEXT_17);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_18);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_19);
    
								}
							}else if(isPrimitive){
								
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_20);
    stringBuffer.append(groupby[i][0] );
    
							}else{
								
    stringBuffer.append(TEXT_21);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_22);
    stringBuffer.append(groupby[i][0] );
    stringBuffer.append(TEXT_23);
    
									if(isDate && pattern != null){
									
    if(needReplace){
    stringBuffer.append(TEXT_24);
    }
    stringBuffer.append(TEXT_25);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_26);
    stringBuffer.append(groupby[i][0] );
    stringBuffer.append(TEXT_27);
    stringBuffer.append(pattern );
    stringBuffer.append(TEXT_28);
    if(needReplace){
    stringBuffer.append(TEXT_29);
    }
    
									}else if(isByteArray){
									
    stringBuffer.append(TEXT_30);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_31);
    stringBuffer.append(groupby[i][0] );
    stringBuffer.append(TEXT_32);
    
									}else if(isBigDecimal){
									
    stringBuffer.append(TEXT_33);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_34);
    stringBuffer.append(tag[i][0] );
    stringBuffer.append(TEXT_35);
    
									}else{
									
    if(needReplace){
    stringBuffer.append(TEXT_36);
    }
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_37);
    stringBuffer.append(groupby[i][0] );
    if(needReplace){
    stringBuffer.append(TEXT_38);
    }
    
									}
    stringBuffer.append(TEXT_39);
    
							}
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_41);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_43);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_45);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_46);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_48);
    stringBuffer.append(groupby.length-1 );
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_50);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_51);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_52);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_53);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_54);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_55);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_56);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_57);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_58);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_59);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_62);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_63);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_64);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_65);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_66);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_67);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_68);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_69);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_70);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_71);
    
		}

    stringBuffer.append(TEXT_72);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_73);
    stringBuffer.append(ElementParameterParser.getValue(node, "__ROW_TAG__"));
    stringBuffer.append(TEXT_74);
    
for(int i = 0; i < attribute.length; i++){
	boolean needReplace = false;
	boolean isDate = false;
	boolean isByteArray = false;
	String pattern = null;
	boolean isPrimitive = false;
	boolean isBigDecimal = false;
	boolean isAdvancedSeparator = false;
	for(IMetadataColumn column:metadata.getListColumns()) {
		if(column.getLabel().equals(attribute[i][0])){
			JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
			if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.STRING){
				needReplace = true;
			}
			if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.DATE){
				pattern = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
				if(pattern != null && (pattern.contains("&") || pattern.contains("<") || pattern.contains(">") || pattern.contains("'") || pattern.contains("\""))){
					needReplace = true;
				}
				isDate = true;
			}
			if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.BYTE_ARRAY){
				isByteArray = true;
			}else if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.BIGDECIMAL){
				isBigDecimal = true;
			}
			isPrimitive = JavaTypesManager.isJavaPrimitiveType( column.getTalendType(), column.isNullable());
			
			isAdvancedSeparator = advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable());
			break;
		}
	}

    stringBuffer.append(TEXT_75);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_76);
    stringBuffer.append(attribute[i][1] );
    stringBuffer.append(TEXT_77);
    
							if(isAdvancedSeparator){
								if(isBigDecimal){
								
    stringBuffer.append(TEXT_78);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_79);
    stringBuffer.append(attribute[i][0] );
    stringBuffer.append(TEXT_80);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_81);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_82);
    
								}else {
								
    stringBuffer.append(TEXT_83);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_84);
    stringBuffer.append(attribute[i][0] );
    stringBuffer.append(TEXT_85);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_86);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_87);
    
								}
							}else if(isPrimitive){
								
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_88);
    stringBuffer.append(attribute[i][0] );
    
							}else{
								
    stringBuffer.append(TEXT_89);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_90);
    stringBuffer.append(attribute[i][0] );
    stringBuffer.append(TEXT_91);
    
									if(isDate && pattern != null){
									
    if(needReplace){
    stringBuffer.append(TEXT_92);
    }
    stringBuffer.append(TEXT_93);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_94);
    stringBuffer.append(attribute[i][0] );
    stringBuffer.append(TEXT_95);
    stringBuffer.append(pattern );
    stringBuffer.append(TEXT_96);
    if(needReplace){
    stringBuffer.append(TEXT_97);
    }
    
									}else if(isByteArray){
									
    stringBuffer.append(TEXT_98);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_99);
    stringBuffer.append(attribute[i][0] );
    stringBuffer.append(TEXT_100);
    
									}else if(isBigDecimal){
									
    stringBuffer.append(TEXT_101);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_102);
    stringBuffer.append(tag[i][0] );
    stringBuffer.append(TEXT_103);
    
									}else{
									
    if(needReplace){
    stringBuffer.append(TEXT_104);
    }
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_105);
    stringBuffer.append(attribute[i][0] );
    if(needReplace){
    stringBuffer.append(TEXT_106);
    }
    
									}
    stringBuffer.append(TEXT_107);
    
							}
    stringBuffer.append(TEXT_108);
    
}

    
if(tags > 0){

    stringBuffer.append(TEXT_109);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_110);
    
}else{

    stringBuffer.append(TEXT_111);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_112);
    
}

    stringBuffer.append(TEXT_113);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_114);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_115);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_116);
    
for(int i = 0; i < tag.length; i++){
	boolean needReplace = false;
	boolean isDate = false;
	boolean isByteArray = false;
	String pattern = null;
	boolean isPrimitive = false;
	boolean isBigDecimal = false;
	boolean isAdvancedSeparator = false;
	for(IMetadataColumn column:metadata.getListColumns()) {
		if(column.getLabel().equals(tag[i][0])){
			JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
			if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.STRING){
				needReplace = true;
			}
			if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.DATE){
				pattern = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
				if(pattern != null && (pattern.contains("&") || pattern.contains("<") || pattern.contains(">") || pattern.contains("'") || pattern.contains("\""))){
					needReplace = true;
				}
				isDate = true;
			}
			if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.BYTE_ARRAY){
				isByteArray = true;
			}else if(JavaTypesManager.getJavaTypeFromId(column.getTalendType()) == JavaTypesManager.BIGDECIMAL){
				isBigDecimal = true;
			}
			isPrimitive = JavaTypesManager.isJavaPrimitiveType( column.getTalendType(), column.isNullable());
			isAdvancedSeparator = advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable());
			break;
		}
	}

    stringBuffer.append(TEXT_117);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_118);
    stringBuffer.append(tag[i][1]);
    stringBuffer.append(TEXT_119);
    
							if(isAdvancedSeparator){
								if(isBigDecimal){
								
    stringBuffer.append(TEXT_120);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_121);
    stringBuffer.append(tag[i][0] );
    stringBuffer.append(TEXT_122);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_123);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_124);
    
								}else {
								
    stringBuffer.append(TEXT_125);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_126);
    stringBuffer.append(tag[i][0] );
    stringBuffer.append(TEXT_127);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_128);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_129);
    
								}
							}else if(isPrimitive){
								
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_130);
    stringBuffer.append(tag[i][0] );
    
							}else{
								
    stringBuffer.append(TEXT_131);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_132);
    stringBuffer.append(tag[i][0] );
    stringBuffer.append(TEXT_133);
    
									if(isDate && pattern != null){
									
    if(needReplace){
    stringBuffer.append(TEXT_134);
    }
    stringBuffer.append(TEXT_135);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_136);
    stringBuffer.append(tag[i][0] );
    stringBuffer.append(TEXT_137);
    stringBuffer.append(pattern );
    stringBuffer.append(TEXT_138);
    if(needReplace){
    stringBuffer.append(TEXT_139);
    }
    
									}else if(isByteArray){
									
    stringBuffer.append(TEXT_140);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_141);
    stringBuffer.append(tag[i][0] );
    stringBuffer.append(TEXT_142);
    
									}else if(isBigDecimal){
									
    stringBuffer.append(TEXT_143);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_144);
    stringBuffer.append(tag[i][0] );
    stringBuffer.append(TEXT_145);
    
									}else{
									
    if(needReplace){
    stringBuffer.append(TEXT_146);
    }
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_147);
    stringBuffer.append(tag[i][0] );
    if(needReplace){
    stringBuffer.append(TEXT_148);
    }
    
									}
    stringBuffer.append(TEXT_149);
    
							}
    stringBuffer.append(TEXT_150);
    stringBuffer.append(tag[i][1]);
    stringBuffer.append(TEXT_151);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_152);
    
	if(i == tag.length -1){

    stringBuffer.append(TEXT_153);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_154);
    stringBuffer.append(ElementParameterParser.getValue(node, "__ROW_TAG__"));
    stringBuffer.append(TEXT_155);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_156);
    
	}
}

    stringBuffer.append(TEXT_157);
     if(flushOnRow) { 
    stringBuffer.append(TEXT_158);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_159);
    stringBuffer.append(flushMod );
    stringBuffer.append(TEXT_160);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_161);
    
	}

    stringBuffer.append(TEXT_162);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_163);
    
    if(split.equals("true")){

    stringBuffer.append(TEXT_164);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_165);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_166);
    stringBuffer.append(ElementParameterParser.getValue(node, "__SPLIT_EVERY__") );
    stringBuffer.append(TEXT_167);
    
		for(int i = groupby.length - 1; i >=0; i--){

    stringBuffer.append(TEXT_168);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_169);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_170);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_171);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_172);
    
		}
		for(int i = footers - 1; i >= 0 ;i--){

    stringBuffer.append(TEXT_173);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_174);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_175);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_176);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_177);
    
		}

    stringBuffer.append(TEXT_178);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_179);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_180);
    
	if(fileName.startsWith("\"") && fileName.endsWith("\"")){
		String fileNameWithoutExtension =  fileName.substring(0,fileName.indexOf(".xml"));

    stringBuffer.append(TEXT_181);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_182);
    stringBuffer.append(fileNameWithoutExtension);
    stringBuffer.append(TEXT_183);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_184);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_185);
    
	}else{

    stringBuffer.append(TEXT_186);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_187);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_188);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_189);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_190);
    
	}
	if(groupby.length > 0){

    stringBuffer.append(TEXT_191);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_192);
    
	}
	for(int i = 0; i <= footers;i++){

    stringBuffer.append(TEXT_193);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_194);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_195);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_196);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_197);
    
	}
	for(int i = 0; i < groupby.length; i++){

    stringBuffer.append(TEXT_198);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_199);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_200);
    
	}

    stringBuffer.append(TEXT_201);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_202);
    
	}
		}
	}
}

    return stringBuffer.toString();
  }
}
