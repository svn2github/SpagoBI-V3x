package org.talend.designer.codegen.translators.file.output;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.IConnectionCategory;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;
import java.util.ArrayList;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;

public class TFileOutputDelimitedMainJava
{
  protected static String nl;
  public static synchronized TFileOutputDelimitedMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileOutputDelimitedMainJava result = new TFileOutputDelimitedMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL;
  protected final String TEXT_3 = NL + "    \t\t\t\tStringBuilder sb_";
  protected final String TEXT_4 = " = new StringBuilder();" + NL + "    \t\t\t\t\t\t" + NL + "    \t\t\t\t";
  protected final String TEXT_5 = "   \t\t\t\t" + NL + "    \t    \t\t\t\tif(";
  protected final String TEXT_6 = ".";
  protected final String TEXT_7 = " != null) {" + NL + "        \t\t\t\t    ";
  protected final String TEXT_8 = NL + "    \t\t\t\t\tsb_";
  protected final String TEXT_9 = ".append(" + NL + "    \t\t\t        ";
  protected final String TEXT_10 = NL + "    \t\t\t\t\t\tFormatterUtils.format_Date(";
  protected final String TEXT_11 = ".";
  protected final String TEXT_12 = ", ";
  protected final String TEXT_13 = ")" + NL + "    \t\t\t\t\t\t";
  protected final String TEXT_14 = NL + "        \t\t\t\t\t\t\t";
  protected final String TEXT_15 = NL + "        \t\t\t\t\t\t\tFormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_16 = ".";
  protected final String TEXT_17 = ".doubleValue()), ";
  protected final String TEXT_18 = ", ";
  protected final String TEXT_19 = ")\t\t\t\t\t" + NL + "        \t\t\t\t\t\t\t";
  protected final String TEXT_20 = NL + "        \t\t\t\t\t\t\tFormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_21 = ".";
  protected final String TEXT_22 = "), ";
  protected final String TEXT_23 = ", ";
  protected final String TEXT_24 = ")\t\t\t\t\t\t" + NL + "        \t\t\t\t\t\t\t";
  protected final String TEXT_25 = NL + "\t\t\t\t\t\t\t";
  protected final String TEXT_26 = NL + "    \t\t\t\t\t\t";
  protected final String TEXT_27 = ".";
  protected final String TEXT_28 = ".doubleValue()" + NL + "    \t\t\t\t\t\t";
  protected final String TEXT_29 = NL + "    \t\t\t\t\t\t";
  protected final String TEXT_30 = ".";
  protected final String TEXT_31 = NL + "    \t\t\t\t\t\t";
  protected final String TEXT_32 = NL + "    \t\t\t\t\t);" + NL + "    \t\t\t\t\t";
  protected final String TEXT_33 = NL + "    \t\t\t\t\t    } " + NL + "    \t\t\t\t\t";
  protected final String TEXT_34 = "\t\t\t\t\t" + NL + "    \t\t\t            sb_";
  protected final String TEXT_35 = ".append(OUT_DELIM_";
  protected final String TEXT_36 = ");" + NL + "    \t\t\t            ";
  protected final String TEXT_37 = NL + "    \t\t        sb_";
  protected final String TEXT_38 = ".append(OUT_DELIM_ROWSEP_";
  protected final String TEXT_39 = ");" + NL + "    \t\t" + NL + "    \t\t        ";
  protected final String TEXT_40 = NL + "    \t\t            if(currentRow_";
  protected final String TEXT_41 = " % splitEvery_";
  protected final String TEXT_42 = "==0 && currentRow_";
  protected final String TEXT_43 = "!=0){" + NL + "    \t\t                splitedFileNo_";
  protected final String TEXT_44 = "++;" + NL + "    \t\t                out";
  protected final String TEXT_45 = ".close(); " + NL + "    \t\t                //close original outputStream" + NL + "    \t\t                out";
  protected final String TEXT_46 = " = new java.io.BufferedWriter(new java.io.OutputStreamWriter(" + NL + "    \t\t                        new java.io.FileOutputStream(fullName_";
  protected final String TEXT_47 = " + splitedFileNo_";
  protected final String TEXT_48 = " + extension_";
  protected final String TEXT_49 = ", ";
  protected final String TEXT_50 = "),";
  protected final String TEXT_51 = "));" + NL + "    \t\t                file";
  protected final String TEXT_52 = " = new java.io.File(fullName_";
  protected final String TEXT_53 = " + splitedFileNo_";
  protected final String TEXT_54 = " + extension_";
  protected final String TEXT_55 = ");  \t\t\t\t\t" + NL + "    " + NL + "    \t\t                ";
  protected final String TEXT_56 = NL + "    \t\t                    if(file";
  protected final String TEXT_57 = ".length()==0)  " + NL + "    \t\t                    {" + NL + "    \t\t                        ";
  protected final String TEXT_58 = NL + "    \t\t                            out";
  protected final String TEXT_59 = ".write(\"";
  protected final String TEXT_60 = "\");" + NL + "    \t\t                            ";
  protected final String TEXT_61 = NL + "    \t\t                                out";
  protected final String TEXT_62 = ".write(OUT_DELIM_";
  protected final String TEXT_63 = ");" + NL + "    \t\t                                ";
  protected final String TEXT_64 = NL + "    \t\t                        out";
  protected final String TEXT_65 = ".write(OUT_DELIM_ROWSEP_";
  protected final String TEXT_66 = ");" + NL + "    \t\t                    }\t" + NL + "    \t\t                    ";
  protected final String TEXT_67 = NL + "    \t\t                out";
  protected final String TEXT_68 = ".write(sb_";
  protected final String TEXT_69 = ".toString());" + NL + "    \t\t                ";
  protected final String TEXT_70 = NL + "        \t\t                if(nb_line_";
  protected final String TEXT_71 = "%";
  protected final String TEXT_72 = " == 0) {" + NL + "        \t\t                out";
  protected final String TEXT_73 = ".flush();" + NL + "        \t\t                }" + NL + "    \t\t                    ";
  protected final String TEXT_74 = " \t\t\t" + NL + "    \t\t            }else{" + NL + "    \t\t                out";
  protected final String TEXT_75 = ".write(sb_";
  protected final String TEXT_76 = ".toString());" + NL + "    \t\t                ";
  protected final String TEXT_77 = NL + "        \t\t                if(nb_line_";
  protected final String TEXT_78 = "%";
  protected final String TEXT_79 = " == 0) {" + NL + "        \t\t                out";
  protected final String TEXT_80 = ".flush();" + NL + "        \t\t                }" + NL + "    \t\t                    ";
  protected final String TEXT_81 = "  \t\t\t" + NL + "    \t\t            }\t" + NL + "    \t\t            currentRow_";
  protected final String TEXT_82 = "++;\t\t\t\t" + NL + "    \t\t\t" + NL + "    " + NL + "    \t\t            ";
  protected final String TEXT_83 = NL + "    \t\t" + NL + "    \t\t            out";
  protected final String TEXT_84 = ".write(sb_";
  protected final String TEXT_85 = ".toString());" + NL + "    \t\t            ";
  protected final String TEXT_86 = NL + "        \t\t                if(nb_line_";
  protected final String TEXT_87 = "%";
  protected final String TEXT_88 = " == 0) {" + NL + "        \t\t                out";
  protected final String TEXT_89 = ".flush();" + NL + "        \t\t                }" + NL + "    \t\t                ";
  protected final String TEXT_90 = "     \t\t\t" + NL + "    \t\t            ";
  protected final String TEXT_91 = "  \t\t\t" + NL + "    \t\t        nb_line_";
  protected final String TEXT_92 = "++;" + NL + "    \t\t        ";
  protected final String TEXT_93 = NL;
  protected final String TEXT_94 = NL;
  protected final String TEXT_95 = NL + "              \tCsvWriter";
  protected final String TEXT_96 = ".setRecordDelimiter('";
  protected final String TEXT_97 = "');" + NL + "              \t";
  protected final String TEXT_98 = NL + "                CsvWriter";
  protected final String TEXT_99 = ".setEscapeMode(com.csvreader.CsvWriter.ESCAPE_MODE_BACKSLASH);";
  protected final String TEXT_100 = NL + "                CsvWriter";
  protected final String TEXT_101 = ".setEscapeMode(com.csvreader.CsvWriter.ESCAPE_MODE_DOUBLED);";
  protected final String TEXT_102 = NL + "                //doesn't work for other escapeChar";
  protected final String TEXT_103 = NL + "      \t\t" + NL + "      \t\tCsvWriter";
  protected final String TEXT_104 = ".setTextQualifier('";
  protected final String TEXT_105 = "'); " + NL + "      \t\tCsvWriter";
  protected final String TEXT_106 = ".setForceQualifier(true);" + NL + "      \t\t";
  protected final String TEXT_107 = "  \t" + NL + "                    \tString[] row";
  protected final String TEXT_108 = "=new String[";
  protected final String TEXT_109 = "];\t\t" + NL + "                    \t";
  protected final String TEXT_110 = NL + "                \t\t\t    row";
  protected final String TEXT_111 = "[";
  protected final String TEXT_112 = "] =String.valueOf(";
  protected final String TEXT_113 = ".";
  protected final String TEXT_114 = "); " + NL + "                \t\t\t    ";
  protected final String TEXT_115 = NL + "                \t\t\t    if(";
  protected final String TEXT_116 = ".";
  protected final String TEXT_117 = " == null){" + NL + "                \t\t\t        row";
  protected final String TEXT_118 = "[";
  protected final String TEXT_119 = "]=\"\";" + NL + "                \t\t\t    }else{" + NL + "                \t\t\t        ";
  protected final String TEXT_120 = NL + "                \t\t\t            row";
  protected final String TEXT_121 = "[";
  protected final String TEXT_122 = "] = ";
  protected final String TEXT_123 = ".";
  protected final String TEXT_124 = ";" + NL + "                \t\t\t            ";
  protected final String TEXT_125 = NL + "                \t\t\t            row";
  protected final String TEXT_126 = "[";
  protected final String TEXT_127 = "] = FormatterUtils.format_Date(";
  protected final String TEXT_128 = ".";
  protected final String TEXT_129 = ", ";
  protected final String TEXT_130 = ");" + NL + "                \t\t\t            ";
  protected final String TEXT_131 = NL + "                \t\t\t            row";
  protected final String TEXT_132 = "[";
  protected final String TEXT_133 = "] = java.nio.charset.Charset.defaultCharset().decode(java.nio.ByteBuffer.wrap(";
  protected final String TEXT_134 = ".";
  protected final String TEXT_135 = ")).toString();" + NL + "                \t\t\t            ";
  protected final String TEXT_136 = NL + "                \t\t\t\t\t\t\t";
  protected final String TEXT_137 = NL + "                \t\t\t\t\t\t\trow";
  protected final String TEXT_138 = "[";
  protected final String TEXT_139 = "] = FormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_140 = ".";
  protected final String TEXT_141 = ".doubleValue()), ";
  protected final String TEXT_142 = ", ";
  protected final String TEXT_143 = ");\t\t\t\t\t" + NL + "                \t\t\t\t\t\t\t";
  protected final String TEXT_144 = NL + "                \t\t\t\t\t\t\trow";
  protected final String TEXT_145 = "[";
  protected final String TEXT_146 = "] = FormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_147 = ".";
  protected final String TEXT_148 = "), ";
  protected final String TEXT_149 = ", ";
  protected final String TEXT_150 = ");\t\t\t\t\t\t" + NL + "                \t\t\t\t\t\t\t";
  protected final String TEXT_151 = NL + "        \t\t\t\t\t\t\t";
  protected final String TEXT_152 = NL + "\t\t\t\t\t\t\t\t\t\trow";
  protected final String TEXT_153 = "[";
  protected final String TEXT_154 = "] = String.valueOf(";
  protected final String TEXT_155 = ".";
  protected final String TEXT_156 = ".doubleValue());" + NL + "\t\t\t\t\t\t\t\t\t\t";
  protected final String TEXT_157 = NL + "                \t\t\t            row";
  protected final String TEXT_158 = "[";
  protected final String TEXT_159 = "] = String.valueOf(";
  protected final String TEXT_160 = ".";
  protected final String TEXT_161 = ");" + NL + "                \t\t\t            ";
  protected final String TEXT_162 = NL + "                \t\t\t    }" + NL + "                \t\t\t    ";
  protected final String TEXT_163 = NL + "            \t\t\t    if(currentRow_";
  protected final String TEXT_164 = " % splitEvery_";
  protected final String TEXT_165 = "==0 && currentRow_";
  protected final String TEXT_166 = "!=0){" + NL + "            \t\t\t        splitedFileNo_";
  protected final String TEXT_167 = "++;" + NL + "            \t\t\t        CsvWriter";
  protected final String TEXT_168 = ".close(); " + NL + "            \t\t\t        //close original outputStream" + NL + "            \t                CsvWriter";
  protected final String TEXT_169 = " = new com.csvreader.CsvWriter(new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(fullName_";
  protected final String TEXT_170 = " + splitedFileNo_";
  protected final String TEXT_171 = " + extension_";
  protected final String TEXT_172 = ", ";
  protected final String TEXT_173 = "), ";
  protected final String TEXT_174 = ")), '";
  protected final String TEXT_175 = "');" + NL + "            \t\t\t        //set header." + NL + "            \t\t\t        ";
  protected final String TEXT_176 = NL + "            \t\t\t            CsvWriter";
  protected final String TEXT_177 = ".writeRecord(headColu";
  protected final String TEXT_178 = ");\t" + NL + "            \t\t\t            ";
  protected final String TEXT_179 = NL + "                                    file_";
  protected final String TEXT_180 = " = new java.io.File(fullName_";
  protected final String TEXT_181 = " + splitedFileNo_";
  protected final String TEXT_182 = " + extension_";
  protected final String TEXT_183 = ");" + NL + "                        \t\t    if(file_";
  protected final String TEXT_184 = ".length() == 0) {" + NL + "                        \t\t        CsvWriter";
  protected final String TEXT_185 = ".writeRecord(headColu";
  protected final String TEXT_186 = "); " + NL + "                        \t\t    }\t  " + NL + "                        \t\t    ";
  protected final String TEXT_187 = NL + "                        \t\t//initialize new CsvWriter information " + NL + "        \t\t\t\t\t\t";
  protected final String TEXT_188 = NL + "        \t\t\t\t\t\t    CsvWriter";
  protected final String TEXT_189 = ".setRecordDelimiter('";
  protected final String TEXT_190 = "');" + NL + "        \t\t\t\t\t\t    ";
  protected final String TEXT_191 = NL + "        \t\t\t\t\t\t    CsvWriter";
  protected final String TEXT_192 = ".setEscapeMode(com.csvreader.CsvWriter.ESCAPE_MODE_BACKSLASH);" + NL + "        \t\t\t\t\t\t    ";
  protected final String TEXT_193 = NL + "        \t\t\t\t\t\t    CsvWriter";
  protected final String TEXT_194 = ".setEscapeMode(com.csvreader.CsvWriter.ESCAPE_MODE_DOUBLED);" + NL + "        \t\t\t\t\t\t    ";
  protected final String TEXT_195 = NL + "        \t\t\t\t\t\t    //doesn't work for other escapeChar" + NL + "        \t\t\t\t\t\t    ";
  protected final String TEXT_196 = " " + NL + "        \t\t\t\t\t\tCsvWriter";
  protected final String TEXT_197 = ".setTextQualifier('";
  protected final String TEXT_198 = "'); " + NL + "          \t\t\t\t\t\tCsvWriter";
  protected final String TEXT_199 = ".setForceQualifier(true);            \t\t" + NL + "                        \t\tCsvWriter";
  protected final String TEXT_200 = ".writeRecord(row";
  protected final String TEXT_201 = ");" + NL + "                        \t\t";
  protected final String TEXT_202 = NL + "            \t\t                if(nb_line_";
  protected final String TEXT_203 = "%";
  protected final String TEXT_204 = " == 0) {" + NL + "            \t\t                CsvWriter";
  protected final String TEXT_205 = ".flush();" + NL + "            \t\t                }" + NL + "                        \t\t    ";
  protected final String TEXT_206 = " " + NL + "         \t\t\t\t" + NL + "         \t\t\t\t\t}else{" + NL + "         \t\t\t\t\t    CsvWriter";
  protected final String TEXT_207 = ".writeRecord(row";
  protected final String TEXT_208 = ");\t" + NL + "         \t\t\t\t\t    ";
  protected final String TEXT_209 = NL + "            \t\t                if(nb_line_";
  protected final String TEXT_210 = "%";
  protected final String TEXT_211 = " == 0) {" + NL + "            \t\t                CsvWriter";
  protected final String TEXT_212 = ".flush();" + NL + "            \t\t                }" + NL + "         \t\t\t\t\t        ";
  protected final String TEXT_213 = "  \t\t\t\t\t" + NL + "         \t\t\t\t\t}\t" + NL + "            \t\t\t    currentRow_";
  protected final String TEXT_214 = "++;\t\t" + NL + "             \t\t\t" + NL + "            \t\t\t    ";
  protected final String TEXT_215 = NL + "            \t\t\t    CsvWriter";
  protected final String TEXT_216 = ".writeRecord(row";
  protected final String TEXT_217 = ");\t" + NL + "            \t\t\t    ";
  protected final String TEXT_218 = NL + "            \t\t                if(nb_line_";
  protected final String TEXT_219 = "%";
  protected final String TEXT_220 = " == 0) {" + NL + "            \t\t                CsvWriter";
  protected final String TEXT_221 = ".flush();" + NL + "            \t\t                }" + NL + "            \t\t\t        ";
  protected final String TEXT_222 = "  \t\t\t\t" + NL + "            \t\t\t    ";
  protected final String TEXT_223 = NL + "            \t\t\tnb_line_";
  protected final String TEXT_224 = "++;" + NL + "            \t\t\t";
  protected final String TEXT_225 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
     
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();	
if(ElementParameterParser.getValue(node,"__CSV_OPTION__").equals("false")) {	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    stringBuffer.append(TEXT_2);
    
    
    List<IMetadataTable> metadatas = node.getMetadataList();
    if ((metadatas!=null)&&(metadatas.size()>0)) {
        IMetadataTable metadata = metadatas.get(0);
        if (metadata!=null) {
                        
            String fieldSeparator = ElementParameterParser.getValueWithUIFieldKey(
                node,
                "__FIELDSEPARATOR__",
                "FIELDSEPARATOR"
            );
            
            String rowSeparator = ElementParameterParser.getValueWithUIFieldKey(
                node,
                "__ROWSEPARATOR__",
                "ROWSEPARATOR"
            );
            
            String encoding = ElementParameterParser.getValue(
                node,
                "__ENCODING__"
            );
            
            boolean isAppend = ElementParameterParser.getValue(
                node,
                "__APPEND__"
            ).equals("true");
            
            boolean isIncludeHeader = ElementParameterParser.getValue(
                node,
                "__INCLUDEHEADER__"
            ).equals("true");
    		String fileNewname = ElementParameterParser.getValue(node,"__FILENAME__");
    		
    		boolean split = ElementParameterParser.getValue(node, "__SPLIT__").equals("true");
            String splitEvery = ElementParameterParser.getValue(node, "__SPLIT_EVERY__");
            
            boolean flushOnRow = ElementParameterParser.getValue(node, "__FLUSHONROW__").equals("true");
            String flushMod = ElementParameterParser.getValue(node, "__FLUSHONROW_NUM__");
            
    		String advancedSeparatorStr = ElementParameterParser.getValue(node, "__ADVANCED_SEPARATOR__");
    		boolean advancedSeparator = (advancedSeparatorStr!=null&&!advancedSeparatorStr.equals(""))?advancedSeparatorStr.equals("true"):false;
    		String thousandsSeparator = ElementParameterParser.getValue(node, "__THOUSANDS_SEPARATOR__");
    		String decimalSeparator = ElementParameterParser.getValue(node, "__DECIMAL_SEPARATOR__"); 
                
        	List< ? extends IConnection> conns = node.getIncomingConnections();
        	for (IConnection conn : conns) {
        		if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
        		    
    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_4);
      
        			List<IMetadataColumn> columns = metadata.getListColumns();
        			int sizeColumns = columns.size();
        			for (int i = 0; i < sizeColumns; i++) {
      			
        				IMetadataColumn column = columns.get(i);
    					JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
    					boolean isPrimitive = JavaTypesManager.isJavaPrimitiveType( javaType, column.isNullable());
    					if(!isPrimitive) {
    					    
    stringBuffer.append(TEXT_5);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_6);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_7);
    
    				    } 
    				    
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_9);
    
    			        String pattern = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
    			        if (javaType == JavaTypesManager.DATE && pattern != null && pattern.trim().length() != 0) {
    			            
    stringBuffer.append(TEXT_10);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_11);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_12);
    stringBuffer.append( pattern );
    stringBuffer.append(TEXT_13);
    	
    							} else if(advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable())) { 
							
    stringBuffer.append(TEXT_14);
     if(javaType == JavaTypesManager.BIGDECIMAL) {
    stringBuffer.append(TEXT_15);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_16);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_17);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_18);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_19);
     } else { 
    stringBuffer.append(TEXT_20);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_21);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_22);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_23);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_24);
     } 
    stringBuffer.append(TEXT_25);
    
								} else if(javaType == JavaTypesManager.BIGDECIMAL){
    						
    stringBuffer.append(TEXT_26);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_28);
    
    			        } else {
    			            
    stringBuffer.append(TEXT_29);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_30);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_31);
    				
    			        }
    			        
    stringBuffer.append(TEXT_32);
    
    					if(!isPrimitive) {
    					    
    stringBuffer.append(TEXT_33);
    
    			        } 
    			        if(i != sizeColumns - 1) {
    			            
    stringBuffer.append(TEXT_34);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_35);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_36);
    
    			        }
    		        }
    		        
    stringBuffer.append(TEXT_37);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_38);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_39);
     
    		        if(split){ 
    		            
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_43);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_45);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_46);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_48);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_49);
    stringBuffer.append( isAppend);
    stringBuffer.append(TEXT_50);
    stringBuffer.append( encoding);
    stringBuffer.append(TEXT_51);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_52);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_53);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_54);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_55);
    
    		                if(isIncludeHeader){
    		                    
    stringBuffer.append(TEXT_56);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_57);
    		
    		                        //List<IMetadataColumn> columns = metadata.getListColumns();
    		                        //int sizeColumns = columns.size();
    		                        for (int i = 0; i < sizeColumns; i++) {
    		                            IMetadataColumn column = columns.get(i);
    		                            
    stringBuffer.append(TEXT_58);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_59);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_60);
    
    		                            if(i != sizeColumns - 1) {
    		                                
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_62);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_63);
    
    		                            }
    		                        }
    		                        
    stringBuffer.append(TEXT_64);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_65);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_66);
    
    		                }
    		                
    stringBuffer.append(TEXT_67);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_68);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_69);
     
    		                if(flushOnRow) { 
    		                    
    stringBuffer.append(TEXT_70);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_71);
    stringBuffer.append(flushMod );
    stringBuffer.append(TEXT_72);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_73);
    
    		                }
    		                
    stringBuffer.append(TEXT_74);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_75);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_76);
     
    		                if(flushOnRow) { 
    		                    
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_78);
    stringBuffer.append(flushMod );
    stringBuffer.append(TEXT_79);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_80);
    
    		                }
    		                
    stringBuffer.append(TEXT_81);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_82);
     
    		        } else { 
    		            
    stringBuffer.append(TEXT_83);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_84);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_85);
     
    		            if(flushOnRow) { 
    		                
    stringBuffer.append(TEXT_86);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_87);
    stringBuffer.append(flushMod );
    stringBuffer.append(TEXT_88);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_89);
    
    		            }
    		            
    stringBuffer.append(TEXT_90);
    
    		        }
    		        
    stringBuffer.append(TEXT_91);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_92);
    
    	        }
            }
        }
    }
    
    stringBuffer.append(TEXT_93);
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}else{//the following is the tFileOutputCSV component
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    stringBuffer.append(TEXT_94);
    
    
    List<IMetadataTable> metadatas = node.getMetadataList();
    if ((metadatas!=null)&&(metadatas.size()>0)) {
        IMetadataTable metadata = metadatas.get(0);
        if (metadata!=null) {                                    
            String encoding = ElementParameterParser.getValue(node,"__ENCODING__");
    		String delim1 = ElementParameterParser.getValue(node, "__FIELDSEPARATOR__");
        	String delim = delim1.substring(1,delim1.length()-1);
        	boolean isIncludeHeader = ElementParameterParser.getValue(node,"__INCLUDEHEADER__").equals("true");
        	boolean isAppend = ElementParameterParser.getValue(node,"__APPEND__").equals("true");
        	String rowSeparator1 = ElementParameterParser.getValue(node, "__ROWSEPARATOR__");
        	String rowSeparator = rowSeparator1.substring(1,rowSeparator1.length()-1);
        	String escapeChar1 = ElementParameterParser.getValue(node, "__ESCAPE_CHAR__");
        	String escapeChar = escapeChar1.substring(1,escapeChar1.length()-1);
        	String textEnclosure1 = ElementParameterParser.getValue(node, "__TEXT_ENCLOSURE__");
        	String textEnclosure = textEnclosure1.substring(1,textEnclosure1.length()-1);
        	if ("".equals(textEnclosure)) textEnclosure = "\0";
        	boolean split = ElementParameterParser.getValue(node, "__SPLIT__").equals("true");
        	boolean flushOnRow = ElementParameterParser.getValue(node, "__FLUSHONROW__").equals("true");
        	String flushMod = ElementParameterParser.getValue(node, "__FLUSHONROW_NUM__");
        	
    		String advancedSeparatorStr = ElementParameterParser.getValue(node, "__ADVANCED_SEPARATOR__");
    		boolean advancedSeparator = (advancedSeparatorStr!=null&&!advancedSeparatorStr.equals(""))?advancedSeparatorStr.equals("true"):false;
    		String thousandsSeparator = ElementParameterParser.getValue(node, "__THOUSANDS_SEPARATOR__");
    		String decimalSeparator = ElementParameterParser.getValue(node, "__DECIMAL_SEPARATOR__");        	
        	
        	List< ? extends IConnection> conns = node.getIncomingConnections();
          	if(!rowSeparator.equals("\\n") && !rowSeparator.equals("\\r")){
          	    
    stringBuffer.append(TEXT_95);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_96);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_97);
    				
          	}
            if(escapeChar.equals("\\\\")){
                
    stringBuffer.append(TEXT_98);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_99);
    
            }else if(escapeChar.equals(textEnclosure)){
                
    stringBuffer.append(TEXT_100);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_101);
    
            }else{
                
    stringBuffer.append(TEXT_102);
    
            }
            
    stringBuffer.append(TEXT_103);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_104);
    stringBuffer.append(textEnclosure );
    stringBuffer.append(TEXT_105);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_106);
          
     
        	if(conns!=null){
        		if (conns.size()>0){
        		    IConnection conn =conns.get(0);
            		if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
        			List<IMetadataColumn> columns = metadata.getListColumns();
            			int sizeColumns = columns.size();
            			
    stringBuffer.append(TEXT_107);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_108);
    stringBuffer.append(sizeColumns);
    stringBuffer.append(TEXT_109);
    
            			for (int i = 0; i < sizeColumns; i++) {
                			IMetadataColumn column = columns.get(i);
                			JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
                			String pattern = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
                			if(JavaTypesManager.isJavaPrimitiveType( column.getTalendType(), column.isNullable())){
                			    
    stringBuffer.append(TEXT_110);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_111);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_112);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_113);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_114);
    
                			}else { 
                			    
    stringBuffer.append(TEXT_115);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_116);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_117);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_118);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_119);
    					
                			        if(javaType == JavaTypesManager.STRING ){
                			            
    stringBuffer.append(TEXT_120);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_121);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_122);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_123);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_124);
    
                			        }else if(javaType == JavaTypesManager.DATE && pattern != null){
                			            
    stringBuffer.append(TEXT_125);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_126);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_127);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_128);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_129);
    stringBuffer.append( pattern );
    stringBuffer.append(TEXT_130);
    
                			        }else if(javaType == JavaTypesManager.BYTE_ARRAY){
                			            
    stringBuffer.append(TEXT_131);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_132);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_133);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_134);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_135);
    
                			        } else if(advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable())) { 
        							
    stringBuffer.append(TEXT_136);
     if(javaType == JavaTypesManager.BIGDECIMAL) {
    stringBuffer.append(TEXT_137);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_138);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_139);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_140);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_141);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_142);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_143);
     } else { 
    stringBuffer.append(TEXT_144);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_145);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_146);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_147);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_148);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_149);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_150);
     } 
    stringBuffer.append(TEXT_151);
    
        								} else if (javaType == JavaTypesManager.BIGDECIMAL) {
										
    stringBuffer.append(TEXT_152);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_153);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_154);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_155);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_156);
    
                			        }else{
                			            
    stringBuffer.append(TEXT_157);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_158);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_159);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_160);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_161);
    
                			        }
                			        
    stringBuffer.append(TEXT_162);
       			
                			}
            			} 
            			if(split){
            			    
    stringBuffer.append(TEXT_163);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_164);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_165);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_166);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_167);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_168);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_169);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_170);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_171);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_172);
    stringBuffer.append(isAppend);
    stringBuffer.append(TEXT_173);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_174);
    stringBuffer.append(delim);
    stringBuffer.append(TEXT_175);
    
            			        if(isIncludeHeader && !isAppend){
            			            
    stringBuffer.append(TEXT_176);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_177);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_178);
    
            			        }
            			        if(isIncludeHeader && isAppend){
            			            
    stringBuffer.append(TEXT_179);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_180);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_181);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_182);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_183);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_184);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_185);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_186);
    
            			        }
                        		
    stringBuffer.append(TEXT_187);
    
        						if(!rowSeparator.equals("\\n") && !rowSeparator.equals("\\r")){
        						    
    stringBuffer.append(TEXT_188);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_189);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_190);
    
        						}
        						if(escapeChar.equals("\\\\")){
        						    
    stringBuffer.append(TEXT_191);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_192);
    
        						}else if(escapeChar.equals(textEnclosure)){
        						    
    stringBuffer.append(TEXT_193);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_194);
    
        						}else{
        						    
    stringBuffer.append(TEXT_195);
    
        						}
        						
    stringBuffer.append(TEXT_196);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_197);
    stringBuffer.append(textEnclosure );
    stringBuffer.append(TEXT_198);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_199);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_200);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_201);
     
                        		if(flushOnRow) { 
                        		    
    stringBuffer.append(TEXT_202);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_203);
    stringBuffer.append(flushMod );
    stringBuffer.append(TEXT_204);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_205);
    
                    			}
                        		
    stringBuffer.append(TEXT_206);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_207);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_208);
     
         					    if(flushOnRow) { 
         					        
    stringBuffer.append(TEXT_209);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_210);
    stringBuffer.append(flushMod );
    stringBuffer.append(TEXT_211);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_212);
    
         					    }
         					    
    stringBuffer.append(TEXT_213);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_214);
    
            			}else{
            			    
    stringBuffer.append(TEXT_215);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_216);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_217);
     
            			    if(flushOnRow) { 
            			        
    stringBuffer.append(TEXT_218);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_219);
    stringBuffer.append(flushMod );
    stringBuffer.append(TEXT_220);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_221);
    
                			}
            			    
    stringBuffer.append(TEXT_222);
       		
            		
            			}
            			
    stringBuffer.append(TEXT_223);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_224);
       		
            		}
        		
        		}
        	}	
    	
        }
    
    }
    
    stringBuffer.append(TEXT_225);
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

    return stringBuffer.toString();
  }
}
