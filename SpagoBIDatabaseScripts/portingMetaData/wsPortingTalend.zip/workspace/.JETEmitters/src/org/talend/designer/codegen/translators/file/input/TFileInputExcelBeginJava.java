package org.talend.designer.codegen.translators.file.input;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.IConnectionCategory;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;

public class TFileInputExcelBeginJava
{
  protected static String nl;
  public static synchronized TFileInputExcelBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileInputExcelBeginJava result = new TFileInputExcelBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "\t";
  protected final String TEXT_2 = NL + "\t\t" + NL + "\t\tfinal jxl.WorkbookSettings workbookSettings_";
  protected final String TEXT_3 = " = new jxl.WorkbookSettings();" + NL + "        workbookSettings_";
  protected final String TEXT_4 = ".setEncoding(";
  protected final String TEXT_5 = ");" + NL + "        final jxl.Workbook workbook_";
  protected final String TEXT_6 = " = jxl.Workbook.getWorkbook(new java.io.BufferedInputStream(new java.io.FileInputStream(" + NL + "        \t\t\t\t\t\t";
  protected final String TEXT_7 = ")), workbookSettings_";
  protected final String TEXT_8 = ");" + NL + "        final jxl.Sheet sheet_";
  protected final String TEXT_9 = "  = workbook_";
  protected final String TEXT_10 = ".getSheet(";
  protected final String TEXT_11 = ");" + NL + "        if(sheet_";
  protected final String TEXT_12 = " == null){" + NL + "        \tthrow new RuntimeException(\"Sheet \\\"\"+";
  protected final String TEXT_13 = "+\"\\\" not exist!\");" + NL + "        }" + NL + "        int nb_line_";
  protected final String TEXT_14 = " = 0;            " + NL + "" + NL + "        int begin_line_";
  protected final String TEXT_15 = " = ";
  protected final String TEXT_16 = "0";
  protected final String TEXT_17 = ";" + NL + "        int end_line_";
  protected final String TEXT_18 = " = sheet_";
  protected final String TEXT_19 = ".getRows()- ";
  protected final String TEXT_20 = "0";
  protected final String TEXT_21 = ";" + NL + "        int limit_";
  protected final String TEXT_22 = " = ";
  protected final String TEXT_23 = "-1";
  protected final String TEXT_24 = ";" + NL + "        int start_column_";
  protected final String TEXT_25 = " = ";
  protected final String TEXT_26 = "0";
  protected final String TEXT_27 = "-1";
  protected final String TEXT_28 = ";" + NL + "        int end_column_";
  protected final String TEXT_29 = " = ";
  protected final String TEXT_30 = "sheet_";
  protected final String TEXT_31 = ".getColumns()";
  protected final String TEXT_32 = ";" + NL + "" + NL + "        jxl.Cell[] row_";
  protected final String TEXT_33 = " = null;" + NL + "        " + NL + "        for(int i_";
  protected final String TEXT_34 = " = begin_line_";
  protected final String TEXT_35 = "; i_";
  protected final String TEXT_36 = " < end_line_";
  protected final String TEXT_37 = "; i_";
  protected final String TEXT_38 = "++){" + NL + "" + NL + "        \tif (limit_";
  protected final String TEXT_39 = " != -1 && nb_line_";
  protected final String TEXT_40 = " >= limit_";
  protected final String TEXT_41 = ") {" + NL + "        \t\tbreak;" + NL + "        \t}" + NL + "                " + NL + "        \trow_";
  protected final String TEXT_42 = " = sheet_";
  protected final String TEXT_43 = ".getRow(i_";
  protected final String TEXT_44 = ");     " + NL + "        ";
  protected final String TEXT_45 = NL + "    \t\t";
  protected final String TEXT_46 = " = null;\t\t\t";
  protected final String TEXT_47 = NL + "\t\t\tString[] temp_row_";
  protected final String TEXT_48 = " = new String[";
  protected final String TEXT_49 = "];" + NL + "\t\t\tint actual_end_column_";
  protected final String TEXT_50 = " = end_column_";
  protected final String TEXT_51 = " >\trow_";
  protected final String TEXT_52 = ".length ? row_";
  protected final String TEXT_53 = ".length : end_column_";
  protected final String TEXT_54 = ";" + NL + "\t\t\tfor(int i=0;i<";
  protected final String TEXT_55 = ";i++){\t\t\t\t\t\t\t" + NL + "\t\t\t\tif(i + start_column_";
  protected final String TEXT_56 = " < actual_end_column_";
  protected final String TEXT_57 = "){" + NL + "\t\t\t\t\ttemp_row_";
  protected final String TEXT_58 = "[i] = row_";
  protected final String TEXT_59 = "[i + start_column_";
  protected final String TEXT_60 = "].getContents();" + NL + "\t\t\t\t}else{" + NL + "\t\t\t\t\ttemp_row_";
  protected final String TEXT_61 = "[i]=\"\";" + NL + "\t\t\t\t}\t\t\t\t\t\t\t\t" + NL + "\t\t\t}" + NL + "\t\t\t" + NL + "\t\t\tboolean whetherReject_";
  protected final String TEXT_62 = " = false;" + NL + "\t\t\t";
  protected final String TEXT_63 = " = new ";
  protected final String TEXT_64 = "Struct();" + NL + "\t\t\ttry {\t\t\t";
  protected final String TEXT_65 = "\t\t\t\t\t" + NL + "\t\t\tif(temp_row_";
  protected final String TEXT_66 = "[";
  protected final String TEXT_67 = "].length() > 0) {";
  protected final String TEXT_68 = NL + "\t\t\t";
  protected final String TEXT_69 = ".";
  protected final String TEXT_70 = " = temp_row_";
  protected final String TEXT_71 = "[";
  protected final String TEXT_72 = "];";
  protected final String TEXT_73 = "\t\t" + NL + "\t\t\tif(";
  protected final String TEXT_74 = "<actual_end_column_";
  protected final String TEXT_75 = "){" + NL + "\t\t\t\ttry{" + NL + "\t\t\t\t\tjava.util.Date dateGMT_";
  protected final String TEXT_76 = " = ((jxl.DateCell)row_";
  protected final String TEXT_77 = "[";
  protected final String TEXT_78 = " + start_column_";
  protected final String TEXT_79 = "]).getDate();" + NL + "\t\t\t\t\t";
  protected final String TEXT_80 = ".";
  protected final String TEXT_81 = " = new java.util.Date(dateGMT_";
  protected final String TEXT_82 = ".getTime() - java.util.TimeZone.getDefault().getRawOffset());" + NL + "\t\t\t\t}catch(Exception e){" + NL + "\t\t\t\t\tthrow new RuntimeException(\"The cell format is not Date in row \"+(nb_line_";
  protected final String TEXT_83 = "+1)+\" column \"+(";
  protected final String TEXT_84 = " + start_column_";
  protected final String TEXT_85 = "+1));" + NL + "\t\t\t\t}" + NL + "\t\t\t}";
  protected final String TEXT_86 = NL + "\t\t";
  protected final String TEXT_87 = ".";
  protected final String TEXT_88 = " = ParserUtils.parseTo_";
  protected final String TEXT_89 = "(ParserUtils.parseTo_Number(temp_row_";
  protected final String TEXT_90 = "[";
  protected final String TEXT_91 = "], ";
  protected final String TEXT_92 = ", ";
  protected final String TEXT_93 = "));";
  protected final String TEXT_94 = "\t\t\t\t\t\t\t" + NL + "\t\t\t";
  protected final String TEXT_95 = ".";
  protected final String TEXT_96 = " = temp_row_";
  protected final String TEXT_97 = "[";
  protected final String TEXT_98 = "].getBytes(";
  protected final String TEXT_99 = ");" + NL + "\t";
  protected final String TEXT_100 = NL + "\t\t\t";
  protected final String TEXT_101 = ".";
  protected final String TEXT_102 = " = ParserUtils.parseTo_";
  protected final String TEXT_103 = "(temp_row_";
  protected final String TEXT_104 = "[";
  protected final String TEXT_105 = "]);";
  protected final String TEXT_106 = "\t\t\t\t\t" + NL + "\t\t\t}else {";
  protected final String TEXT_107 = NL + "\t\t\t\tthrow new RuntimeException(\"Value is empty for column : '";
  protected final String TEXT_108 = "', value is invalid or this column should be nullable or have a default value.\");";
  protected final String TEXT_109 = NL + "\t\t\t\t";
  protected final String TEXT_110 = ".";
  protected final String TEXT_111 = " = ";
  protected final String TEXT_112 = ";";
  protected final String TEXT_113 = NL + "\t\t}";
  protected final String TEXT_114 = NL + "\t\t\t\t\t";
  protected final String TEXT_115 = " ";
  protected final String TEXT_116 = " = null; ";
  protected final String TEXT_117 = NL + "\t\t\t\t\t" + NL + "    } catch (Exception e) {" + NL + "        whetherReject_";
  protected final String TEXT_118 = " = true;";
  protected final String TEXT_119 = NL + "            throw(e);";
  protected final String TEXT_120 = NL + "                    ";
  protected final String TEXT_121 = " = new ";
  protected final String TEXT_122 = "Struct();";
  protected final String TEXT_123 = NL + "                    ";
  protected final String TEXT_124 = ".";
  protected final String TEXT_125 = " = ";
  protected final String TEXT_126 = ".";
  protected final String TEXT_127 = ";";
  protected final String TEXT_128 = NL + "                ";
  protected final String TEXT_129 = ".errorMessage = e.getMessage();";
  protected final String TEXT_130 = NL + "                ";
  protected final String TEXT_131 = " = null;";
  protected final String TEXT_132 = NL + "                System.err.println(e.getMessage());";
  protected final String TEXT_133 = NL + "                ";
  protected final String TEXT_134 = " = null;";
  protected final String TEXT_135 = NL + "            \t";
  protected final String TEXT_136 = ".errorMessage = e.getMessage();";
  protected final String TEXT_137 = NL + "    }\t\t\t\t\t" + NL + "\t\t\t\t\t" + NL + "\t\t\t\t\t";
  protected final String TEXT_138 = NL + "\t\t";
  protected final String TEXT_139 = "if(!whetherReject_";
  protected final String TEXT_140 = ") { ";
  protected final String TEXT_141 = "      " + NL + "             if(";
  protected final String TEXT_142 = " == null){ " + NL + "            \t ";
  protected final String TEXT_143 = " = new ";
  protected final String TEXT_144 = "Struct();" + NL + "             }\t\t\t\t";
  protected final String TEXT_145 = NL + "\t    \t ";
  protected final String TEXT_146 = ".";
  protected final String TEXT_147 = " = ";
  protected final String TEXT_148 = ".";
  protected final String TEXT_149 = ";    \t\t\t\t";
  protected final String TEXT_150 = NL + "\t\t";
  protected final String TEXT_151 = " } ";
  protected final String TEXT_152 = "\t";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();
List<IMetadataTable> metadatas = node.getMetadataList();
if ((metadatas!=null)&&(metadatas.size()>0)) {
	IMetadataTable metadata = metadatas.get(0);
	if (metadata!=null) {
    	String header = ElementParameterParser.getValue(node, "__HEADER__");
    	String limit = ElementParameterParser.getValue(node, "__LIMIT__");
    	String footer = ElementParameterParser.getValue(node, "__FOOTER__");
    	String firstColumn = ElementParameterParser.getValue(node, "__FIRST_COLUMN__");
    	String lastColumn = ElementParameterParser.getValue(node, "__LAST_COLUMN__");
    	String dieOnErrorStr = ElementParameterParser.getValue(node, "__DIE_ON_ERROR__");
		boolean dieOnError = (dieOnErrorStr!=null&&!dieOnErrorStr.equals(""))?dieOnErrorStr.equals("true"):false;
		String encoding = ElementParameterParser.getValue(node,"__ENCODING__");
		
		String advancedSeparatorStr = ElementParameterParser.getValue(node, "__ADVANCED_SEPARATOR__");
		boolean advancedSeparator = (advancedSeparatorStr!=null&&!advancedSeparatorStr.equals(""))?advancedSeparatorStr.equals("true"):false;
		String thousandsSeparator = ElementParameterParser.getValue(node, "__THOUSANDS_SEPARATOR__");
		String decimalSeparator = ElementParameterParser.getValue(node, "__DECIMAL_SEPARATOR__");		    	

    stringBuffer.append(TEXT_2);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_3);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_4);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_5);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_6);
    stringBuffer.append(ElementParameterParser.getValue(node,"__FILENAME__"));
    stringBuffer.append(TEXT_7);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_8);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_9);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_10);
    stringBuffer.append( ElementParameterParser.getValue(node, "__SHEETNAME__"));
    stringBuffer.append(TEXT_11);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_12);
    stringBuffer.append( ElementParameterParser.getValue(node, "__SHEETNAME__"));
    stringBuffer.append(TEXT_13);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_14);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_15);
    if(header.trim().equals("")){
    stringBuffer.append(TEXT_16);
    }else{
    stringBuffer.append( header );
    }
    stringBuffer.append(TEXT_17);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_18);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_19);
    if(footer.trim().equals("")){
    stringBuffer.append(TEXT_20);
    }else{
    stringBuffer.append(footer);
    }
    stringBuffer.append(TEXT_21);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_22);
    if(limit.trim().equals("")){
    stringBuffer.append(TEXT_23);
    }else{
    stringBuffer.append(limit);
    }
    stringBuffer.append(TEXT_24);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_25);
    if(firstColumn.trim().equals("")){
    stringBuffer.append(TEXT_26);
    }else{
    stringBuffer.append(firstColumn);
    stringBuffer.append(TEXT_27);
    }
    stringBuffer.append(TEXT_28);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_29);
    if(lastColumn.trim().equals("")){
    stringBuffer.append(TEXT_30);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_31);
    }else{
    stringBuffer.append(lastColumn);
    }
    stringBuffer.append(TEXT_32);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_33);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_34);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_35);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_36);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_37);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_38);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_39);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_40);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_41);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_42);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_43);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_44);
    
//begin
//
	List< ? extends IConnection> conns = node.getOutgoingSortedConnections();

    String rejectConnName = "";
    List<? extends IConnection> rejectConns = node.getOutgoingConnections("REJECT");
    if(rejectConns != null && rejectConns.size() > 0) {
        IConnection rejectConn = rejectConns.get(0);
        rejectConnName = rejectConn.getName();
    }
    List<IMetadataColumn> rejectColumnList = null;
    IMetadataTable metadataTable = node.getMetadataFromConnector("REJECT");
    if(metadataTable != null) {
        rejectColumnList = metadataTable.getListColumns();      
    }

    	if (conns!=null) {
    		if (conns.size()>0) {
    			for (int i=0;i<conns.size();i++) {
    				IConnection connTemp = conns.get(i);
    				if (connTemp.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {

    stringBuffer.append(TEXT_45);
    stringBuffer.append(connTemp.getName() );
    stringBuffer.append(TEXT_46);
    
    				}
    			}
    		}
    	}
    	
		String firstConnName = "";
		if (conns!=null) {
			if (conns.size()>0) {
				IConnection conn = conns.get(0);
				firstConnName = conn.getName();
				List<IMetadataColumn> listColumns = metadata.getListColumns();
				int size = listColumns.size();
				if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
//
//end
    stringBuffer.append(TEXT_47);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_48);
    stringBuffer.append(listColumns.size());
    stringBuffer.append(TEXT_49);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_50);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_51);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_52);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_53);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_54);
    stringBuffer.append(size);
    stringBuffer.append(TEXT_55);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_56);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_57);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_58);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_59);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_60);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_62);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_63);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_64);
    
//start
//
					for (int i=0; i<size; i++) {
						IMetadataColumn column = listColumns.get(i);
						String typeToGenerate = JavaTypesManager.getTypeToGenerate(column.getTalendType(), column.isNullable());
						JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
						String patternValue = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
//
//end
    stringBuffer.append(TEXT_65);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_66);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_67);
    
//start
//

						if(javaType == JavaTypesManager.STRING || javaType == JavaTypesManager.OBJECT) {
//
//end
    stringBuffer.append(TEXT_68);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_69);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_70);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_71);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_72);
    		
//start
			} else if(javaType == JavaTypesManager.DATE) {
//
//end
    stringBuffer.append(TEXT_73);
    stringBuffer.append( i);
    stringBuffer.append(TEXT_74);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_75);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_76);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_77);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_78);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_79);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_80);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_81);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_82);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_83);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_84);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_85);
    
//start			
			}else if(advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable())) { 

    stringBuffer.append(TEXT_86);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_87);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_88);
    stringBuffer.append( typeToGenerate );
    stringBuffer.append(TEXT_89);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_90);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_91);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_92);
    stringBuffer.append( decimalSeparator );
    stringBuffer.append(TEXT_93);
    
					} else if(javaType == JavaTypesManager.BYTE_ARRAY) { 
	
    stringBuffer.append(TEXT_94);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_95);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_96);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_97);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_98);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_99);
    
			} else {
//
//end
    stringBuffer.append(TEXT_100);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_101);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_102);
    stringBuffer.append( typeToGenerate );
    stringBuffer.append(TEXT_103);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_104);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_105);
    
//start
//
						}
//
//end
    stringBuffer.append(TEXT_106);
    
//start
//
						String defaultValue = JavaTypesManager.getDefaultValueFromJavaType(typeToGenerate, column.getDefault());
						if(defaultValue == null) {
//
//end
    stringBuffer.append(TEXT_107);
    stringBuffer.append( column.getLabel() );
    stringBuffer.append(TEXT_108);
    
//start
//
						} else {
//
//end
    stringBuffer.append(TEXT_109);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_110);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_111);
    stringBuffer.append(defaultValue);
    stringBuffer.append(TEXT_112);
    
//start
//
						}
//
//end
    stringBuffer.append(TEXT_113);
    
//start
//
					}
    stringBuffer.append(TEXT_114);
    if(rejectConnName.equals(firstConnName)) {
    stringBuffer.append(TEXT_115);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_116);
    }
    stringBuffer.append(TEXT_117);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_118);
    
        if (dieOnError) {
            
    stringBuffer.append(TEXT_119);
    
        } else {
            if(!rejectConnName.equals("")&&!rejectConnName.equals(firstConnName)&&rejectColumnList != null && rejectColumnList.size() > 0) {

                
    stringBuffer.append(TEXT_120);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_121);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_122);
    
                for(IMetadataColumn column : metadata.getListColumns()) {
                    
    stringBuffer.append(TEXT_123);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_124);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_125);
    stringBuffer.append(firstConnName);
    stringBuffer.append(TEXT_126);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_127);
    
                }
                
    stringBuffer.append(TEXT_128);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_129);
    stringBuffer.append(TEXT_130);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_131);
    
            } else if(rejectConnName.equals("")){
                
    stringBuffer.append(TEXT_132);
    stringBuffer.append(TEXT_133);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_134);
    
            } else if(rejectConnName.equals(firstConnName)){
    stringBuffer.append(TEXT_135);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_136);
    }
        } 
        
    stringBuffer.append(TEXT_137);
    
				}
			}
		if (conns.size()>0) {	
			boolean isFirstEnter = true;
			for (int i=0;i<conns.size();i++) {
				IConnection conn = conns.get(i);
				if ((conn.getName().compareTo(firstConnName)!=0)&&(conn.getName().compareTo(rejectConnName)!=0)&&(conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA))) {

    stringBuffer.append(TEXT_138);
     if(isFirstEnter) {
    stringBuffer.append(TEXT_139);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_140);
     isFirstEnter = false; } 
    stringBuffer.append(TEXT_141);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_142);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_143);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_144);
    
			    	 for (IMetadataColumn column: metadata.getListColumns()) {

    stringBuffer.append(TEXT_145);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_146);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_147);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_148);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_149);
    
				 	}
				}
			}

    stringBuffer.append(TEXT_150);
     if(!isFirstEnter) {
    stringBuffer.append(TEXT_151);
     } 
    stringBuffer.append(TEXT_152);
    
		}
		}
	}
}
//
//end
    return stringBuffer.toString();
  }
}
