package org.talend.designer.codegen.translators.file.output;

import org.talend.core.model.process.INode;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.process.ElementParameterParser;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;

public class TAdvancedFileOutputXMLEndJava
{
  protected static String nl;
  public static synchronized TAdvancedFileOutputXMLEndJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TAdvancedFileOutputXMLEndJava result = new TAdvancedFileOutputXMLEndJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "\t\torg.dom4j.Element ";
  protected final String TEXT_3 = "_c_";
  protected final String TEXT_4 = " = ";
  protected final String TEXT_5 = "_";
  protected final String TEXT_6 = ".addElement(\"xsd:complexType\");" + NL + "\t\torg.dom4j.Element ";
  protected final String TEXT_7 = "_s_";
  protected final String TEXT_8 = " = ";
  protected final String TEXT_9 = "_c_";
  protected final String TEXT_10 = ".addElement(\"xsd:sequence\");";
  protected final String TEXT_11 = NL + "\t\torg.dom4j.Element ";
  protected final String TEXT_12 = "_";
  protected final String TEXT_13 = " = ";
  protected final String TEXT_14 = "_";
  protected final String TEXT_15 = ".addElement(\"xsd:element\");" + NL + "\t\t";
  protected final String TEXT_16 = "_";
  protected final String TEXT_17 = ".addAttribute(\"name\",\"";
  protected final String TEXT_18 = "\");" + NL + "\t\t";
  protected final String TEXT_19 = "_";
  protected final String TEXT_20 = ".addAttribute(\"nillable\",\"true\");";
  protected final String TEXT_21 = NL + "\t\t";
  protected final String TEXT_22 = "_";
  protected final String TEXT_23 = ".addAttribute(\"minOccurs\",\"0\");" + NL + "\t\t";
  protected final String TEXT_24 = "_";
  protected final String TEXT_25 = ".addAttribute(\"maxOccurs\",\"unbounded\");";
  protected final String TEXT_26 = NL + "\t\t";
  protected final String TEXT_27 = "_";
  protected final String TEXT_28 = ".addElement(\"xsd:attribute\").addAttribute(\"name\",\"";
  protected final String TEXT_29 = "\");";
  protected final String TEXT_30 = NL + "\t\tout_xsd_";
  protected final String TEXT_31 = ".write(\"";
  protected final String TEXT_32 = "  <xsd:complexType>\");" + NL + "\t\tout_xsd_";
  protected final String TEXT_33 = ".newLine();" + NL + "\t\tout_xsd_";
  protected final String TEXT_34 = ".write(\"";
  protected final String TEXT_35 = "    <xsd:sequence>\");" + NL + "\t\tout_xsd_";
  protected final String TEXT_36 = ".newLine();";
  protected final String TEXT_37 = NL + "\t\tout_xsd_";
  protected final String TEXT_38 = ".write(\"";
  protected final String TEXT_39 = "    </xsd:sequence>\");" + NL + "\t\tout_xsd_";
  protected final String TEXT_40 = ".newLine();";
  protected final String TEXT_41 = NL + "\t\tout_xsd_";
  protected final String TEXT_42 = ".write(\"";
  protected final String TEXT_43 = "  </xsd:complexType>\");" + NL + "\t\tout_xsd_";
  protected final String TEXT_44 = ".newLine();";
  protected final String TEXT_45 = NL + "\t\tout_xsd_";
  protected final String TEXT_46 = ".write(\"";
  protected final String TEXT_47 = "</xsd:element>\");" + NL + "\t\tout_xsd_";
  protected final String TEXT_48 = ".newLine();";
  protected final String TEXT_49 = NL + "\t\tout_xsd_";
  protected final String TEXT_50 = ".write(\"";
  protected final String TEXT_51 = "<xsd:element name=\\\"";
  protected final String TEXT_52 = "\\\" nillable=\\\"true\\\" \"+";
  protected final String TEXT_53 = NL + "\t\t\"minOccurs=\\\"0\\\" maxOccurs=\\\"unbounded\\\"\"+";
  protected final String TEXT_54 = NL + "\t\t\">\");" + NL + "\t\tout_xsd_";
  protected final String TEXT_55 = ".newLine();";
  protected final String TEXT_56 = NL + "\t\tout_xsd_";
  protected final String TEXT_57 = ".write(\"";
  protected final String TEXT_58 = "<xsd:attribute name= \\\"";
  protected final String TEXT_59 = "\\\"/>\");" + NL + "\t\tout_xsd_";
  protected final String TEXT_60 = ".newLine();";
  protected final String TEXT_61 = NL + "if(currentRowCount_";
  protected final String TEXT_62 = " > 0){";
  protected final String TEXT_63 = NL + "\tjava.io.FileOutputStream stream_";
  protected final String TEXT_64 = " = new java.io.FileOutputStream(file_";
  protected final String TEXT_65 = " + currentFileCount_";
  protected final String TEXT_66 = " + \".xml\");";
  protected final String TEXT_67 = NL + "\tjava.io.FileOutputStream stream_";
  protected final String TEXT_68 = " = new java.io.FileOutputStream(fileName_";
  protected final String TEXT_69 = ");";
  protected final String TEXT_70 = NL + "    org.dom4j.io.XMLWriter output_";
  protected final String TEXT_71 = " = new org.dom4j.io.XMLWriter(stream_";
  protected final String TEXT_72 = ", format_";
  protected final String TEXT_73 = ");";
  protected final String TEXT_74 = NL + "\tdoc_";
  protected final String TEXT_75 = ".getRootElement().addAttribute(\"xsi:noNamespaceSchemaLocation\", file_";
  protected final String TEXT_76 = ".substring(file_";
  protected final String TEXT_77 = ".lastIndexOf(\"/\")+1)+\".xsd\");" + NL + "    doc_";
  protected final String TEXT_78 = ".getRootElement().addNamespace(\"xsi\", \"http://www.w3.org/2001/XMLSchema-instance\");";
  protected final String TEXT_79 = "  " + NL + "    nestXMLTool_";
  protected final String TEXT_80 = ".replaceDefaultNameSpace(doc_";
  protected final String TEXT_81 = ".getRootElement());" + NL + "    output_";
  protected final String TEXT_82 = ".write(doc_";
  protected final String TEXT_83 = ");" + NL + "    output_";
  protected final String TEXT_84 = ".close();";
  protected final String TEXT_85 = NL + "\tout_";
  protected final String TEXT_86 = ".newLine();" + NL + "\tout_";
  protected final String TEXT_87 = ".write(\"";
  protected final String TEXT_88 = "</";
  protected final String TEXT_89 = ">\");";
  protected final String TEXT_90 = NL + "\tout_";
  protected final String TEXT_91 = ".close();";
  protected final String TEXT_92 = NL + "}";
  protected final String TEXT_93 = NL + "globalMap.put(\"";
  protected final String TEXT_94 = "_NB_LINE\",nb_line_";
  protected final String TEXT_95 = ");";
  protected final String TEXT_96 = NL + "\torg.dom4j.Document doc_xsd_";
  protected final String TEXT_97 = "  = org.dom4j.DocumentHelper.createDocument();" + NL + "\t" + NL + "\torg.dom4j.Element root_xsd_";
  protected final String TEXT_98 = " = doc_xsd_";
  protected final String TEXT_99 = ".addElement(\"xsd:schema\");" + NL + "    root_xsd_";
  protected final String TEXT_100 = ".addNamespace(\"xsd\", \"http://www.w3.org/2001/XMLSchema\");";
  protected final String TEXT_101 = NL + "\tjava.io.FileOutputStream stream_xsd_";
  protected final String TEXT_102 = " = new java.io.FileOutputStream(file_";
  protected final String TEXT_103 = "+\".xsd\");" + NL + "    org.dom4j.io.XMLWriter output_xsd_";
  protected final String TEXT_104 = " = new org.dom4j.io.XMLWriter(stream_xsd_";
  protected final String TEXT_105 = ", format_";
  protected final String TEXT_106 = ");" + NL + "    output_xsd_";
  protected final String TEXT_107 = ".write(doc_xsd_";
  protected final String TEXT_108 = " );" + NL + "    output_xsd_";
  protected final String TEXT_109 = ".close();";
  protected final String TEXT_110 = NL + "\tjava.io.BufferedWriter out_xsd_";
  protected final String TEXT_111 = " = new java.io.BufferedWriter(" + NL + "\t\tnew java.io.OutputStreamWriter(new java.io.FileOutputStream(file_";
  protected final String TEXT_112 = "+\".xsd\"), ";
  protected final String TEXT_113 = "));" + NL + "\tout_xsd_";
  protected final String TEXT_114 = ".write(\"<xsd:schema xmlns:xsd=\\\"http://www.w3.org/2001/XMLSchema\\\">\");" + NL + "\tout_xsd_";
  protected final String TEXT_115 = ".newLine();";
  protected final String TEXT_116 = NL + "\tout_xsd_";
  protected final String TEXT_117 = ".write(\"</xsd:schema>\");" + NL + "\tout_xsd_";
  protected final String TEXT_118 = ".close();";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
class XMLNode{
	public XMLNode(String path, String type, XMLNode parent, String column){
		this.path = path;
		this.parent = parent;
		this.type = type;
		this.column = column;
		if (type.equals("ELEMENT")) {
            this.name = path.substring(path.lastIndexOf("/") + 1);
        } else {
            this.name = path;
        }
	}
	public String name = null;
	public String path = null;
	public String type = null;
	public String column = null;
	public String value = null;
	public int special = 0;  //1 is subtree root, 2 is subtree root parent, 4 is main, 8 nest XML
	public XMLNode parent = null;
	public List<XMLNode> attributes = new LinkedList<XMLNode>();
	public List<XMLNode> namespaces = new LinkedList<XMLNode>();
	public List<XMLNode> elements = new LinkedList<XMLNode>();
}

//XMLTool
class XMLTool{
	
	public XMLNode removeEmptyElement(XMLNode root) {
        List<XMLNode> removeNodes = new LinkedList<XMLNode>();
        for (XMLNode attri : root.attributes) {
            if (attri.column == null || attri.column.length() == 0) {
                attri.parent = null;
                removeNodes.add(attri);
            }
        }
        root.attributes.removeAll(removeNodes);

        removeNodes.clear();
        for (XMLNode ns : root.namespaces) {
            if (ns.column == null || ns.column.length() == 0) {
                ns.parent = null;
                removeNodes.add(ns);
            }
        }
        root.namespaces.removeAll(removeNodes);

        removeNodes.clear();
        for (XMLNode child : root.elements) {
            removeNodes.add(removeEmptyElement(child));
        }
        root.elements.removeAll(removeNodes);

        if (root.attributes.size() == 0 && root.namespaces.size() == 0 && root.elements.size() == 0
                && (root.column == null || root.column.length() == 0)) {
            return root;
        } else {
            return null;
        }
    }
}
class XSDToolByDom4j{
    String cid = null;
    public void generateXSD(String parent, String currEleName, XMLNode root){
    	if(root.type.equals("ELEMENT")){
    		createElement(parent,currEleName,root);
			
			if(root.elements!=null && root.elements.size()>0
			  || root.attributes!=null && root.attributes.size()>0){

    stringBuffer.append(TEXT_2);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_10);
    
        		int index = 0;
        		for(XMLNode child:root.elements){
        			generateXSD(currEleName+"_s", currEleName+"_"+index++, child);
        		}
        		
        		for(XMLNode attri:root.attributes){
        			createAttribute(currEleName+"_c",attri);
        		}
			}
    	}
    }
    
    private void createElement(String parent, String currEleName, XMLNode node){

    stringBuffer.append(TEXT_11);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(parent);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_20);
    
		if(node.parent != null){

    stringBuffer.append(TEXT_21);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_23);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_25);
    
		}
    }
    
    private void createAttribute(String parent, XMLNode node){

    stringBuffer.append(TEXT_26);
    stringBuffer.append(parent);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_28);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_29);
    
    }
}

class XSDToolByNull{
	String cid = null;
    public void generateXSD(String emptyspace, XMLNode root){
    	if(root.type.equals("ELEMENT")){
    		createElement(emptyspace, root);
			
			if(root.elements!=null && root.elements.size()>0
			  || root.attributes!=null && root.attributes.size()>0){

    stringBuffer.append(TEXT_30);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_31);
    stringBuffer.append(emptyspace);
    stringBuffer.append(TEXT_32);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_33);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_34);
    stringBuffer.append(emptyspace);
    stringBuffer.append(TEXT_35);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_36);
    
				XMLNode mainNode = null;
        		for(XMLNode child:root.elements){
        			if( 1==(child.special & 4)){
        				mainNode = child;
        			}else{
        				generateXSD(emptyspace+"      ", child);
        			}
        		}
        		if(mainNode!= null){
        			generateXSD(emptyspace+"      ", mainNode);
        		}

    stringBuffer.append(TEXT_37);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_38);
    stringBuffer.append(emptyspace);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_40);
    
        		for(XMLNode attri:root.attributes){
        			createAttribute(emptyspace+"    ",attri);
        		}

    stringBuffer.append(TEXT_41);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_42);
    stringBuffer.append(emptyspace);
    stringBuffer.append(TEXT_43);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_44);
    
			}

    stringBuffer.append(TEXT_45);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_46);
    stringBuffer.append(emptyspace);
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_48);
    
    	}
    }
    
    private void createElement(String emptyspace, XMLNode node){

    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_50);
    stringBuffer.append(emptyspace);
    stringBuffer.append(TEXT_51);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_52);
    
		if(node.parent != null){

    stringBuffer.append(TEXT_53);
    
		}

    stringBuffer.append(TEXT_54);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_55);
    
    }
    
    private void createAttribute(String emptyspace, XMLNode node){

    stringBuffer.append(TEXT_56);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_57);
    stringBuffer.append(emptyspace);
    stringBuffer.append(TEXT_58);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_59);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_60);
    
    }
}

CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String allowEmpty = ElementParameterParser.getValue(node, "__CREATE_EMPTY_ELEMENT__");
String outputAsXSD = ElementParameterParser.getValue(node, "__OUTPUT_AS_XSD__");
List<Map<String, String>> rootTable = 
	(List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__ROOT__");
List<Map<String, String>> groupTable = 
	(List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__GROUP__");
List<Map<String, String>> loopTable = 
	(List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__LOOP__");

String encoding = ElementParameterParser.getValue(node, "__ENCODING__");
String mode = ElementParameterParser.getValue(node, "__GENERATION_MODE__");
String cid = node.getUniqueName();
List<IMetadataTable> metadatas = node.getMetadataList();
if ((metadatas!=null)&&(metadatas.size()>0)) {
	String split = ElementParameterParser.getValue(node, "__SPLIT__");
	if(split.equals("true")){

    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_62);
    
	}
	if(mode.equals("Dom4j")){
		if(split.equals("true")){

    stringBuffer.append(TEXT_63);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_64);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_65);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_66);
    
		}else{

    stringBuffer.append(TEXT_67);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_68);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_69);
    
		}

    stringBuffer.append(TEXT_70);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_71);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_72);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_73);
    
		if(outputAsXSD.equals("true")){

    stringBuffer.append(TEXT_74);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_75);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_76);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_78);
    
		}

    stringBuffer.append(TEXT_79);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_80);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_81);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_82);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_83);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_84);
    
	}else if(mode.equals("Null")){
		String path = loopTable.get(0).get("PATH");
		String[] endTabs = path.split("/");	
		for(int i=endTabs.length-2;i>0;i--){
			String tab = endTabs[i];
			String emptyspace = "";
			for(int len = 1; len<i;len++){
				emptyspace += "  ";
			}
			if(tab!=null && tab.length()>0){

    stringBuffer.append(TEXT_85);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_86);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_87);
    stringBuffer.append(emptyspace);
    stringBuffer.append(TEXT_88);
    stringBuffer.append(tab);
    stringBuffer.append(TEXT_89);
    
			}
		}

    stringBuffer.append(TEXT_90);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_91);
    
	}
	if(split.equals("true")){

    stringBuffer.append(TEXT_92);
    
	}

    stringBuffer.append(TEXT_93);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_94);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_95);
    
//-------Map to tree---------------------
	if(outputAsXSD.equals("true")){
    	XMLTool tool= new XMLTool();
    	List<List<Map<String, String>>> tables = new ArrayList<List<Map<String, String>>>();
        tables.add(rootTable);
        tables.add(groupTable);
        tables.add(loopTable);
    
        XMLNode root =null;
        XMLNode tmpParent = null;
        XMLNode tmpMainNode = null;
        if(loopTable==null || loopTable.size()==0){
        	return "";
        }
        String mainPath = loopTable.get(0).get("PATH");
        for (List<Map<String, String>> tmpTable : tables) {
            tmpParent = tmpMainNode;
            for (Map<String, String> tmpMap : tmpTable) {
                XMLNode tmpNew = null;
                if (tmpMap.get("ATTRIBUTE").equals("attri")) {
                    tmpNew = new XMLNode(tmpMap.get("PATH"), "ATTRIBUTE", tmpParent, tmpMap.get("COLUMN"));
                    tmpParent.attributes.add(tmpNew);
                } else {
                    if (tmpParent == null) {
                        tmpNew = new XMLNode(tmpMap.get("PATH"), "ELEMENT", tmpParent, tmpMap.get("COLUMN"));
                        root = tmpNew;
                    } else {
                        String tmpParentPath = tmpMap.get("PATH").substring(0, tmpMap.get("PATH").lastIndexOf("/"));
               		 	while (tmpParent != null && !tmpParentPath.equals(tmpParent.path)) {
                            tmpParent = tmpParent.parent;
                        }
                        tmpNew = new XMLNode(tmpMap.get("PATH"), "ELEMENT", tmpParent, tmpMap.get("COLUMN"));
                        tmpParent.elements.add(tmpNew);
                    }
                    if (tmpMap.get("ATTRIBUTE").equals("main")) {
                        tmpMainNode = tmpNew;
                        tmpNew.special |= 4;
                    }
                    tmpParent = tmpNew;
                }
            }
        }
        
        if(!allowEmpty.equals("true")){
        	tool.removeEmptyElement(root);
        }

//-------generate XSD file---------------------
		if(mode.equals("Dom4j")){

    stringBuffer.append(TEXT_96);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_97);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_98);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_99);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_100);
    
	XSDToolByDom4j xsdTool = new XSDToolByDom4j();
	xsdTool.cid = cid;
	xsdTool.generateXSD("root_xsd","ele_xsd",root);

    stringBuffer.append(TEXT_101);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_102);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_103);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_104);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_105);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_106);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_107);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_108);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_109);
    
		}else if(mode.equals("Null")){

    stringBuffer.append(TEXT_110);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_111);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_112);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_113);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_114);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_115);
    
	XSDToolByNull xsdTool = new XSDToolByNull();
	xsdTool.cid=cid;
	xsdTool.generateXSD("  ",root);

    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_117);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_118);
    
		}
    }
}

    return stringBuffer.toString();
  }
}
