package org.talend.designer.codegen.translators.charts;

import org.talend.core.model.process.INode;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.process.ElementParameterParser;
import java.util.List;

public class TLineChartEndJava
{
  protected static String nl;
  public static synchronized TLineChartEndJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TLineChartEndJava result = new TLineChartEndJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "        for (org.jfree.data.xy.XYSeries serie: series.values()){" + NL + "          dataset.addSeries(serie);" + NL + "        }" + NL + "" + NL + "        // create the chart..." + NL + "        org.jfree.chart.JFreeChart chart = org.jfree.chart.ChartFactory.createXYLineChart(";
  protected final String TEXT_2 = ",";
  protected final String TEXT_3 = NL + "                ";
  protected final String TEXT_4 = ",";
  protected final String TEXT_5 = NL + "                ";
  protected final String TEXT_6 = "," + NL + "                dataset,";
  protected final String TEXT_7 = NL + "                ";
  protected final String TEXT_8 = ",";
  protected final String TEXT_9 = NL + "                ";
  protected final String TEXT_10 = "," + NL + "                true," + NL + "                false" + NL + "                );" + NL + "" + NL + "        final org.jfree.chart.plot.XYPlot plot = (org.jfree.chart.plot.XYPlot) chart.getPlot();" + NL;
  protected final String TEXT_11 = NL + "        plot.setBackgroundPaint(";
  protected final String TEXT_12 = ");";
  protected final String TEXT_13 = NL + "        chart.setBackgroundPaint(";
  protected final String TEXT_14 = ");";
  protected final String TEXT_15 = NL;
  protected final String TEXT_16 = NL + "            plot.getRangeAxis().setLowerBound(";
  protected final String TEXT_17 = ");";
  protected final String TEXT_18 = NL + "            plot.getRangeAxis().setUpperBound(";
  protected final String TEXT_19 = ");";
  protected final String TEXT_20 = NL;
  protected final String TEXT_21 = NL + "        org.jfree.data.xy.XYDataset movingAverage = org.jfree.data.time.MovingAverage.createMovingAverage(dataset, \" (average)\", ";
  protected final String TEXT_22 = ", 10);" + NL + "        plot.setDataset(1, movingAverage);" + NL + "        plot.setRenderer(1, new org.jfree.chart.renderer.xy.StandardXYItemRenderer());";
  protected final String TEXT_23 = NL + NL + "        try {" + NL + "            org.jfree.chart.ChartUtilities.saveChartAsPNG(new java.io.File(";
  protected final String TEXT_24 = "), chart, ";
  protected final String TEXT_25 = ", ";
  protected final String TEXT_26 = ");" + NL + "        } catch (java.io.IOException e) {" + NL + "            // TODO Auto-generated catch block" + NL + "            e.printStackTrace();" + NL + "        }";
  protected final String TEXT_27 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String filePath = ElementParameterParser.getValue(node,"__GENERATED_IMAGE_PATH__");

    stringBuffer.append(TEXT_1);
    stringBuffer.append(ElementParameterParser.getValue(node,"__CHART_TITLE__"));
    stringBuffer.append(TEXT_2);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(ElementParameterParser.getValue(node,"__DOMAIN_AXIS_LABEL__"));
    stringBuffer.append(TEXT_4);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(ElementParameterParser.getValue(node,"__RANGE_AXIS_LABEL__"));
    stringBuffer.append(TEXT_6);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(ElementParameterParser.getValue(node,"__PLOT_ORIENTATION__"));
    stringBuffer.append(TEXT_8);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(ElementParameterParser.getValue(node,"__INCLUDE_LEGEND__"));
    stringBuffer.append(TEXT_10);
    if (!ElementParameterParser.getValue(node,"__BACKGROUND_PLOT__").equals("")){
    stringBuffer.append(TEXT_11);
    stringBuffer.append(ElementParameterParser.getValue(node,"__BACKGROUND_PLOT__"));
    stringBuffer.append(TEXT_12);
    }
    if (!ElementParameterParser.getValue(node,"__BACKGROUND_CHART__").equals("")){
    stringBuffer.append(TEXT_13);
    stringBuffer.append(ElementParameterParser.getValue(node,"__BACKGROUND_CHART__"));
    stringBuffer.append(TEXT_14);
    }
    stringBuffer.append(TEXT_15);
    if (!ElementParameterParser.getValue(node,"__LOWER_BOUND__").equals("")){
    stringBuffer.append(TEXT_16);
    stringBuffer.append(ElementParameterParser.getValue(node,"__LOWER_BOUND__"));
    stringBuffer.append(TEXT_17);
    }
    if (!ElementParameterParser.getValue(node,"__UPPER_BOUND__").equals("")) {
    stringBuffer.append(TEXT_18);
    stringBuffer.append(ElementParameterParser.getValue(node,"__UPPER_BOUND__"));
    stringBuffer.append(TEXT_19);
    }
    stringBuffer.append(TEXT_20);
    if (ElementParameterParser.getValue(node,"__MOVING_AVERAGE__").equals("true")){
    stringBuffer.append(TEXT_21);
    stringBuffer.append(ElementParameterParser.getValue(node,"__MOVING_AVERAGE_PERIOD__"));
    stringBuffer.append(TEXT_22);
    }
    stringBuffer.append(TEXT_23);
    stringBuffer.append(filePath);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(ElementParameterParser.getValue(node,"__IMAGE_WIDTH__"));
    stringBuffer.append(TEXT_25);
    stringBuffer.append(ElementParameterParser.getValue(node,"__IMAGE_HEIGHT__"));
    stringBuffer.append(TEXT_26);
    stringBuffer.append(TEXT_27);
    return stringBuffer.toString();
  }
}
