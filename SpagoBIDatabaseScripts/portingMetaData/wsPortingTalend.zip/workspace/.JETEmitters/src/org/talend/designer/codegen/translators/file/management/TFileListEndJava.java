package org.talend.designer.codegen.translators.file.management;

import org.talend.core.model.process.INode;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.process.ElementParameterParser;
import java.util.List;

public class TFileListEndJava
{
  protected static String nl;
  public static synchronized TFileListEndJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileListEndJava result = new TFileListEndJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "}" + NL + "" + NL + "globalMap.put(\"";
  protected final String TEXT_3 = "_NB_FILE\", NB_FILE";
  protected final String TEXT_4 = ");";
  protected final String TEXT_5 = NL + "if(NB_FILE";
  protected final String TEXT_6 = " == 0) throw new RuntimeException(\"No file found in directory \"+directory_";
  protected final String TEXT_7 = ");";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();
boolean generateError = ElementParameterParser.getValue(node, "__ERROR__").equals("true");

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_4);
    if(generateError){
    stringBuffer.append(TEXT_5);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_7);
    }
    return stringBuffer.toString();
  }
}
