package org.talend.designer.codegen.translators.databases.mssqlserver;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;
import java.util.Map;

public class TMSSqlSPBeginJava
{
  protected static String nl;
  public static synchronized TMSSqlSPBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TMSSqlSPBeginJava result = new TMSSqlSPBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "java.lang.Class.forName(\"net.sourceforge.jtds.jdbc.Driver\");" + NL + "String connectionString_";
  protected final String TEXT_3 = " = \"jdbc:jtds:sqlserver://\" + ";
  protected final String TEXT_4 = " + \":\" + ";
  protected final String TEXT_5 = " + \"//\" + ";
  protected final String TEXT_6 = " + \";appName=\" + projectName + \";\" + ";
  protected final String TEXT_7 = ";        " + NL + "java.sql.Connection connection_";
  protected final String TEXT_8 = " = java.sql.DriverManager.getConnection(connectionString_";
  protected final String TEXT_9 = ", ";
  protected final String TEXT_10 = ", ";
  protected final String TEXT_11 = ");" + NL;
  protected final String TEXT_12 = NL + "java.sql.CallableStatement statement_";
  protected final String TEXT_13 = " = connection_";
  protected final String TEXT_14 = ".prepareCall(\"{";
  protected final String TEXT_15 = "call ";
  protected final String TEXT_16 = "(";
  protected final String TEXT_17 = ")}\"";
  protected final String TEXT_18 = NL + "\t,java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, java.sql.ResultSet.CONCUR_READ_ONLY";
  protected final String TEXT_19 = NL + ");" + NL + "" + NL + "java.sql.Date tmpDate_";
  protected final String TEXT_20 = ";" + NL + "String tmpString_";
  protected final String TEXT_21 = ";";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode) codeGenArgument.getArgument();
String cid = node.getUniqueName();
String dbhost = ElementParameterParser.getValue(node, "__HOST__");
String dbport = ElementParameterParser.getValue(node, "__PORT__");
String dbname = ElementParameterParser.getValue(node, "__DBNAME__");
String dbproperties = ElementParameterParser.getValue(node, "__PROPERTIES__");
String dbuser = ElementParameterParser.getValue(node, "__USER__");
String dbpwd  = ElementParameterParser.getValue(node, "__PASS__");
String spName = ElementParameterParser.getValue(node, "__SP_NAME__");
boolean isFunction = ElementParameterParser.getValue(node, "__IS_FUNCTION__").equals("true");
List<Map<String, String>> spArgs = (List<Map<String,String>>) ElementParameterParser.getObjectValue(node, "__SP_ARGS__");

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_3);
    stringBuffer.append(dbhost);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(dbport);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(dbname);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(dbproperties);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(dbuser);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(dbpwd);
    stringBuffer.append(TEXT_11);
    
boolean hasOutput = false;
StringBuilder parameters =new StringBuilder();
for (int i = 0; i < spArgs.size(); i++) {
	if(spArgs.get(i).get("TYPE").equals("RECORDSET") 
		|| spArgs.get(i).get("TYPE").equals("INOUT")
		|| spArgs.get(i).get("TYPE").equals("OUT")){
		hasOutput=true;
	}
    if(!spArgs.get(i).get("TYPE").equals("RECORDSET")){
        if (parameters.length()==0) {
           	parameters.append("?");
        } else {
            parameters.append(",?");
        }
    }
}

    stringBuffer.append(TEXT_12);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(isFunction ? "? = " : "");
    stringBuffer.append(TEXT_15);
    stringBuffer.append(spName);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(parameters.toString());
    stringBuffer.append(TEXT_17);
    
if(hasOutput){

    stringBuffer.append(TEXT_18);
    
}

    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_21);
    return stringBuffer.toString();
  }
}
