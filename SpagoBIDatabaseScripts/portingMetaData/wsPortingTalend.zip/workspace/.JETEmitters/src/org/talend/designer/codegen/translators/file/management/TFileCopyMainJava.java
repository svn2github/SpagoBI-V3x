package org.talend.designer.codegen.translators.file.management;

import org.talend.core.model.process.INode;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.process.ElementParameterParser;

public class TFileCopyMainJava
{
  protected static String nl;
  public static synchronized TFileCopyMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFileCopyMainJava result = new TFileCopyMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "\t";
  protected final String TEXT_2 = "     " + NL + "        String srcFileName_";
  protected final String TEXT_3 = " = ";
  protected final String TEXT_4 = ";" + NL + "        java.io.File srcFile_";
  protected final String TEXT_5 = " = new java.io.File(srcFileName_";
  protected final String TEXT_6 = ");" + NL + "        // here need check first, before mkdirs()." + NL + "        if (!srcFile_";
  protected final String TEXT_7 = ".exists() || !srcFile_";
  protected final String TEXT_8 = ".isFile()) {" + NL + "            throw new RuntimeException(\"The source File \\\"\" + srcFileName_";
  protected final String TEXT_9 = " + \"\\\" does not exist or is not a file.\");" + NL + "        }" + NL + "" + NL + "        String desDirName_";
  protected final String TEXT_10 = " = ";
  protected final String TEXT_11 = ";" + NL + "        String desFileName_";
  protected final String TEXT_12 = " = ";
  protected final String TEXT_13 = " ";
  protected final String TEXT_14 = " ";
  protected final String TEXT_15 = " srcFile_";
  protected final String TEXT_16 = ".getName() ";
  protected final String TEXT_17 = ";" + NL + "        if(desFileName_";
  protected final String TEXT_18 = " != null && desFileName_";
  protected final String TEXT_19 = ".trim().equals(\"\")){" + NL + "\t\t\tdesFileName_";
  protected final String TEXT_20 = " = \"NewName.temp\";" + NL + "\t\t}    " + NL + "        " + NL + "        java.io.File desFile_";
  protected final String TEXT_21 = " = new java.io.File(desDirName_";
  protected final String TEXT_22 = ", desFileName_";
  protected final String TEXT_23 = ");" + NL + "" + NL + "        if (!srcFile_";
  protected final String TEXT_24 = ".getPath().equals(desFile_";
  protected final String TEXT_25 = ".getPath()) ";
  protected final String TEXT_26 = "&& !desFile_";
  protected final String TEXT_27 = ".exists() ";
  protected final String TEXT_28 = " ) {" + NL;
  protected final String TEXT_29 = NL + "            java.io.File parentFile_";
  protected final String TEXT_30 = " = desFile_";
  protected final String TEXT_31 = ".getParentFile();" + NL + "            if (parentFile_";
  protected final String TEXT_32 = " != null && !parentFile_";
  protected final String TEXT_33 = ".exists()) {" + NL + "                parentFile_";
  protected final String TEXT_34 = ".mkdirs();" + NL + "            }";
  protected final String TEXT_35 = "           " + NL + "" + NL + "            org.talend.FileCopy.copyFile(srcFile_";
  protected final String TEXT_36 = ".getPath(), desFile_";
  protected final String TEXT_37 = ".getPath(), ";
  protected final String TEXT_38 = ");" + NL + "" + NL + "        }";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
	CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
	INode node = (INode)codeGenArgument.getArgument();
	String cid = node.getUniqueName();
	String fileName = ElementParameterParser.getValue(node, "__FILENAME__");	
	String destination  = ElementParameterParser.getValue(node, "__DESTINATION__");
	
	boolean rename = ElementParameterParser.getValue(node, "__RENAME__").equals("true");	
	String destination_filename  = ElementParameterParser.getValue(node, "__DESTINATION_RENAME__");
	
	boolean reFile = ElementParameterParser.getValue(node, "__REMOVE_FILE__").equals("true");
	boolean rpFile = ElementParameterParser.getValue(node,"__REPLACE_FILE__").equals("true");
    boolean creatDir = ElementParameterParser.getValue(node,"__CREATE_DIRECTORY__").equals("true");

    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_3);
    stringBuffer.append(fileName );
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_5);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_10);
    stringBuffer.append(destination );
    stringBuffer.append(TEXT_11);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_12);
    if(rename){
    stringBuffer.append(TEXT_13);
    stringBuffer.append(destination_filename );
    stringBuffer.append(TEXT_14);
    }else{
    stringBuffer.append(TEXT_15);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_16);
    }
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_21);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_23);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_25);
    if(!rpFile) {
    stringBuffer.append(TEXT_26);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_27);
    }
    stringBuffer.append(TEXT_28);
    if(creatDir){
    stringBuffer.append(TEXT_29);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_30);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_31);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_32);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_33);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_34);
    }
    stringBuffer.append(TEXT_35);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_36);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_37);
    stringBuffer.append(reFile );
    stringBuffer.append(TEXT_38);
    return stringBuffer.toString();
  }
}
