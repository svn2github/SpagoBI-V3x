package org.talend.designer.codegen.translators.internet;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.IConnectionCategory;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;
import java.util.List;
import java.util.Map;

public class TSocketInputBeginJava
{
  protected static String nl;
  public static synchronized TSocketInputBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TSocketInputBeginJava result = new TSocketInputBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "      ";
  protected final String TEXT_3 = NL + "class Compress{" + NL + "    public byte[] unzip(byte[] zipBytes) throws java.io.IOException {" + NL + "        java.io.ByteArrayInputStream bais = new java.io.ByteArrayInputStream(zipBytes);" + NL + "        java.util.zip.ZipInputStream zis = new java.util.zip.ZipInputStream(bais);" + NL + "        zis.getNextEntry();" + NL + "        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();" + NL + "        final int BUFSIZ = 8192;" + NL + "        byte inbuf[] = new byte[BUFSIZ];" + NL + "        int n;" + NL + "        while ((n = zis.read(inbuf, 0, BUFSIZ)) != -1) {" + NL + "            baos.write(inbuf, 0, n);" + NL + "        }" + NL + "        byte[] data = baos.toByteArray();" + NL + "        zis.close();" + NL + "        return data;" + NL + "    } " + NL + "}" + NL + "Compress com";
  protected final String TEXT_4 = " = new Compress();";
  protected final String TEXT_5 = NL + NL + "int nb_line_";
  protected final String TEXT_6 = "=0;" + NL + "" + NL + "java.net.ServerSocket ss";
  protected final String TEXT_7 = ";" + NL + "java.net.Socket socket";
  protected final String TEXT_8 = ";" + NL + "java.io.BufferedReader in";
  protected final String TEXT_9 = ";" + NL + "java.io.PrintWriter out";
  protected final String TEXT_10 = ";" + NL + "" + NL + "ss";
  protected final String TEXT_11 = " = new java.net.ServerSocket(";
  protected final String TEXT_12 = ");";
  protected final String TEXT_13 = NL + "    ss";
  protected final String TEXT_14 = ".setSoTimeout(";
  protected final String TEXT_15 = ");";
  protected final String TEXT_16 = NL + "boolean done";
  protected final String TEXT_17 = " = true;" + NL + "while (done";
  protected final String TEXT_18 = ") {" + NL + "   socket";
  protected final String TEXT_19 = " = ss";
  protected final String TEXT_20 = ".accept();" + NL + "   if(socket";
  protected final String TEXT_21 = ".getInetAddress().getHostAddress().equals(";
  protected final String TEXT_22 = ")){" + NL + "      System.out.println(\"socket connected\");" + NL + "      //READ DATA" + NL + "      com.csvreader.CsvReader csvReader";
  protected final String TEXT_23 = " =" + NL + "          new com.csvreader.CsvReader(new java.io.BufferedReader(new java.io.InputStreamReader(socket";
  protected final String TEXT_24 = ".getInputStream(),";
  protected final String TEXT_25 = ")), '";
  protected final String TEXT_26 = "');" + NL + "                ";
  protected final String TEXT_27 = NL + "      csvReader";
  protected final String TEXT_28 = ".setRecordDelimiter('";
  protected final String TEXT_29 = "');";
  protected final String TEXT_30 = NL + "      csvReader";
  protected final String TEXT_31 = ".setSkipEmptyRecords(true);" + NL + "      csvReader";
  protected final String TEXT_32 = ".setTextQualifier('";
  protected final String TEXT_33 = "');                ";
  protected final String TEXT_34 = NL + "      csvReader";
  protected final String TEXT_35 = ".setEscapeMode(com.csvreader.CsvReader.ESCAPE_MODE_BACKSLASH);";
  protected final String TEXT_36 = NL + "      csvReader";
  protected final String TEXT_37 = ".setEscapeMode(com.csvreader.CsvReader.ESCAPE_MODE_DOUBLED);";
  protected final String TEXT_38 = NL + "                //?????doesn't work for other escapeChar";
  protected final String TEXT_39 = " " + NL + "    " + NL + "    " + NL + "    String[] row";
  protected final String TEXT_40 = "=null;   " + NL + "    while (csvReader";
  protected final String TEXT_41 = ".readRecord()) {         " + NL + "        row";
  protected final String TEXT_42 = "=csvReader";
  protected final String TEXT_43 = ".getValues();";
  protected final String TEXT_44 = NL + "        //decoding" + NL + "        for(int i =0;i<row";
  protected final String TEXT_45 = ".length;i++){" + NL + "           row";
  protected final String TEXT_46 = "[i] = new String(com";
  protected final String TEXT_47 = ".unzip(new sun.misc.BASE64Decoder().decodeBuffer(row";
  protected final String TEXT_48 = "[i])), ";
  protected final String TEXT_49 = ");           " + NL + "        }";
  protected final String TEXT_50 = "   " + NL + "        if(row";
  protected final String TEXT_51 = ".length == 1 && row";
  protected final String TEXT_52 = "[0].equals(\"\\015\")){//empty line when row separator is '\\n'" + NL + "            continue;" + NL + "        }" + NL + "                                                                 ";
  protected final String TEXT_53 = NL + "        ";
  protected final String TEXT_54 = " = null;            ";
  protected final String TEXT_55 = NL + "        boolean whetherReject_";
  protected final String TEXT_56 = " = false;";
  protected final String TEXT_57 = NL + "        ";
  protected final String TEXT_58 = " = new ";
  protected final String TEXT_59 = "Struct();" + NL + "        try {           ";
  protected final String TEXT_60 = "                          " + NL + "        if(row";
  protected final String TEXT_61 = ".length == 1 && row";
  protected final String TEXT_62 = "[0].equals(\"\\015\")){//empty line when row separator is '\\n'           ";
  protected final String TEXT_63 = NL + "            ";
  protected final String TEXT_64 = ".";
  protected final String TEXT_65 = " = ";
  protected final String TEXT_66 = ";           ";
  protected final String TEXT_67 = "           " + NL + "        }else{      ";
  protected final String TEXT_68 = "                         " + NL + "            if(";
  protected final String TEXT_69 = " < row";
  protected final String TEXT_70 = ".length){              ";
  protected final String TEXT_71 = NL + "                ";
  protected final String TEXT_72 = ".";
  protected final String TEXT_73 = " = row";
  protected final String TEXT_74 = "[";
  protected final String TEXT_75 = "];";
  protected final String TEXT_76 = NL + "                    if(row";
  protected final String TEXT_77 = "[";
  protected final String TEXT_78 = "].length() > 0) {";
  protected final String TEXT_79 = NL + "                            ";
  protected final String TEXT_80 = ".";
  protected final String TEXT_81 = " = ParserUtils.parseTo_Date(row";
  protected final String TEXT_82 = "[";
  protected final String TEXT_83 = "], ";
  protected final String TEXT_84 = ");";
  protected final String TEXT_85 = "                          ";
  protected final String TEXT_86 = NL + "                            ";
  protected final String TEXT_87 = ".";
  protected final String TEXT_88 = " = row";
  protected final String TEXT_89 = "[";
  protected final String TEXT_90 = "].getBytes(";
  protected final String TEXT_91 = ");";
  protected final String TEXT_92 = NL + "                            ";
  protected final String TEXT_93 = ".";
  protected final String TEXT_94 = " = ParserUtils.parseTo_";
  protected final String TEXT_95 = "(row";
  protected final String TEXT_96 = "[";
  protected final String TEXT_97 = "]);";
  protected final String TEXT_98 = "                  " + NL + "                    }else{";
  protected final String TEXT_99 = NL + "                        ";
  protected final String TEXT_100 = ".";
  protected final String TEXT_101 = " = ";
  protected final String TEXT_102 = ";" + NL + "                    }";
  protected final String TEXT_103 = "                             " + NL + "            }else{                                      ";
  protected final String TEXT_104 = NL + "            ";
  protected final String TEXT_105 = ".";
  protected final String TEXT_106 = " = ";
  protected final String TEXT_107 = ";" + NL + "            }";
  protected final String TEXT_108 = NL + "        }" + NL + "        nb_line_";
  protected final String TEXT_109 = "++;" + NL + "} catch (Exception e) {" + NL + "    whetherReject_";
  protected final String TEXT_110 = " = true;";
  protected final String TEXT_111 = NL + "        throw(e);";
  protected final String TEXT_112 = NL + "                ";
  protected final String TEXT_113 = " = new ";
  protected final String TEXT_114 = "Struct();";
  protected final String TEXT_115 = NL + "                ";
  protected final String TEXT_116 = ".";
  protected final String TEXT_117 = " = ";
  protected final String TEXT_118 = ".";
  protected final String TEXT_119 = ";";
  protected final String TEXT_120 = NL + "            ";
  protected final String TEXT_121 = ".errorMessage = e.getMessage();";
  protected final String TEXT_122 = NL + "            ";
  protected final String TEXT_123 = " = null;";
  protected final String TEXT_124 = NL + "            System.err.print(e.getMessage());";
  protected final String TEXT_125 = NL + "            ";
  protected final String TEXT_126 = " = null;";
  protected final String TEXT_127 = NL + "}";
  protected final String TEXT_128 = "if(!whetherReject_";
  protected final String TEXT_129 = ") { ";
  protected final String TEXT_130 = "      " + NL + "         if(";
  protected final String TEXT_131 = " == null){ ";
  protected final String TEXT_132 = NL + "             ";
  protected final String TEXT_133 = " = new ";
  protected final String TEXT_134 = "Struct();" + NL + "         }              ";
  protected final String TEXT_135 = NL + "         ";
  protected final String TEXT_136 = ".";
  protected final String TEXT_137 = " = ";
  protected final String TEXT_138 = ".";
  protected final String TEXT_139 = ";                    ";
  protected final String TEXT_140 = " } ";
  protected final String TEXT_141 = "  ";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     
    CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
    INode node = (INode)codeGenArgument.getArgument();
    String cid = node.getUniqueName();      

    stringBuffer.append(TEXT_1);
    
List<IMetadataTable> metadatas = node.getMetadataList();
if ((metadatas!=null)&&(metadatas.size()>0)) {
    IMetadataTable metadata = metadatas.get(0);
    if (metadata!=null) {
        String encoding = ElementParameterParser.getValue(node,"__ENCODING__");
        String hostname = ElementParameterParser.getValue(node,"__HOSTNAME__");
        String port = ElementParameterParser.getValue(node,"__PORT__");
        boolean uncompress = ElementParameterParser.getValue(node,"__UNCOMPRESS__").equals("true");
        boolean dieOnError = ElementParameterParser.getValue(node,"__DIE_ON_ERROR__").equals("true");
        
        String delim1 = ElementParameterParser.getValue(node, "__FIELDSEPARATOR__");
        String fieldSeparator = delim1.substring(1,delim1.length()-1);
        if(fieldSeparator.equals("'")) fieldSeparator = "\\'";
        
        String rowSeparator1 = ElementParameterParser.getValue(node, "__ROWSEPARATOR__");
        String rowSeparator = rowSeparator1.substring(1,rowSeparator1.length()-1);
        if(rowSeparator.equals("'")) rowSeparator = "\\'";
        
        String escapeChar1 = ElementParameterParser.getValue(node, "__ESCAPE_CHAR__");
        String escapeChar = escapeChar1.substring(1,escapeChar1.length()-1);
        if(escapeChar.equals("'")) escapeChar = "\\'";
        
        String textEnclosure1 = ElementParameterParser.getValue(node, "__TEXT_ENCLOSURE__");
        String textEnclosure = textEnclosure1.substring(1,textEnclosure1.length()-1);
        if ("".equals(textEnclosure)) textEnclosure = "\0";
        if(textEnclosure.equals("'")) textEnclosure = "\\'";
        
        String timeout = ElementParameterParser.getValue(node, "__TIMEOUT__");

    stringBuffer.append(TEXT_2);
     if(uncompress){
    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_4);
    }
    stringBuffer.append(TEXT_5);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(port);
    stringBuffer.append(TEXT_12);
    if(!timeout.equals("")){
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(timeout);
    stringBuffer.append(TEXT_15);
    }
    stringBuffer.append(TEXT_16);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_21);
    stringBuffer.append(hostname);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_23);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_25);
    stringBuffer.append(fieldSeparator);
    stringBuffer.append(TEXT_26);
                  if(!rowSeparator.equals("\\n") && !rowSeparator.equals("\\r")){
    stringBuffer.append(TEXT_27);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_28);
    stringBuffer.append(rowSeparator  );
    stringBuffer.append(TEXT_29);
                  }
    stringBuffer.append(TEXT_30);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_31);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_32);
    stringBuffer.append(textEnclosure );
    stringBuffer.append(TEXT_33);
          if(escapeChar.equals("\\\\")){
    stringBuffer.append(TEXT_34);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_35);
          }else if(escapeChar.equals(textEnclosure)){
    stringBuffer.append(TEXT_36);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_37);
          }else{
    stringBuffer.append(TEXT_38);
          }
    stringBuffer.append(TEXT_39);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_41);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_43);
     if(uncompress){
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_45);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_46);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_48);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_49);
     } 
    stringBuffer.append(TEXT_50);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_51);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_52);
    
List< ? extends IConnection> conns = node.getOutgoingSortedConnections();
String rejectConnName = "";
List<? extends IConnection> rejectConns = node.getOutgoingConnections("REJECT");
if(rejectConns != null && rejectConns.size() > 0) {
    IConnection rejectConn = rejectConns.get(0);
    rejectConnName = rejectConn.getName();
}
List<IMetadataColumn> rejectColumnList = null;
IMetadataTable metadataTable = node.getMetadataFromConnector("REJECT");
if(metadataTable != null) {
    rejectColumnList = metadataTable.getListColumns();      
}
    if (conns!=null) {
        if (conns.size()>0) {
            for (int i=0;i<conns.size();i++) {
                IConnection connTemp = conns.get(i);
                if (connTemp.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {

    stringBuffer.append(TEXT_53);
    stringBuffer.append(connTemp.getName() );
    stringBuffer.append(TEXT_54);
    
                }
            }
        }
    }
    
String firstConnName = "";
if (conns!=null) {
    if (conns.size()>0) {
        IConnection conn = conns.get(0);
        firstConnName = conn.getName();       
        if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
        
    stringBuffer.append(TEXT_55);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_56);
    stringBuffer.append(TEXT_57);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_58);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_59);
    
            List<IMetadataColumn> columns=metadata.getListColumns();
            int columnSize = columns.size();
            
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_62);
    
    for (IMetadataColumn column1: metadata.getListColumns()) {
    stringBuffer.append(TEXT_63);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_64);
    stringBuffer.append(column1.getLabel() );
    stringBuffer.append(TEXT_65);
    stringBuffer.append(JavaTypesManager.getDefaultValueFromJavaIdType(column1.getTalendType(), column1.isNullable()));
    stringBuffer.append(TEXT_66);
          }
    stringBuffer.append(TEXT_67);
    
        for (int i=0;i<columnSize;i++) {
                IMetadataColumn column=columns.get(i);
                String typeToGenerate = JavaTypesManager.getTypeToGenerate(column.getTalendType(), column.isNullable());
                JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
                String patternValue = column.getPattern() == null || column.getPattern().trim().length() == 0 ? null : column.getPattern();
        
    stringBuffer.append(TEXT_68);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_69);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_70);
    
                if(javaType == JavaTypesManager.STRING || javaType == JavaTypesManager.OBJECT) {

    stringBuffer.append(TEXT_71);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_72);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_73);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_74);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_75);
    
                } else {

    stringBuffer.append(TEXT_76);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_77);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_78);
    
                        if(javaType == JavaTypesManager.DATE) {

    stringBuffer.append(TEXT_79);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_80);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_81);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_82);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_83);
    stringBuffer.append( patternValue );
    stringBuffer.append(TEXT_84);
    
                        } else if(javaType == JavaTypesManager.BYTE_ARRAY){ 

    stringBuffer.append(TEXT_85);
    stringBuffer.append(TEXT_86);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_87);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_88);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_89);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_90);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_91);
    
                        } else {

    stringBuffer.append(TEXT_92);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_93);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_94);
    stringBuffer.append( typeToGenerate );
    stringBuffer.append(TEXT_95);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_96);
    stringBuffer.append(i );
    stringBuffer.append(TEXT_97);
    
                        }

    stringBuffer.append(TEXT_98);
    stringBuffer.append(TEXT_99);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_100);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_101);
    stringBuffer.append(JavaTypesManager.getDefaultValueFromJavaType(typeToGenerate));
    stringBuffer.append(TEXT_102);
                      
                }
    stringBuffer.append(TEXT_103);
    stringBuffer.append(TEXT_104);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_105);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_106);
    stringBuffer.append(JavaTypesManager.getDefaultValueFromJavaType(typeToGenerate));
    stringBuffer.append(TEXT_107);
              }
    stringBuffer.append(TEXT_108);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_109);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_110);
    
    if (dieOnError) {
        
    stringBuffer.append(TEXT_111);
    
    } else {
        if(!rejectConnName.equals("")&&!rejectConnName.equals(firstConnName)&&rejectColumnList != null && rejectColumnList.size() > 0) {
        
    stringBuffer.append(TEXT_112);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_113);
    stringBuffer.append(rejectConnName );
    stringBuffer.append(TEXT_114);
    
            for(IMetadataColumn column : metadata.getListColumns()) {
                
    stringBuffer.append(TEXT_115);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_116);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_117);
    stringBuffer.append(firstConnName);
    stringBuffer.append(TEXT_118);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_119);
    
            }
            
    stringBuffer.append(TEXT_120);
    stringBuffer.append(rejectConnName);
    stringBuffer.append(TEXT_121);
    stringBuffer.append(TEXT_122);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_123);
    
        } else {
            
    stringBuffer.append(TEXT_124);
    stringBuffer.append(TEXT_125);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_126);
    
        }
    } 
    
    stringBuffer.append(TEXT_127);
              
        }
    }
    if (conns.size()>0) {   
        boolean isFirstEnter = true;
        for (int i=0;i<conns.size();i++) {
            IConnection conn = conns.get(i);
            if ((conn.getName().compareTo(firstConnName)!=0)&&(conn.getName().compareTo(rejectConnName)!=0)&&(conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA))) {

     if(isFirstEnter) {
    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_129);
     isFirstEnter = false; } 
    stringBuffer.append(TEXT_130);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_131);
    stringBuffer.append(TEXT_132);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_133);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_134);
    
                 for (IMetadataColumn column: metadata.getListColumns()) {

    stringBuffer.append(TEXT_135);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_136);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_137);
    stringBuffer.append(firstConnName );
    stringBuffer.append(TEXT_138);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_139);
    
                }
            }
        }

     if(!isFirstEnter) {
    stringBuffer.append(TEXT_140);
     } 
    stringBuffer.append(TEXT_141);
    
     }
    }
  }
}

    return stringBuffer.toString();
  }
}
