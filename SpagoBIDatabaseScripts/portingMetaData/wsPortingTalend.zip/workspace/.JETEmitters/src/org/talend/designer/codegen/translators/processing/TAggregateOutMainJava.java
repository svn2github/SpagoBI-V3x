package org.talend.designer.codegen.translators.processing;

import org.talend.core.model.process.INode;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.IConnectionCategory;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;
import java.util.List;
import java.util.Map;

public class TAggregateOutMainJava
{
  protected static String nl;
  public static synchronized TAggregateOutMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TAggregateOutMainJava result = new TAggregateOutMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "//String key_";
  protected final String TEXT_3 = " = null;";
  protected final String TEXT_4 = NL + "//key_";
  protected final String TEXT_5 = " = String.valueOf(";
  protected final String TEXT_6 = ".";
  protected final String TEXT_7 = ");" + NL + "if(hash_";
  protected final String TEXT_8 = "_";
  protected final String TEXT_9 = ".containsKey(";
  protected final String TEXT_10 = ".";
  protected final String TEXT_11 = ")){" + NL + "\thash_";
  protected final String TEXT_12 = "_";
  protected final String TEXT_13 = " = hash_";
  protected final String TEXT_14 = "_";
  protected final String TEXT_15 = ".get(";
  protected final String TEXT_16 = ".";
  protected final String TEXT_17 = ");                    " + NL + "}else{" + NL + "\thash_";
  protected final String TEXT_18 = "_";
  protected final String TEXT_19 = " = new ";
  protected final String TEXT_20 = "java.util.";
  protected final String TEXT_21 = "Hash";
  protected final String TEXT_22 = "Set<";
  protected final String TEXT_23 = " ";
  protected final String TEXT_24 = "java.util.";
  protected final String TEXT_25 = "Hash";
  protected final String TEXT_26 = "Map<";
  protected final String TEXT_27 = ", OperationStruct";
  protected final String TEXT_28 = "java.util.";
  protected final String TEXT_29 = "Hash";
  protected final String TEXT_30 = "Map<";
  protected final String TEXT_31 = ",";
  protected final String TEXT_32 = ">";
  protected final String TEXT_33 = "();" + NL + "\thash_";
  protected final String TEXT_34 = "_";
  protected final String TEXT_35 = ".put(";
  protected final String TEXT_36 = ".";
  protected final String TEXT_37 = ",hash_";
  protected final String TEXT_38 = "_";
  protected final String TEXT_39 = ");" + NL + "}";
  protected final String TEXT_40 = NL + "//key_";
  protected final String TEXT_41 = " = String.valueOf(";
  protected final String TEXT_42 = ".";
  protected final String TEXT_43 = ");" + NL + "if(hash_";
  protected final String TEXT_44 = "_";
  protected final String TEXT_45 = ".containsKey(";
  protected final String TEXT_46 = ".";
  protected final String TEXT_47 = ")){" + NL + "\toperation_result_";
  protected final String TEXT_48 = " = hash_";
  protected final String TEXT_49 = "_";
  protected final String TEXT_50 = ".get(";
  protected final String TEXT_51 = ".";
  protected final String TEXT_52 = ");                    " + NL + "}else{" + NL + "\toperation_result_";
  protected final String TEXT_53 = " = new OperationStruct";
  protected final String TEXT_54 = "();";
  protected final String TEXT_55 = NL + "//key_";
  protected final String TEXT_56 = " = String.valueOf(";
  protected final String TEXT_57 = ".";
  protected final String TEXT_58 = ");";
  protected final String TEXT_59 = NL + "if(operation_result_";
  protected final String TEXT_60 = " == null){" + NL + "\toperation_result_";
  protected final String TEXT_61 = " = new OperationStruct";
  protected final String TEXT_62 = "();";
  protected final String TEXT_63 = NL;
  protected final String TEXT_64 = NL + "operation_result_";
  protected final String TEXT_65 = ".";
  protected final String TEXT_66 = "_";
  protected final String TEXT_67 = " = ";
  protected final String TEXT_68 = ".";
  protected final String TEXT_69 = ";";
  protected final String TEXT_70 = NL;
  protected final String TEXT_71 = NL + "\thash_";
  protected final String TEXT_72 = "_";
  protected final String TEXT_73 = ".put(";
  protected final String TEXT_74 = ".";
  protected final String TEXT_75 = ", operation_result_";
  protected final String TEXT_76 = ");" + NL + "}";
  protected final String TEXT_77 = NL + "\thash_";
  protected final String TEXT_78 = "_";
  protected final String TEXT_79 = ".add(";
  protected final String TEXT_80 = ".";
  protected final String TEXT_81 = ");\t\t";
  protected final String TEXT_82 = NL + "}";
  protected final String TEXT_83 = NL;
  protected final String TEXT_84 = NL + "if(operation_result_";
  protected final String TEXT_85 = ".";
  protected final String TEXT_86 = "_";
  protected final String TEXT_87 = ".compareTo(";
  protected final String TEXT_88 = ".";
  protected final String TEXT_89 = ") ";
  protected final String TEXT_90 = ">";
  protected final String TEXT_91 = "<";
  protected final String TEXT_92 = " 0){" + NL + "\toperation_result_";
  protected final String TEXT_93 = ".";
  protected final String TEXT_94 = "_";
  protected final String TEXT_95 = " = ";
  protected final String TEXT_96 = ".";
  protected final String TEXT_97 = ";" + NL + "}";
  protected final String TEXT_98 = NL + "if(operation_result_";
  protected final String TEXT_99 = ".";
  protected final String TEXT_100 = "_";
  protected final String TEXT_101 = " == null){" + NL + "\tif(";
  protected final String TEXT_102 = ".";
  protected final String TEXT_103 = " != null){" + NL + "\t\toperation_result_";
  protected final String TEXT_104 = ".";
  protected final String TEXT_105 = "_";
  protected final String TEXT_106 = " = ";
  protected final String TEXT_107 = ".";
  protected final String TEXT_108 = ";" + NL + "\t}" + NL + "}else if(";
  protected final String TEXT_109 = ".";
  protected final String TEXT_110 = " != null){" + NL + "\tif(operation_result_";
  protected final String TEXT_111 = ".";
  protected final String TEXT_112 = "_";
  protected final String TEXT_113 = ".compareTo(";
  protected final String TEXT_114 = ".";
  protected final String TEXT_115 = ") ";
  protected final String TEXT_116 = ">";
  protected final String TEXT_117 = "<";
  protected final String TEXT_118 = " 0){" + NL + "\t\toperation_result_";
  protected final String TEXT_119 = ".";
  protected final String TEXT_120 = "_";
  protected final String TEXT_121 = " = ";
  protected final String TEXT_122 = ".";
  protected final String TEXT_123 = ";" + NL + "\t}" + NL + "}";
  protected final String TEXT_124 = NL + "if(";
  protected final String TEXT_125 = "!";
  protected final String TEXT_126 = ".";
  protected final String TEXT_127 = "){" + NL + "\tif(";
  protected final String TEXT_128 = "!";
  protected final String TEXT_129 = "operation_result_";
  protected final String TEXT_130 = ".";
  protected final String TEXT_131 = "_";
  protected final String TEXT_132 = "){" + NL + "\t\toperation_result_";
  protected final String TEXT_133 = ".";
  protected final String TEXT_134 = "_";
  protected final String TEXT_135 = " = ";
  protected final String TEXT_136 = "false";
  protected final String TEXT_137 = "true";
  protected final String TEXT_138 = ";" + NL + "\t}" + NL + "}";
  protected final String TEXT_139 = NL + "if(operation_result_";
  protected final String TEXT_140 = ".";
  protected final String TEXT_141 = "_";
  protected final String TEXT_142 = " == null){" + NL + "\tif(";
  protected final String TEXT_143 = ".";
  protected final String TEXT_144 = " != null){" + NL + "\t\toperation_result_";
  protected final String TEXT_145 = ".";
  protected final String TEXT_146 = "_";
  protected final String TEXT_147 = " = ";
  protected final String TEXT_148 = ".";
  protected final String TEXT_149 = ";" + NL + "\t}" + NL + "}else if(";
  protected final String TEXT_150 = ".";
  protected final String TEXT_151 = " != null){" + NL + "    if(";
  protected final String TEXT_152 = "!";
  protected final String TEXT_153 = ".";
  protected final String TEXT_154 = "){" + NL + "    \tif(";
  protected final String TEXT_155 = "!";
  protected final String TEXT_156 = "operation_result_";
  protected final String TEXT_157 = ".";
  protected final String TEXT_158 = "_";
  protected final String TEXT_159 = "){" + NL + "    \t\toperation_result_";
  protected final String TEXT_160 = ".";
  protected final String TEXT_161 = "_";
  protected final String TEXT_162 = " = ";
  protected final String TEXT_163 = "false";
  protected final String TEXT_164 = "true";
  protected final String TEXT_165 = ";" + NL + "    \t}" + NL + "    }" + NL + "}";
  protected final String TEXT_166 = NL + "if(operation_result_";
  protected final String TEXT_167 = ".";
  protected final String TEXT_168 = "_";
  protected final String TEXT_169 = ".doubleValue()";
  protected final String TEXT_170 = "  - ";
  protected final String TEXT_171 = ".";
  protected final String TEXT_172 = ".doubleValue()";
  protected final String TEXT_173 = " ";
  protected final String TEXT_174 = ">";
  protected final String TEXT_175 = "<";
  protected final String TEXT_176 = " 0){" + NL + "\toperation_result_";
  protected final String TEXT_177 = ".";
  protected final String TEXT_178 = "_";
  protected final String TEXT_179 = " = ";
  protected final String TEXT_180 = ".";
  protected final String TEXT_181 = ";" + NL + "}";
  protected final String TEXT_182 = NL + "if(operation_result_";
  protected final String TEXT_183 = ".";
  protected final String TEXT_184 = "_";
  protected final String TEXT_185 = " == null){" + NL + "\tif(";
  protected final String TEXT_186 = ".";
  protected final String TEXT_187 = " != null){" + NL + "\t\toperation_result_";
  protected final String TEXT_188 = ".";
  protected final String TEXT_189 = "_";
  protected final String TEXT_190 = " = ";
  protected final String TEXT_191 = ".";
  protected final String TEXT_192 = ";" + NL + "\t}" + NL + "}else if(";
  protected final String TEXT_193 = ".";
  protected final String TEXT_194 = " != null){" + NL + "    if(operation_result_";
  protected final String TEXT_195 = ".";
  protected final String TEXT_196 = "_";
  protected final String TEXT_197 = ".doubleValue()";
  protected final String TEXT_198 = "  - ";
  protected final String TEXT_199 = ".";
  protected final String TEXT_200 = ".doubleValue()";
  protected final String TEXT_201 = " ";
  protected final String TEXT_202 = ">";
  protected final String TEXT_203 = "<";
  protected final String TEXT_204 = " 0){" + NL + "\t\toperation_result_";
  protected final String TEXT_205 = ".";
  protected final String TEXT_206 = "_";
  protected final String TEXT_207 = " = ";
  protected final String TEXT_208 = ".";
  protected final String TEXT_209 = ";" + NL + "\t}" + NL + "}";
  protected final String TEXT_210 = NL + "operation_result_";
  protected final String TEXT_211 = ".";
  protected final String TEXT_212 = "_sum = operation_result_";
  protected final String TEXT_213 = ".";
  protected final String TEXT_214 = "_sum.add(";
  protected final String TEXT_215 = ".";
  protected final String TEXT_216 = ");";
  protected final String TEXT_217 = NL + "if(";
  protected final String TEXT_218 = ".";
  protected final String TEXT_219 = " != null){" + NL + "\toperation_result_";
  protected final String TEXT_220 = ".";
  protected final String TEXT_221 = "_sum = operation_result_";
  protected final String TEXT_222 = ".";
  protected final String TEXT_223 = "_sum.add(";
  protected final String TEXT_224 = ".";
  protected final String TEXT_225 = ");" + NL + "}";
  protected final String TEXT_226 = NL + "operation_result_";
  protected final String TEXT_227 = ".";
  protected final String TEXT_228 = "_sum = operation_result_";
  protected final String TEXT_229 = ".";
  protected final String TEXT_230 = "_sum.add(BigDecimal.valueOf(";
  protected final String TEXT_231 = ".";
  protected final String TEXT_232 = "));";
  protected final String TEXT_233 = NL + "if(";
  protected final String TEXT_234 = ".";
  protected final String TEXT_235 = " != null){" + NL + "\toperation_result_";
  protected final String TEXT_236 = ".";
  protected final String TEXT_237 = "_sum = operation_result_";
  protected final String TEXT_238 = ".";
  protected final String TEXT_239 = "_sum.add(BigDecimal.valueOf(";
  protected final String TEXT_240 = ".";
  protected final String TEXT_241 = "));" + NL + "}";
  protected final String TEXT_242 = NL + "operation_result_";
  protected final String TEXT_243 = ".";
  protected final String TEXT_244 = "_count ++;";
  protected final String TEXT_245 = NL + "if(";
  protected final String TEXT_246 = ".";
  protected final String TEXT_247 = " != null){" + NL + "\toperation_result_";
  protected final String TEXT_248 = ".";
  protected final String TEXT_249 = "_count ++;" + NL + "}";
  protected final String TEXT_250 = NL + "//get the first value that is not null" + NL + "if((operation_result_";
  protected final String TEXT_251 = ".";
  protected final String TEXT_252 = "_";
  protected final String TEXT_253 = " == null) && (";
  protected final String TEXT_254 = ".";
  protected final String TEXT_255 = " != null)){" + NL + "\toperation_result_";
  protected final String TEXT_256 = ".";
  protected final String TEXT_257 = "_";
  protected final String TEXT_258 = " = ";
  protected final String TEXT_259 = ".";
  protected final String TEXT_260 = ";" + NL + "}";
  protected final String TEXT_261 = NL + "operation_result_";
  protected final String TEXT_262 = ".";
  protected final String TEXT_263 = "_last = ";
  protected final String TEXT_264 = ".";
  protected final String TEXT_265 = ";";
  protected final String TEXT_266 = NL + "if(";
  protected final String TEXT_267 = ".";
  protected final String TEXT_268 = " != null){" + NL + "\toperation_result_";
  protected final String TEXT_269 = ".";
  protected final String TEXT_270 = "_last = ";
  protected final String TEXT_271 = ".";
  protected final String TEXT_272 = ";" + NL + "}";
  protected final String TEXT_273 = NL + "operation_result_";
  protected final String TEXT_274 = ".";
  protected final String TEXT_275 = "_list = (operation_result_";
  protected final String TEXT_276 = ".";
  protected final String TEXT_277 = "_list.length() == 0) ? String.valueOf(";
  protected final String TEXT_278 = ".";
  protected final String TEXT_279 = ") : (operation_result_";
  protected final String TEXT_280 = ".";
  protected final String TEXT_281 = "_list + \",\" + ";
  protected final String TEXT_282 = ".";
  protected final String TEXT_283 = ");";
  protected final String TEXT_284 = NL + "if(";
  protected final String TEXT_285 = ".";
  protected final String TEXT_286 = " != null){" + NL + "\toperation_result_";
  protected final String TEXT_287 = ".";
  protected final String TEXT_288 = "_list = (operation_result_";
  protected final String TEXT_289 = ".";
  protected final String TEXT_290 = "_list.length() == 0) ? String.valueOf(";
  protected final String TEXT_291 = ".";
  protected final String TEXT_292 = ") : (operation_result_";
  protected final String TEXT_293 = ".";
  protected final String TEXT_294 = "_list + \",\" + ";
  protected final String TEXT_295 = ".";
  protected final String TEXT_296 = ");" + NL + "}";
  protected final String TEXT_297 = NL + "operation_result_";
  protected final String TEXT_298 = ".";
  protected final String TEXT_299 = "_distinct.add(";
  protected final String TEXT_300 = ".";
  protected final String TEXT_301 = ");";
  protected final String TEXT_302 = NL + "if(";
  protected final String TEXT_303 = ".";
  protected final String TEXT_304 = " != null){" + NL + "\toperation_result_";
  protected final String TEXT_305 = ".";
  protected final String TEXT_306 = "_distinct.add(";
  protected final String TEXT_307 = ".";
  protected final String TEXT_308 = ");" + NL + "}";
  protected final String TEXT_309 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();
List< ? extends IConnection> conns = node.getIncomingConnections();
for (IConnection conn : conns) {
	if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
		List<Map<String, String>> operations = (List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__OPERATIONS__");
        List<Map<String, String>> groupbys = (List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__GROUPBYS__");
        IMetadataTable inMetadata = conn.getMetadataTable();
		List<IMetadataColumn> columns = inMetadata.getListColumns();
		int sizeOperations = operations.size();
		int sizeGroupbys = groupbys.size();
		String lastInputColumn = null;
		if(sizeGroupbys>0){
			lastInputColumn = groupbys.get(sizeGroupbys-1).get("INPUT_COLUMN");
		}
		
		
		//pretreatment opreations before aggregating
		
		//modify06-05 begin
String[] groupby_type = new String[sizeGroupbys];
for(int i = 0; i < sizeGroupbys; i++){
	String columnname = groupbys.get(i).get("INPUT_COLUMN");
	List<? extends IConnection> incomingConnections = node.getIncomingConnections();
    if (incomingConnections != null && !incomingConnections.isEmpty()) {
    	for (IConnection conne : incomingConnections) {
			if (conne.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
        		IMetadataTable inMetadatat = conne.getMetadataTable();
       			for (IMetadataColumn column: inMetadatat.getListColumns()) {
            		if(column.getLabel().equals(columnname)){
						JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
						if(javaType == JavaTypesManager.BOOLEAN){
							groupby_type[i] = "Boolean";
						}else if(javaType == JavaTypesManager.BYTE){
							groupby_type[i] = "Byte";
						}else if(javaType == JavaTypesManager.BYTE_ARRAY){
							groupby_type[i] = "byte[]";
						}else if(javaType == JavaTypesManager.CHARACTER){
							groupby_type[i] = "Character";
						}else if(javaType == JavaTypesManager.DATE){
							groupby_type[i] = "java.util.Date";
						}else if(javaType == JavaTypesManager.DOUBLE){
							groupby_type[i] = "Double";
						}else if(javaType == JavaTypesManager.FLOAT){
							groupby_type[i] = "Float";
						}else if(javaType == JavaTypesManager.INTEGER){
							groupby_type[i] = "Integer";
						}else if(javaType == JavaTypesManager.LONG){
							groupby_type[i] = "Long";
						}else if(javaType == JavaTypesManager.SHORT){
							groupby_type[i] = "Short";
						}else if(javaType == JavaTypesManager.STRING){
							groupby_type[i] = "String";
						}else if(javaType == JavaTypesManager.OBJECT){
							groupby_type[i] = "Object";
						}
						break;
            		}
				}
			}
		}
  	}
}
//modify06-05 end
		
		List<String[]> funinOperations = new java.util.ArrayList<String[]>();
		next:
		for(int i=0; i<sizeOperations; i++){
			Map<String, String> operation = operations.get(i);
			String fun = operation.get("FUNCTION");
			String in = operation.get("INPUT_COLUMN");
			String ignoreNull = operation.get("IGNORE_NULL");
			if(fun.equals("sum") || fun.equals("count")){
				for(int j=0; j<sizeOperations; j++){
					Map<String, String> tOperation = operations.get(j);
					if(tOperation.get("FUNCTION").equals("avg") && tOperation.get("INPUT_COLUMN").equals(in)){
						continue next;
					}
				}
			}
			for(int j = 0; j < i; j++){//skip depulicate operation
				Map<String, String> tOperation = operations.get(j);
				if(tOperation.get("FUNCTION").equals(fun) && tOperation.get("INPUT_COLUMN").equals(in)){
					continue next;
				}
			}
			if(fun.equals("avg")){
				String[] funin = new String[3];
				funin[0]="sum";
				funin[1]=in;
				funin[2]=ignoreNull;
				funinOperations.add(funin);
				funin=new String[3];
				funin[0]="count";
				funin[1]=in;
				funin[2]=ignoreNull;
				funinOperations.add(funin);
			}else{
				String[] funin = new String[3];
				funin[0]=fun;
				funin[1]=in;
				funin[2]=ignoreNull;
				funinOperations.add(funin);
			}
		}
		int sizeOps = funinOperations.size();
		String tInputColumn =null;
		
		for (int i=0; i<sizeGroupbys; i++) {
           	Map<String, String> groupby = groupbys.get(i);
			String inputColumn = groupby.get("INPUT_COLUMN");
			String nextInputColumn = null;
			if(i==0){
//
//end
    stringBuffer.append(TEXT_2);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_3);
    //start
//
			}
			if(i != sizeGroupbys - 1){
				nextInputColumn = groupbys.get(i+1).get("INPUT_COLUMN");
			}
			if(i < sizeGroupbys-1){

    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_5);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_6);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_7);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_9);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_10);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_11);
    stringBuffer.append(nextInputColumn  );
    stringBuffer.append(TEXT_12);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_13);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_14);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_15);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_16);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_17);
    stringBuffer.append(nextInputColumn  );
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_19);
    
//start
//
					for(int j = i+1; j < sizeGroupbys; j++){
						if(j == sizeGroupbys - 1){
							if(sizeOps == 0){
//
//end

    stringBuffer.append(TEXT_20);
    if(j == i+1){
    stringBuffer.append(TEXT_21);
    }
    stringBuffer.append(TEXT_22);
    stringBuffer.append(groupby_type[j] );
    stringBuffer.append(TEXT_23);
    
//start
//
							}else{
//
//end

    stringBuffer.append(TEXT_24);
    if(j == i+1){
    stringBuffer.append(TEXT_25);
    }
    stringBuffer.append(TEXT_26);
    stringBuffer.append(groupby_type[j] );
    stringBuffer.append(TEXT_27);
    stringBuffer.append(cid );
    
//start
//
							}
						}else{
//
//end

    stringBuffer.append(TEXT_28);
    if(j == i+1){
    stringBuffer.append(TEXT_29);
    }
    stringBuffer.append(TEXT_30);
    stringBuffer.append(groupby_type[j] );
    stringBuffer.append(TEXT_31);
    
//start
//
						}
					}
					for(int j = i+1; j < sizeGroupbys; j++){
//
//end

    stringBuffer.append(TEXT_32);
    
//start
//
					}
//
//end

    stringBuffer.append(TEXT_33);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_34);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_35);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_36);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_37);
    stringBuffer.append(nextInputColumn );
    stringBuffer.append(TEXT_38);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_39);
    //start
//
				}else{
					tInputColumn = inputColumn;
					if(sizeOps > 0 ){
//
//end
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_41);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_42);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_43);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_45);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_46);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_47);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_48);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_50);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_51);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_52);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_53);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_54);
    //start
//
					}else{
    stringBuffer.append(TEXT_55);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_56);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_57);
    stringBuffer.append(inputColumn );
    stringBuffer.append(TEXT_58);
    
					}
				}
			}
			if(sizeOps>0 && sizeGroupbys == 0){

    stringBuffer.append(TEXT_59);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_62);
    
			}

    stringBuffer.append(TEXT_63);
    //start
//
		for(int j = 0; j < sizeOps; j++){
			String[] funin = funinOperations.get(j);
			if(funin[0].equals("first")||funin[0].equals("min")||funin[0].equals("max")){
//
//end
    stringBuffer.append(TEXT_64);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_65);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_66);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_67);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_68);
    stringBuffer.append(funin[1]  );
    stringBuffer.append(TEXT_69);
    //start
//
			}
		}
//
//end
    stringBuffer.append(TEXT_70);
    
		if(sizeGroupbys > 0){
			if(sizeOps>0){

    stringBuffer.append(TEXT_71);
    stringBuffer.append(tInputColumn );
    stringBuffer.append(TEXT_72);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_73);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_74);
    stringBuffer.append(lastInputColumn );
    stringBuffer.append(TEXT_75);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_76);
    
			}else{

    stringBuffer.append(TEXT_77);
    stringBuffer.append(tInputColumn );
    stringBuffer.append(TEXT_78);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_79);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_80);
    stringBuffer.append(lastInputColumn );
    stringBuffer.append(TEXT_81);
    
			}
		}else if(sizeOps > 0){
    stringBuffer.append(TEXT_82);
    
		}

    stringBuffer.append(TEXT_83);
    //start
//
		JavaType javaType = null;
        for(int j = 0; j < sizeOps; j++){
			String[] funin = funinOperations.get(j);
            for (IMetadataColumn column: columns) {
            	if(column.toString().equals(funin[1])){
            		javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
            			break;
            	}
            }
			if(funin[0].equals("min")||funin[0].equals("max")){
				if(javaType == JavaTypesManager.BYTE_ARRAY || javaType == JavaTypesManager.OBJECT){
					//do nothing here
				}else if(javaType == JavaTypesManager.STRING || javaType == JavaTypesManager.DATE){
					if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_84);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_85);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_86);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_87);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_88);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_89);
    if(funin[0].equals("min")){
    stringBuffer.append(TEXT_90);
    }else{
    stringBuffer.append(TEXT_91);
    }
    stringBuffer.append(TEXT_92);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_93);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_94);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_95);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_96);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_97);
    //start
//
					}else{
//
//end
    stringBuffer.append(TEXT_98);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_99);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_100);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_101);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_102);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_103);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_104);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_105);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_106);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_107);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_108);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_109);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_110);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_111);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_112);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_113);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_114);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_115);
    if(funin[0].equals("min")){
    stringBuffer.append(TEXT_116);
    }else{
    stringBuffer.append(TEXT_117);
    }
    stringBuffer.append(TEXT_118);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_119);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_120);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_121);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_122);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_123);
    //start
//
					}
				}else if(javaType == JavaTypesManager.BOOLEAN){
					if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_124);
    if(funin[0].equals("min")){
    stringBuffer.append(TEXT_125);
    }
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_126);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_127);
    if(funin[0].equals("max")){
    stringBuffer.append(TEXT_128);
    }
    stringBuffer.append(TEXT_129);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_130);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_131);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_132);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_133);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_134);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_135);
    if(funin[0].equals("min")){
    stringBuffer.append(TEXT_136);
    }else{
    stringBuffer.append(TEXT_137);
    }
    stringBuffer.append(TEXT_138);
    //start
//
					}else{
//
//end
    stringBuffer.append(TEXT_139);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_140);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_141);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_142);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_143);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_144);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_145);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_146);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_147);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_148);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_149);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_150);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_151);
    if(funin[0].equals("min")){
    stringBuffer.append(TEXT_152);
    }
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_153);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_154);
    if(funin[0].equals("max")){
    stringBuffer.append(TEXT_155);
    }
    stringBuffer.append(TEXT_156);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_157);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_158);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_159);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_160);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_161);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_162);
    if(funin[0].equals("min")){
    stringBuffer.append(TEXT_163);
    }else{
    stringBuffer.append(TEXT_164);
    }
    stringBuffer.append(TEXT_165);
    //start
//
					}
				}else{
					//for numbers(byte, char, short, int, long, float, double)
					if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_166);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_167);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_168);
    stringBuffer.append(funin[0] );
    if(javaType == JavaTypesManager.BIGDECIMAL){
    stringBuffer.append(TEXT_169);
    }
    stringBuffer.append(TEXT_170);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_171);
    stringBuffer.append(funin[1] );
    if(javaType == JavaTypesManager.BIGDECIMAL){
    stringBuffer.append(TEXT_172);
    }
    stringBuffer.append(TEXT_173);
    if(funin[0].equals("min")){
    stringBuffer.append(TEXT_174);
    }else{
    stringBuffer.append(TEXT_175);
    }
    stringBuffer.append(TEXT_176);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_177);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_178);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_179);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_180);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_181);
    //start
//
					}else{
//
//end
    stringBuffer.append(TEXT_182);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_183);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_184);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_185);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_186);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_187);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_188);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_189);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_190);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_191);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_192);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_193);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_194);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_195);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_196);
    stringBuffer.append(funin[0] );
    if(javaType == JavaTypesManager.BIGDECIMAL){
    stringBuffer.append(TEXT_197);
    }
    stringBuffer.append(TEXT_198);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_199);
    stringBuffer.append(funin[1] );
    if(javaType == JavaTypesManager.BIGDECIMAL){
    stringBuffer.append(TEXT_200);
    }
    stringBuffer.append(TEXT_201);
    if(funin[0].equals("min")){
    stringBuffer.append(TEXT_202);
    }else{
    stringBuffer.append(TEXT_203);
    }
    stringBuffer.append(TEXT_204);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_205);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_206);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_207);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_208);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_209);
    //start
//
					}
				}
			}
			if(funin[0].equals("sum")){
				if(javaType == JavaTypesManager.BYTE_ARRAY || javaType == JavaTypesManager.OBJECT 
					|| javaType == JavaTypesManager.STRING || javaType == JavaTypesManager.BOOLEAN
					|| javaType == JavaTypesManager.DATE){
					//do nothing here
				}else if(javaType == JavaTypesManager.BIGDECIMAL){
					if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_210);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_211);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_212);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_213);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_214);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_215);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_216);
    //start
//
					}else{
//
//end
    stringBuffer.append(TEXT_217);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_218);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_219);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_220);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_221);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_222);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_223);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_224);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_225);
    //start
//
					}
				}else{
					if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_226);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_227);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_228);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_229);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_230);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_231);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_232);
    //start
//
					}else{
//
//end
    stringBuffer.append(TEXT_233);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_234);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_235);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_236);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_237);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_238);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_239);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_240);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_241);
    //start
//
					}
				}
			}
			if(funin[0].equals("count")){
				if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_242);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_243);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_244);
    //start
//
				}else{
//
//end
    stringBuffer.append(TEXT_245);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_246);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_247);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_249);
    //start
//
				}
			}
			if(funin[0].equals("first") && funin[2].equals("true")){
//
//end
    stringBuffer.append(TEXT_250);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_251);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_252);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_253);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_254);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_255);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_256);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_257);
    stringBuffer.append(funin[0] );
    stringBuffer.append(TEXT_258);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_259);
    stringBuffer.append(funin[1]  );
    stringBuffer.append(TEXT_260);
    //start
//
			}
			if(funin[0].equals("last")){
					if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_261);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_262);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_263);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_264);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_265);
    //start
//
					}else{
//
//end
    stringBuffer.append(TEXT_266);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_267);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_268);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_269);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_270);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_271);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_272);
    //start
//
					}
			}
			if(funin[0].equals("list")){
				if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_273);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_274);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_275);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_276);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_277);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_278);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_279);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_280);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_281);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_282);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_283);
    //start
//
				}else{
//
//end
    stringBuffer.append(TEXT_284);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_285);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_286);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_287);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_288);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_289);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_290);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_291);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_292);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_293);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_294);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_295);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_296);
    //start
//
				}
			}
			if(funin[0].equals("distinct")){
				if(funin[2].equals("false")){
//
//end
    stringBuffer.append(TEXT_297);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_298);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_299);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_300);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_301);
    //start
//
				}else{
//
//end
    stringBuffer.append(TEXT_302);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_303);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_304);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_305);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_306);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_307);
    stringBuffer.append(funin[1] );
    stringBuffer.append(TEXT_308);
    //start
//
				}
			}
		}
//
//end
	}
}
//
//end
    stringBuffer.append(TEXT_309);
    return stringBuffer.toString();
  }
}
