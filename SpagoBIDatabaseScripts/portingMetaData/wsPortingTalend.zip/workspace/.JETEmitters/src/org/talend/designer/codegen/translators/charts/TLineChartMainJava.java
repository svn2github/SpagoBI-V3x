package org.talend.designer.codegen.translators.charts;

import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.process.INode;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.IConnectionCategory;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;

public class TLineChartMainJava
{
  protected static String nl;
  public static synchronized TLineChartMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TLineChartMainJava result = new TLineChartMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "  String serieLabel = ";
  protected final String TEXT_2 = ".serie;" + NL + "  org.jfree.data.xy.XYSeries serie;" + NL + "  if (series.containsKey(serieLabel)){" + NL + "    serie=series.get(serieLabel);" + NL + "  } else {" + NL + "    serie= new org.jfree.data.xy.XYSeries(serieLabel, true, false);" + NL + "    series.put(serieLabel, serie);" + NL + "  }" + NL + "" + NL + "  serie.add(";
  protected final String TEXT_3 = ".x,";
  protected final String TEXT_4 = ".y);";
  protected final String TEXT_5 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();

    
	List< ? extends IConnection> conns = node.getIncomingConnections();
	if (conns!=null && !conns.isEmpty()){
	for (IConnection conn : conns){
if( conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)) {
    stringBuffer.append(TEXT_1);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_2);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_3);
    stringBuffer.append(conn.getName() );
    stringBuffer.append(TEXT_4);
    }
}
}
    stringBuffer.append(TEXT_5);
    return stringBuffer.toString();
  }
}
