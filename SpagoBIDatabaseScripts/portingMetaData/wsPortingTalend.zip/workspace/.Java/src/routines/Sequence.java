package routines;

import java.math.BigDecimal;
import java.sql.*;


/**
 * @author Chiara Chiarelli
 *
 */
public class Sequence {
	
	private static Connection dbConnection;
	private static PreparedStatement selectStmt = null;
	private static PreparedStatement createTrgStmt = null;	
	private static BigDecimal idTabella = null;
	public static String SEQ_NAME = "_SEQ";
	public static String nomeTabella = null;
	public static String nomeIdTabella = null;
	

	public static BigDecimal getIdTabella() {
		return idTabella;
	}

	public static void setIdTabella(BigDecimal idTabella) {
		Sequence.idTabella = idTabella;
	}
	
	public static String getSeqName() {
		return Sequence.getNomeTabella() + SEQ_NAME ;
	}

	public static void setSeqName(String SEQ_NAME) {
		Sequence.SEQ_NAME = SEQ_NAME;
	}
	
	public static String getNomeTabella() {
		return nomeTabella;
	}

	public static void setNomeTabella(String nomeTabella) {
		Sequence.nomeTabella = nomeTabella;
	}
	
	public static String getNomeIdTabella() {
		return nomeIdTabella;
	}

	public static void setNomeIdTabella(String nomeIdTabella) {
		Sequence.nomeIdTabella = nomeIdTabella;
	}
	
	public static void init(String driver, String url, String user, String pwd) {
		
		
		try {
			java.lang.Class.forName(driver);
			dbConnection = java.sql.DriverManager.getConnection(url, user, pwd);
			
			selectStmt = dbConnection
			.prepareStatement("select max("+nomeTabella+"."+nomeIdTabella+" )  "
					+ "from " +nomeTabella);
			
			String tmpQuery = "CREATE trigger TRG_" + Sequence.getNomeTabella() + " BEFORE INSERT on " + Sequence.getNomeTabella() + 
			" REFERENCING OLD AS old NEW AS new for each row declare nuovo_id number; begin IF :new.VALUE_ID IS NULL THEN select " +
			Sequence.getSeqName() + ".nextval into nuovo_id from dual; :new.VALUE_ID:=nuovo_id; END IF; end;";
			
			System.out.println(tmpQuery);
			
			createTrgStmt = dbConnection
			.prepareStatement(tmpQuery);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	
	public static void updateSequenceVal(boolean createTrg) throws Exception{
		String query = null;			
		Statement stmt = null;
		ResultSet rs = null;
		BigDecimal valSeq = new BigDecimal("1");

		try{
			//dropSeqStmt.execute();														

			rs = selectStmt.executeQuery();
			while (rs.next()) {				
				valSeq = rs.getBigDecimal(1);

			}
			query = "CREATE SEQUENCE " + Sequence.getSeqName() + " minvalue 1 maxvalue 999999999999999999999 start with " + valSeq.toString() + " increment by 1 cache 20 ";				
			System.out.println("Sequence created with value : " + valSeq.toString());
			stmt = dbConnection.createStatement();				
			rs = stmt.executeQuery(query);				
			rs.close();
	        if (createTrg){
	        	createTrgStmt.execute();
			    System.out.println("Trigger Created.");
	        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}							
	}
	


	public static void main(String args[]){
	}
}
